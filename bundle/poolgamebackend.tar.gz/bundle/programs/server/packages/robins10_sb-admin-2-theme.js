(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['robins10:sb-admin-2-theme'] = {};

})();
