(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['zodiase:material-design-icons-fonts'] = {};

})();
