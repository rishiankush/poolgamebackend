(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['myboon:bootstrap-material-datetimepicker'] = {};

})();
