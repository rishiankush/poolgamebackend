var require = meteorInstall({"server":{"rest":{"v1":{"File":{"upload.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/File/upload.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Busboy = void 0;                                                                                                  // 1
module.watch(require("busboy"), {                                                                                     // 1
  "default": function (v) {                                                                                           // 1
    Busboy = v;                                                                                                       // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
                                                                                                                      //
var uploadBeforeAction = function (req, res, next) {                                                                  // 6
  var files = []; // Store files in an array and then pass them to request.                                           // 7
                                                                                                                      //
  if (req.method === 'POST') {                                                                                        // 9
    //console.log(req.body.token)                                                                                     // 10
    // console.log(req.body);                                                                                         // 11
    var busboy = new Busboy({                                                                                         // 13
      headers: req.headers                                                                                            // 13
    });                                                                                                               // 13
    busboy.on('file', function (fieldname, file, filename, encoding, mimetype) {                                      // 15
      var fileObj = {}; // crate an fileObj object                                                                    // 16
                                                                                                                      //
      fileObj.mimeType = mimetype;                                                                                    // 18
      fileObj.encoding = encoding;                                                                                    // 19
      fileObj.filename = filename; // buffer the read chunks                                                          // 20
                                                                                                                      //
      var buffers = [];                                                                                               // 22
      file.on('data', function (data) {                                                                               // 24
        buffers.push(data);                                                                                           // 25
      });                                                                                                             // 26
      file.on('end', function () {                                                                                    // 28
        // concat the chunks                                                                                          // 29
        fileObj.data = Buffer.concat(buffers); // push the image object to the file array                             // 30
                                                                                                                      //
        files.push(fileObj);                                                                                          // 32
      });                                                                                                             // 33
    });                                                                                                               // 34
    busboy.on('field', function (fieldname, value) {                                                                  // 36
      req.body[fieldname] = value;                                                                                    // 37
    });                                                                                                               // 38
    busboy.on('finish', function () {                                                                                 // 40
      // Pass the file array together with the request                                                                // 41
      req.files = files;                                                                                              // 42
      next();                                                                                                         // 43
    }); // Pass request to busboy                                                                                     // 44
                                                                                                                      //
    req.pipe(busboy);                                                                                                 // 47
  } else {                                                                                                            // 48
    this.next();                                                                                                      // 49
  }                                                                                                                   // 50
};                                                                                                                    // 51
                                                                                                                      //
Router.route('/rest/v1/files/upload', function () {                                                                   // 53
  this.response.setHeader('Access-Control-Allow-Origin', '*'); // Meteor.log._('ios test', this.request.headers);     // 56
  // Meteor.call('storeLog', this.request.headers);                                                                   // 59
                                                                                                                      //
  var context = this,                                                                                                 // 61
      filesData = this.request.files,                                                                                 // 61
      filesUrls = [];                                                                                                 // 61
  console.log('request file ******* ', filesData);                                                                    // 64
                                                                                                                      //
  _.each(filesData, function (file) {                                                                                 // 65
    var newFile = new FS.File();                                                                                      // 66
    newFile.attachData(file.data, {                                                                                   // 68
      type: file.mimeType                                                                                             // 68
    }, function (err) {                                                                                               // 68
      newFile.name(file.filename);                                                                                    // 69
      Files.insert(newFile, function (err, fileObj) {                                                                 // 71
        while (fileObj.url() == null) {} //let ext = fileObj.url().split('/store/files/uploads/'+fileObj._id+'/')[1].split('.').pop();
                                                                                                                      //
                                                                                                                      //
        filesUrls.push({                                                                                              // 74
          _id: fileObj._id,                                                                                           // 74
          url: fileObj.url(),                                                                                         // 74
          type: fileObj.type()                                                                                        // 74
        }); //console.log(fileObj.url().split('/store/files/uploads/'+fileObj._id+'/')[1]);                           // 74
                                                                                                                      //
        if (filesData.length === filesUrls.length) Utility.response(context, 200, successResponse({                   // 77
          msg: 'File uploaded successfully',                                                                          // 81
          data: filesUrls                                                                                             // 81
        }));                                                                                                          // 81
      });                                                                                                             // 83
    });                                                                                                               // 84
  });                                                                                                                 // 85
}, {                                                                                                                  // 86
  where: 'server',                                                                                                    // 88
  onBeforeAction: uploadBeforeAction                                                                                  // 89
});                                                                                                                   // 87
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"gamePricings":{"gamePricings.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/gamePricings/gamePricings.js                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var mentionMandatoryFields = void 0,                                                                                  // 1
    feildsCannotBeEdited = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  mentionMandatoryFields: function (v) {                                                                              // 1
    mentionMandatoryFields = v;                                                                                       // 1
  },                                                                                                                  // 1
  feildsCannotBeEdited: function (v) {                                                                                // 1
    feildsCannotBeEdited = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
var authentication = void 0;                                                                                          // 1
module.watch(require("../../Auth"), {                                                                                 // 1
  "default": function (v) {                                                                                           // 1
    authentication = v;                                                                                               // 1
  }                                                                                                                   // 1
}, 2);                                                                                                                // 1
Router.route('/rest/v1/gamePricings/getGamePricings', function () {                                                   // 6
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                        // 9
                                                                                                                      //
  if (this.request.method == 'POST') {                                                                                // 10
    var context = this,                                                                                               // 11
        Data = Utility.getRequestContents(context.request);                                                           // 11
    field = mentionMandatoryFields(Data, ['userId', 'token']);                                                        // 13
                                                                                                                      //
    if (field) {                                                                                                      // 14
      Utility.response(context, 400, failResponse(field));                                                            // 16
    } else {                                                                                                          // 22
      var userId = Data.userId,                                                                                       // 22
          token = Data.token;                                                                                         // 22
                                                                                                                      //
      var _authentication = authentication({                                                                          // 22
        userId: userId,                                                                                               // 24
        token: token                                                                                                  // 24
      }),                                                                                                             // 24
          authorise = _authentication.authorise,                                                                      // 22
          message = _authentication.message;                                                                          // 22
                                                                                                                      //
      if (authorise) {                                                                                                // 25
        var pricings = gamePricing.getGamePriceByType(1, {                                                            // 26
          deduction: 1,                                                                                               // 26
          price: 1,                                                                                                   // 26
          name: 1                                                                                                     // 26
        });                                                                                                           // 26
        Utility.response(context, 200, successResponse({                                                              // 27
          data: pricings                                                                                              // 31
        }));                                                                                                          // 30
      } else {                                                                                                        // 35
        Utility.response(context, 400, failResponse(message));                                                        // 36
      }                                                                                                               // 41
    }                                                                                                                 // 43
  } else {                                                                                                            // 46
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 47
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 51
    this.response.end('Set OPTIONS.');                                                                                // 52
  }                                                                                                                   // 53
}, {                                                                                                                  // 54
  where: 'server'                                                                                                     // 55
});                                                                                                                   // 55
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"singleGames":{"makeBet.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/singleGames/makeBet.js                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var mentionMandatoryFields = void 0,                                                                                  // 1
    feildsCannotBeEdited = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  mentionMandatoryFields: function (v) {                                                                              // 1
    mentionMandatoryFields = v;                                                                                       // 1
  },                                                                                                                  // 1
  feildsCannotBeEdited: function (v) {                                                                                // 1
    feildsCannotBeEdited = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
var authentication = void 0;                                                                                          // 1
module.watch(require("../../Auth"), {                                                                                 // 1
  "default": function (v) {                                                                                           // 1
    authentication = v;                                                                                               // 1
  }                                                                                                                   // 1
}, 2);                                                                                                                // 1
var gamePricing = void 0;                                                                                             // 1
module.watch(require("../../../../collections/singleGamePricing"), {                                                  // 1
  "default": function (v) {                                                                                           // 1
    gamePricing = v;                                                                                                  // 1
  }                                                                                                                   // 1
}, 3);                                                                                                                // 1
// import  UserMaster from '../../../../collections/UserMaster';                                                      // 6
Router.route('/rest/v1/singleGames/makeABet', function () {                                                           // 9
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                        // 12
                                                                                                                      //
  if (this.request.method == 'POST') {                                                                                // 13
    var context = this,                                                                                               // 14
        Data = Utility.getRequestContents(context.request);                                                           // 14
    field = mentionMandatoryFields(Data, ['userId', 'token', 'coins', 'notes', 'bonusNotes']);                        // 16
                                                                                                                      //
    if (field) {                                                                                                      // 22
      Utility.response(context, 400, failResponse(field));                                                            // 24
    } else {                                                                                                          // 30
      var userId = Data.userId,                                                                                       // 30
          token = Data.token,                                                                                         // 30
          coins = Data.coins,                                                                                         // 30
          notes = Data.notes,                                                                                         // 30
          bonusNotes = Data.bonusNotes;                                                                               // 30
      coins = -Number(coins);                                                                                         // 32
      notes = -Number(notes);                                                                                         // 33
      bonusNotes = -Number(bonusNotes);                                                                               // 34
                                                                                                                      //
      var _authentication = authentication({                                                                          // 30
        userId: userId,                                                                                               // 35
        token: token                                                                                                  // 35
      }),                                                                                                             // 35
          authorise = _authentication.authorise,                                                                      // 30
          message = _authentication.message;                                                                          // 30
                                                                                                                      //
      if (authorise) {                                                                                                // 36
        UserMaster.updateGains(userId, coins, notes, bonusNotes);                                                     // 37
        Utility.response(context, 200, successResponse({                                                              // 38
          msg: 'Deduction done successfully'                                                                          // 42
        }));                                                                                                          // 41
      } else {                                                                                                        // 46
        Utility.response(context, 400, failResponse(message));                                                        // 47
      }                                                                                                               // 52
    }                                                                                                                 // 54
  } else {                                                                                                            // 57
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 58
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 62
    this.response.end('Set OPTIONS.');                                                                                // 63
  }                                                                                                                   // 64
}, {                                                                                                                  // 65
  where: 'server'                                                                                                     // 66
});                                                                                                                   // 66
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"saveGameResult.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/singleGames/saveGameResult.js                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _extends2 = require("babel-runtime/helpers/extends");                                                             //
                                                                                                                      //
var _extends3 = _interopRequireDefault(_extends2);                                                                    //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
var mentionMandatoryFields = void 0,                                                                                  // 1
    feildsCannotBeEdited = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  mentionMandatoryFields: function (v) {                                                                              // 1
    mentionMandatoryFields = v;                                                                                       // 1
  },                                                                                                                  // 1
  feildsCannotBeEdited: function (v) {                                                                                // 1
    feildsCannotBeEdited = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
var singleGames = void 0;                                                                                             // 1
module.watch(require("../../../../collections/singleGames"), {                                                        // 1
  "default": function (v) {                                                                                           // 1
    singleGames = v;                                                                                                  // 1
  }                                                                                                                   // 1
}, 2);                                                                                                                // 1
var authentication = void 0;                                                                                          // 1
module.watch(require("../../Auth"), {                                                                                 // 1
  "default": function (v) {                                                                                           // 1
    authentication = v;                                                                                               // 1
  }                                                                                                                   // 1
}, 3);                                                                                                                // 1
Router.route('/rest/v1/singleGames/saveGameResult', function () {                                                     // 8
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                        // 11
                                                                                                                      //
  if (this.request.method == 'POST') {                                                                                // 12
    var context = this,                                                                                               // 13
        Data = Utility.getRequestContents(context.request);                                                           // 13
    field = mentionMandatoryFields(Data, ['userId', 'token', 'priceRoomId', 'roomId', 'looserId', 'winnerId', 'winnerPots', 'looserPots', 'coins', 'notes', 'bonusNotes']);
                                                                                                                      //
    if (field) {                                                                                                      // 27
      Utility.response(context, 400, failResponse(field));                                                            // 29
    } else {                                                                                                          // 35
      var userId = Data.userId,                                                                                       // 35
          token = Data.token,                                                                                         // 35
          coins = Data.coins,                                                                                         // 35
          notes = Data.notes,                                                                                         // 35
          bonusNotes = Data.bonusNotes,                                                                               // 35
          winnerId = Data.winnerId;                                                                                   // 35
      coins = Number(coins);                                                                                          // 37
      notes = Number(notes);                                                                                          // 38
      bonusNotes = Number(bonusNotes);                                                                                // 39
      var matchesWon = void 0,                                                                                        // 40
          matchesLost = void 0;                                                                                       // 40
                                                                                                                      //
      var _authentication = authentication({                                                                          // 35
        userId: userId,                                                                                               // 41
        token: token                                                                                                  // 41
      }),                                                                                                             // 41
          authorise = _authentication.authorise,                                                                      // 35
          message = _authentication.message;                                                                          // 35
                                                                                                                      //
      if (authorise) {                                                                                                // 42
        var _userId = Data.userId,                                                                                    // 42
            roomId = Data.roomId,                                                                                     // 42
            looserId = Data.looserId,                                                                                 // 42
            priceRoomId = Data.priceRoomId;                                                                           // 42
        var game = singleGames.addSingleGame({                                                                        // 44
          winner: winnerId,                                                                                           // 44
          looserId: looserId,                                                                                         // 44
          photonRoomId: roomId                                                                                        // 44
        });                                                                                                           // 44
        game = singleGames.findOne({                                                                                  // 45
          _id: game                                                                                                   // 45
        });                                                                                                           // 45
        matchesWon = singleGames.find({                                                                               // 46
          winner: winnerId                                                                                            // 46
        }).count();                                                                                                   // 46
        matchesLost = singleGames.find({                                                                              // 47
          looserId: _userId                                                                                           // 47
        }).count();                                                                                                   // 47
        UserMaster.updateGains(winnerId, coins, notes, bonusNotes, 1);                                                // 48
        UserMaster.endStreak(looserId);                                                                               // 49
        var gains = UserMaster.findOne({                                                                              // 51
          userId: _userId                                                                                             // 51
        }, {                                                                                                          // 51
          fields: {                                                                                                   // 51
            coins: 1,                                                                                                 // 52
            notes: 1,                                                                                                 // 53
            bonusNotes: 1,                                                                                            // 54
            winningStreak: 1                                                                                          // 55
          }                                                                                                           // 51
        });                                                                                                           // 51
        game = (0, _extends3.default)({}, game, {                                                                     // 58
          matchesWon: matchesWon,                                                                                     // 59
          matchesLost: matchesLost,                                                                                   // 60
          coins: gains.coins,                                                                                         // 61
          notes: gains.notes,                                                                                         // 62
          bonusNotes: gains.bonusNotes,                                                                               // 63
          rank: 1,                                                                                                    // 64
          winPercent: singleGames.winningPercentage(_userId)                                                          // 65
        });                                                                                                           // 58
        Utility.response(context, 200, successResponse({                                                              // 68
          data: game                                                                                                  // 72
        }));                                                                                                          // 71
      } else {                                                                                                        // 76
        Utility.response(context, 400, failResponse(message));                                                        // 77
      }                                                                                                               // 82
    }                                                                                                                 // 84
  } else {                                                                                                            // 87
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 88
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 92
    this.response.end('Set OPTIONS.');                                                                                // 93
  }                                                                                                                   // 94
}, {                                                                                                                  // 95
  where: 'server'                                                                                                     // 96
});                                                                                                                   // 96
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"tournaments":{"getTournaments.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/tournaments/getTournaments.js                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var mentionMandatoryFields = void 0,                                                                                  // 1
    feildsCannotBeEdited = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  mentionMandatoryFields: function (v) {                                                                              // 1
    mentionMandatoryFields = v;                                                                                       // 1
  },                                                                                                                  // 1
  feildsCannotBeEdited: function (v) {                                                                                // 1
    feildsCannotBeEdited = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
Router.route('/rest/v1/tournaments/getTournaments', function () {                                                     // 5
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                        // 8
                                                                                                                      //
  if (this.request.method == 'POST') {                                                                                // 9
    var context = this,                                                                                               // 10
        Data = Utility.getRequestContents(context.request); // field = mentionMandatoryFields(Data, ['userId', 'token']);
    // if(field){                                                                                                     // 13
    //   Utility.response(                                                                                            // 14
    //     context,                                                                                                   // 15
    //     400,                                                                                                       // 16
    //     failResponse(field)                                                                                        // 17
    //   );                                                                                                           // 18
    // }else{                                                                                                         // 20
                                                                                                                      //
    var data = tournament.getAllTournaments();                                                                        // 22
    data.map(function (each) {                                                                                        // 23
      each.subFolders = tournamentSubFolder.getSubTournamentsByMainTournament(each._id);                              // 24
    });                                                                                                               // 25
    Utility.response(context, 200, successResponse({                                                                  // 27
      data: data                                                                                                      // 31
    })); // }                                                                                                         // 30
  } else {                                                                                                            // 38
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 39
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 43
    this.response.end('Set OPTIONS.');                                                                                // 44
  }                                                                                                                   // 45
}, {                                                                                                                  // 46
  where: 'server'                                                                                                     // 47
});                                                                                                                   // 47
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"user":{"addCoinsNotesOrBonusNotes.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/user/addCoinsNotesOrBonusNotes.js                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var mentionMandatoryFields = void 0,                                                                                  // 1
    feildsCannotBeEdited = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  mentionMandatoryFields: function (v) {                                                                              // 1
    mentionMandatoryFields = v;                                                                                       // 1
  },                                                                                                                  // 1
  feildsCannotBeEdited: function (v) {                                                                                // 1
    feildsCannotBeEdited = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
var singleGames = void 0;                                                                                             // 1
module.watch(require("../../../../collections/singleGames"), {                                                        // 1
  "default": function (v) {                                                                                           // 1
    singleGames = v;                                                                                                  // 1
  }                                                                                                                   // 1
}, 2);                                                                                                                // 1
var authentication = void 0;                                                                                          // 1
module.watch(require("../../Auth"), {                                                                                 // 1
  "default": function (v) {                                                                                           // 1
    authentication = v;                                                                                               // 1
  }                                                                                                                   // 1
}, 3);                                                                                                                // 1
Router.route('/rest/v1/user/addCoinsNotesOrBonusNotes', function () {                                                 // 8
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                        // 11
                                                                                                                      //
  if (this.request.method == 'POST') {                                                                                // 12
    var context = this,                                                                                               // 13
        Data = Utility.getRequestContents(context.request);                                                           // 13
    field = mentionMandatoryFields(Data, ['userId', 'token', 'coins', 'notes', 'bonusNotes']);                        // 15
                                                                                                                      //
    if (field) {                                                                                                      // 21
      Utility.response(context, 400, failResponse(field));                                                            // 23
    } else {                                                                                                          // 29
      var userId = Data.userId,                                                                                       // 29
          token = Data.token,                                                                                         // 29
          coins = Data.coins,                                                                                         // 29
          notes = Data.notes,                                                                                         // 29
          bonusNotes = Data.bonusNotes;                                                                               // 29
      coins = Number(coins);                                                                                          // 31
      notes = Number(notes);                                                                                          // 32
      bonusNotes = Number(bonusNotes);                                                                                // 33
      UserMaster.updateGains(userId, coins, notes, bonusNotes);                                                       // 34
      var gains = UserMaster.findOne({                                                                                // 36
        userId: userId                                                                                                // 36
      }, {                                                                                                            // 36
        fields: {                                                                                                     // 36
          coins: 1,                                                                                                   // 37
          notes: 1,                                                                                                   // 38
          bonusNotes: 1                                                                                               // 39
        }                                                                                                             // 36
      });                                                                                                             // 36
      Utility.response(context, 200, successResponse({                                                                // 43
        data: gains                                                                                                   // 47
      }));                                                                                                            // 46
    }                                                                                                                 // 53
  } else {                                                                                                            // 56
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 57
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 61
    this.response.end('Set OPTIONS.');                                                                                // 62
  }                                                                                                                   // 63
}, {                                                                                                                  // 64
  where: 'server'                                                                                                     // 65
});                                                                                                                   // 65
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"completeProfile1.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/user/completeProfile1.js                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var checkMandatoryFields = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  checkMandatoryFields: function (v) {                                                                                // 1
    checkMandatoryFields = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
Router.route('/rest/v1/user/completeProfile1', function () {                                                          // 5
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                        // 8
                                                                                                                      //
  if (this.request.method == 'POST') {                                                                                // 9
    var context = this,                                                                                               // 10
        Data = Utility.getRequestContents(context.request),                                                           // 10
        hasQuery = Utility.hasData(Data),                                                                             // 10
        validData = Utility.validate(Data, {                                                                          // 10
      userId: NonEmptyString,                                                                                         // 14
      token: NonEmptyString,                                                                                          // 15
      phoneNum: NonEmptyString,                                                                                       // 16
      gender: NonEmptyString,                                                                                         // 17
      dob: NonEmptyString,                                                                                            // 18
      maritalStatus: NonEmptyString //deviceInfo:Object                                                               // 19
                                                                                                                      //
    }),                                                                                                               // 13
        field = checkMandatoryFields(_.omit(Data, 'userId', 'token'));                                                // 10
                                                                                                                      //
    if (validData) {                                                                                                  // 23
      // Meteor.call('sendGCM','fgDnMNMDGx8:APA91bFD-JQrEcG4NPQaNLvvBhiv03t4V25H9z_ISfE6bJMlUag5W59wrpte3BB4UFLO40OMn4DJhGtOoClIj6nQ9eQcRBuUljR6A4ym0xbaJQXLNmUSVo4FyoiksxzSk4TBU7Wh3FnU');
      if (Data.phoneNum != '' && isPhoneNo(Data.phoneNum) == false) {                                                 // 26
        validData = false;                                                                                            // 27
        Utility.response(context, 400, failResponse('Please enter valid phone number along with countrycode.'));      // 28
      } else if (!Number(Data.dob)) {                                                                                 // 33
        Utility.response(context, 400, failResponse('Please enter a valid date of birth'));                           // 36
      } else if (!Number(Data.maritalStatus)) {                                                                       // 37
        Utility.response(context, 400, failResponse('Please enter a valid martial status'));                          // 40
      } else {                                                                                                        // 41
        var randomNum = Math.floor(Math.random() * 9000) + 1000;                                                      // 44
        var update = UserMaster.update({                                                                              // 45
          userId: Data.userId                                                                                         // 45
        }, {                                                                                                          // 45
          $set: {                                                                                                     // 45
            gender: Number(Data.gender),                                                                              // 45
            dob: Number(Data.dob),                                                                                    // 46
            phoneNum: Data.phoneNum,                                                                                  // 47
            code: randomNum,                                                                                          // 48
            firstTimeLogin: false,                                                                                    // 49
            maritalStatus: Number(Data.maritalStatus)                                                                 // 50
          }                                                                                                           // 45
        });                                                                                                           // 45
        var data = UserMaster.findOne({                                                                               // 52
          userId: Data.userId                                                                                         // 52
        });                                                                                                           // 52
                                                                                                                      //
        if (update) {                                                                                                 // 53
          sendSms(Data.phoneNum, randomNum);                                                                          // 54
          Utility.response(context, 200, successResponse({                                                            // 55
            data: data                                                                                                // 59
          }));                                                                                                        // 58
        } else {                                                                                                      // 62
          Utility.response(context, 400, failResponse('Technical Error'));                                            // 63
        }                                                                                                             // 70
      }                                                                                                               // 71
    } else {                                                                                                          // 72
      //console.log(Data)                                                                                             // 73
      Utility.response(context, 400, failResponse("Please fill " + field + " field"));                                // 74
    }                                                                                                                 // 75
  } else {                                                                                                            // 76
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 77
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 81
    this.response.end('Set OPTIONS.');                                                                                // 82
  }                                                                                                                   // 83
}, {                                                                                                                  // 84
  where: 'server'                                                                                                     // 85
});                                                                                                                   // 85
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"deleteUser.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/user/deleteUser.js                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var mentionMandatoryFields = void 0,                                                                                  // 1
    feildsCannotBeEdited = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  mentionMandatoryFields: function (v) {                                                                              // 1
    mentionMandatoryFields = v;                                                                                       // 1
  },                                                                                                                  // 1
  feildsCannotBeEdited: function (v) {                                                                                // 1
    feildsCannotBeEdited = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
Router.route('/rest/v1/user/deleteUser', function () {                                                                // 5
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                        // 8
                                                                                                                      //
  if (this.request.method == 'POST') {                                                                                // 9
    var context = this,                                                                                               // 10
        Data = Utility.getRequestContents(context.request),                                                           // 10
        field = mentionMandatoryFields(Data, ['email']);                                                              // 10
                                                                                                                      //
    if (field) {                                                                                                      // 13
      Utility.response(context, 400, failResponse(field));                                                            // 14
    } else {                                                                                                          // 20
      Data.email = Data.email.toLowerCase();                                                                          // 21
      var user = UserMaster.findOne({                                                                                 // 22
        email: Data.email                                                                                             // 22
      });                                                                                                             // 22
                                                                                                                      //
      if (user) {                                                                                                     // 23
        Meteor.users.remove({                                                                                         // 24
          _id: user.userId                                                                                            // 24
        });                                                                                                           // 24
        UserMaster.remove({                                                                                           // 25
          email: Data.email                                                                                           // 25
        });                                                                                                           // 25
        Utility.response(context, 200, successResponse({                                                              // 29
          msg: 'Profile deleted successfully'                                                                         // 33
        }));                                                                                                          // 32
      } else {                                                                                                        // 36
        Utility.response(context, 400, failResponse('emailId not found'));                                            // 37
      }                                                                                                               // 42
    }                                                                                                                 // 45
  } else {                                                                                                            // 48
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 49
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 53
    this.response.end('Set OPTIONS.');                                                                                // 54
  }                                                                                                                   // 55
}, {                                                                                                                  // 56
  where: 'server'                                                                                                     // 57
});                                                                                                                   // 57
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"editProfile.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/user/editProfile.js                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var mentionMandatoryFields = void 0,                                                                                  // 1
    feildsCannotBeEdited = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  mentionMandatoryFields: function (v) {                                                                              // 1
    mentionMandatoryFields = v;                                                                                       // 1
  },                                                                                                                  // 1
  feildsCannotBeEdited: function (v) {                                                                                // 1
    feildsCannotBeEdited = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
Router.route('/rest/v1/user/editProfile', function () {                                                               // 5
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                        // 8
                                                                                                                      //
  if (this.request.method == 'POST') {                                                                                // 9
    var context = this,                                                                                               // 10
        Data = Utility.getRequestContents(context.request),                                                           // 10
        field = mentionMandatoryFields(Data, ['userId', 'token']);                                                    // 10
                                                                                                                      //
    if (field) {                                                                                                      // 13
      Utility.response(context, 400, failResponse(field));                                                            // 14
    } else {                                                                                                          // 20
      var fieldsNotAllowed = feildsCannotBeEdited(Data, ['email', 'firstTimeLogin', 'isEmailVerified', 'isPhoneNumVerified', 'kycSubmitted', 'code', 'isActive', 'auth', '_id']);
                                                                                                                      //
      if (fieldsNotAllowed) {                                                                                         // 30
        Utility.response(context, 400, failResponse(fieldsNotAllowed));                                               // 31
        return;                                                                                                       // 36
      }                                                                                                               // 37
                                                                                                                      //
      if (Data.hasOwnProperty('phoneNum')) {                                                                          // 38
        if (Data.phoneNum != '' && isPhoneNo(Data.phoneNum) == false) {                                               // 39
          validData = false;                                                                                          // 40
          Utility.response(context, 400, failResponse('Please enter valid phone number along with countrycode.'));    // 41
          return;                                                                                                     // 46
        }                                                                                                             // 47
                                                                                                                      //
        var userData = UserMaster.findOne({                                                                           // 48
          userId: Data.userId                                                                                         // 48
        });                                                                                                           // 48
        var checkPhone = UserMaster.findOne({                                                                         // 49
          phoneNum: Data.phoneNum                                                                                     // 49
        });                                                                                                           // 49
                                                                                                                      //
        if (checkPhone && checkPhone.userId != Data.userId) {                                                         // 50
          Utility.response(context, 400, failResponse('Phone number already in use'));                                // 51
          return;                                                                                                     // 56
        }                                                                                                             // 57
                                                                                                                      //
        if (userData.phoneNum != Data.phoneNum) {                                                                     // 58
          var randomNum = Math.floor(Math.random() * 9000) + 1000;                                                    // 59
          sendSms(Data.phoneNum, randomNum);                                                                          // 60
          Data.code = randomNum;                                                                                      // 61
          Data.isPhoneNumVerified = false;                                                                            // 62
        } else {                                                                                                      // 64
          Utility.response(context, 400, failResponse('Phone number is same as before'));                             // 65
          return;                                                                                                     // 70
        }                                                                                                             // 71
      }                                                                                                               // 74
                                                                                                                      //
      if (Data.hasOwnProperty('gender')) {                                                                            // 75
        Data.gender = Number(Data.gender);                                                                            // 76
      }                                                                                                               // 77
                                                                                                                      //
      if (Data.hasOwnProperty('dob')) {                                                                               // 79
        Data.dob = Number(Data.dob);                                                                                  // 80
      }                                                                                                               // 81
                                                                                                                      //
      if (Data.hasOwnProperty('martialStatus')) {                                                                     // 83
        Data.martialStatus = Number(Data.martialStatus);                                                              // 84
      }                                                                                                               // 85
                                                                                                                      //
      if (Data.hasOwnProperty('addressProof') || Data.hasOwnProperty('passportNum') || Data.hasOwnProperty('idProof')) {
        Data.kycVerified = 0;                                                                                         // 90
        Data.updateAt = Date.now();                                                                                   // 91
      }                                                                                                               // 92
                                                                                                                      //
      delete Data.token;                                                                                              // 93
      var update = UserMaster.update({                                                                                // 95
        userId: Data.userId                                                                                           // 95
      }, {                                                                                                            // 95
        $set: Data                                                                                                    // 95
      });                                                                                                             // 95
      var data = UserMaster.findOne({                                                                                 // 97
        userId: Data.userId                                                                                           // 97
      });                                                                                                             // 97
                                                                                                                      //
      if (update) {                                                                                                   // 98
        Utility.response(context, 200, successResponse({                                                              // 99
          data: data,                                                                                                 // 103
          msg: 'Profile updated successfully'                                                                         // 104
        }));                                                                                                          // 102
      }                                                                                                               // 107
    }                                                                                                                 // 108
  } else {                                                                                                            // 111
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 112
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 116
    this.response.end('Set OPTIONS.');                                                                                // 117
  }                                                                                                                   // 118
}, {                                                                                                                  // 119
  where: 'server'                                                                                                     // 120
});                                                                                                                   // 120
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"forgotpwd.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/user/forgotpwd.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var checkMandatoryFields = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  checkMandatoryFields: function (v) {                                                                                // 1
    checkMandatoryFields = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var Email = void 0;                                                                                                   // 1
module.watch(require("meteor/email"), {                                                                               // 1
  Email: function (v) {                                                                                               // 1
    Email = v;                                                                                                        // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 2);                                                                                                                // 1
Router.route('/rest/v1/user/forgotpwd', function () {                                                                 // 5
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                        // 8
                                                                                                                      //
  if (this.request.method === 'POST') {                                                                               // 9
    var context = this,                                                                                               // 10
        feild = '',                                                                                                   // 10
        Data = Utility.getRequestContents(context.request),                                                           // 10
        hasQuery = Utility.hasData(Data),                                                                             // 10
        validData = Utility.validate(Data, {                                                                          // 10
      email: NonEmptyString                                                                                           // 15
    });                                                                                                               // 14
    field = checkMandatoryFields(Data);                                                                               // 18
                                                                                                                      //
    if (validData) {                                                                                                  // 20
      if (isEmail(Data.phoneNum) == false) {                                                                          // 21
        validData = false;                                                                                            // 22
        Utility.response(context, 400, failResponse('Please enter valid email address'));                             // 23
      } else {                                                                                                        // 28
        var UserData = UserMaster.findOne({                                                                           // 29
          email: Data.email                                                                                           // 29
        }); // let checkVerifiedUser = Meteor.users.findOne({ 'emails.verified': true })                              // 29
                                                                                                                      //
        console.log(UserData);                                                                                        // 31
                                                                                                                      //
        if (UserData) {                                                                                               // 32
          if (Data && hasQuery && validData) {                                                                        // 33
            var userId = UserData.userId; //console.log('userId ******** ', userId)                                   // 34
                                                                                                                      //
            Accounts.sendResetPasswordEmail(userId, Data.email);                                                      // 36
            Utility.response(context, 200, successResponse({                                                          // 37
              msg: 'An email is sent to your registered address.'                                                     // 40
            }));                                                                                                      // 40
          } else {                                                                                                    // 42
            Utility.response(context, 400, failResponse('Invalid email address'));                                    // 43
          }                                                                                                           // 44
        } else {                                                                                                      // 45
          Utility.response(context, 400, failResponse('Your email is not registered with us'));                       // 46
        }                                                                                                             // 47
      }                                                                                                               // 48
    } else {                                                                                                          // 49
      Utility.response(context, 400, failResponse("Please fill " + field + " field"));                                // 50
    }                                                                                                                 // 51
  } else {                                                                                                            // 52
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 53
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 57
    this.response.end('Set OPTIONS.'); //console.log(Data, hasQuery, validData);                                      // 58
  }                                                                                                                   // 60
}, {                                                                                                                  // 61
  where: 'server'                                                                                                     // 62
});                                                                                                                   // 62
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"login.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/user/login.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _extends2 = require("babel-runtime/helpers/extends");                                                             //
                                                                                                                      //
var _extends3 = _interopRequireDefault(_extends2);                                                                    //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
var checkMandatoryFields = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  checkMandatoryFields: function (v) {                                                                                // 1
    checkMandatoryFields = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0,                                                                                            // 1
    suspendedAccount = void 0;                                                                                        // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  },                                                                                                                  // 1
  suspendedAccount: function (v) {                                                                                    // 1
    suspendedAccount = v;                                                                                             // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
Router.route('/rest/v1/user/login', function () {                                                                     // 5
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                        // 8
                                                                                                                      //
  if (this.request.method == 'POST') {                                                                                // 9
    var context = this,                                                                                               // 10
        Data = Utility.getRequestContents(context.request),                                                           // 10
        hasQuery = Utility.hasData(Data),                                                                             // 10
        validData = Utility.validate(Data, {                                                                          // 10
      email: NonEmptyString,                                                                                          // 14
      // here email field is just a name of field which takes both phone number and email                             // 14
      password: NonEmptyString //deviceInfo: Object,                                                                  // 15
                                                                                                                      //
    }),                                                                                                               // 13
        field = checkMandatoryFields(Data); // if (!nesteddeviceInfoObject(Data.deviceInfo)) {                        // 10
    //   Utility.response(context, 400, failResponse('Device Information is not valid'));                             // 20
    // }                                                                                                              // 21
                                                                                                                      //
    if (validData) {                                                                                                  // 23
      if (!isEmail(Data.email)) {                                                                                     // 24
        Utility.response(context, 400, failResponse('Please enter valid email address.'));                            // 25
        return;                                                                                                       // 26
      } else {                                                                                                        // 27
        Data.email = Data.email.toLowerCase();                                                                        // 28
        var result = serverSideLogin(Data.email, Data.password);                                                      // 29
                                                                                                                      //
        if (result.error) {                                                                                           // 30
          Utility.response(context, 400, failResponse(result.message));                                               // 31
          return;                                                                                                     // 32
        } else {                                                                                                      // 33
          if (result.user.emails[0].verified) {                                                                       // 34
            // console.log(result.user._id)                                                                           // 35
            var userData = UserMaster.findOne({                                                                       // 36
              userId: result.user._id                                                                                 // 36
            });                                                                                                       // 36
            userData = (0, _extends3.default)({}, userData, {                                                         // 37
              matchesWon: 0,                                                                                          // 38
              matchesLost: 0,                                                                                         // 39
              totalWinnings: 19,                                                                                      // 40
              totalLosses: 10,                                                                                        // 41
              totalTournamentsWon: 2,                                                                                 // 42
              totalTournamentsLoss: 10,                                                                               // 43
              coins: userData.coins || 0,                                                                             // 44
              notes: userData.notes || 0,                                                                             // 45
              bonusNotes: userData.bonusNotes || 0,                                                                   // 46
              rank: 1,                                                                                                // 47
              winPercent: 50,                                                                                         // 48
              winningStreak: userData.winningStreak || 0,                                                             // 49
              BallsPotted: 10                                                                                         // 50
            });                                                                                                       // 37
            UserMaster.update({                                                                                       // 52
              userId: userData.userId                                                                                 // 52
            }, {                                                                                                      // 52
              $set: {                                                                                                 // 52
                isEmailVerified: true,                                                                                // 52
                firstTimeLogin: false                                                                                 // 52
              }                                                                                                       // 52
            });                                                                                                       // 52
            Utility.response(context, 200, successResponse({                                                          // 53
              data: userData                                                                                          // 53
            }));                                                                                                      // 53
          } else {                                                                                                    // 54
            Utility.response(context, 400, failResponse('This email is not verified with us.'));                      // 55
          }                                                                                                           // 56
        }                                                                                                             // 58
      } // let UserData = '';                                                                                         // 59
      // // if user has filled email, we get emailMatch                                                               // 61
      // emailMatch =                                                                                                 // 62
      //   UserMaster.findOne({ email: Data.email.toLowerCase() })                                                    // 63
      // if (emailMatch) {                                                                                            // 65
      //   // checking whether account is verified or not                                                             // 66
      //   if (emailMatch.isActive == 0) {                                                                            // 67
      //     Utility.response(context, 402, failResponse('Your account has been suspended'));                         // 68
      //   } else if (emailMatch.isVerified) {                                                                        // 69
      //     UserData = serverSideLogin(emailMatch.email.toLowerCase(), Data.password);                               // 70
      //   } else {                                                                                                   // 71
      //     UserData = '';                                                                                           // 72
      //     Utility.response(                                                                                        // 73
      //       context,                                                                                               // 74
      //       400,                                                                                                   // 75
      //       failResponse('Credentials does not exists Please go for Sign up process')                              // 76
      //     );                                                                                                       // 77
      //   }                                                                                                          // 78
      // } else {                                                                                                     // 79
      //   UserData = '';                                                                                             // 80
      // }                                                                                                            // 81
      // // checking if login function response is undefined,blank or error                                           // 82
      // if (!(UserData == '' || UserData == null || UserData.error)) {                                               // 83
      //   //console.log(UserData.user._id , "userdata is here")                                                      // 84
      //   UserMaster.generateToken(UserData.user._id);                                                               // 85
      //   // console.log(token);                                                                                     // 86
      //   // code to check whether a person is logged in and try to log in again.                                    // 87
      //   // console.log(loginInfo,"hahahh");                                                                        // 89
      //   UserMaster.saveDeviceInfoLogIn(                                                                            // 90
      //     UserData.user._id,                                                                                       // 91
      //     Data.deviceInfo.deviceType,                                                                              // 92
      //     Data.deviceInfo.deviceToken                                                                              // 93
      //   );                                                                                                         // 94
      //   let data = UserMaster.getUserData(Data.email);                                                             // 95
      //   //console.log('here is data****** ',data)                                                                  // 96
      // let userData = UserMaster.findOne({email:Data.email});                                                       // 98
      // let emailMatch = Meteor.users.findOne({'emails.address':Data.email})                                         // 99
      //   console.log('emailMatch ****** ',emailMatch.emails[0].verified)                                            // 100
      //   if (!isEmail(Data.email)) {                                                                                // 101
      //     validData = false;                                                                                       // 102
      //     Utility.response(context, 400, failResponse('Please enter valid email address.'));                       // 103
      //   }                                                                                                          // 104
      //   else if(userData.email != Data.email){                                                                     // 106
      //     Utility.response(context, 400, failResponse('This email is not registered with us.'));                   // 107
      //   }                                                                                                          // 108
      //   else if(emailMatch.emails[0].verified == false){                                                           // 110
      //     Utility.response(context, 400, failResponse('This email is not verified with us.'));                     // 111
      //   }                                                                                                          // 112
      //   else{                                                                                                      // 114
      //     Utility.response(                                                                                        // 115
      //       context,                                                                                               // 116
      //       200,                                                                                                   // 117
      //       successResponse({ msg: 'User logged in successfully', data: userData })                                // 118
      //     );                                                                                                       // 119
      //   }                                                                                                          // 120
                                                                                                                      //
    } else {                                                                                                          // 122
      // in case of invalid data                                                                                      // 123
      Utility.response(context, 400, failResponse("Please fill " + field + " field"));                                // 124
    }                                                                                                                 // 125
  } else {                                                                                                            // 126
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 127
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 131
    this.response.end('Set OPTIONS.');                                                                                // 132
  }                                                                                                                   // 133
}, {                                                                                                                  // 134
  where: 'server'                                                                                                     // 135
});                                                                                                                   // 135
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"resendOtp.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/user/resendOtp.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var checkMandatoryFields = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  checkMandatoryFields: function (v) {                                                                                // 1
    checkMandatoryFields = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
Router.route('/rest/v1/user/resendOtp', function () {                                                                 // 5
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                        // 8
                                                                                                                      //
  if (this.request.method == 'POST') {                                                                                // 9
    var context = this,                                                                                               // 10
        Data = Utility.getRequestContents(context.request),                                                           // 10
        hasQuery = Utility.hasData(Data),                                                                             // 10
        validData = Utility.validate(Data, {                                                                          // 10
      phoneNum: NonEmptyString                                                                                        // 14
    }),                                                                                                               // 13
        field = checkMandatoryFields(Data);                                                                           // 10
                                                                                                                      //
    if (validData) {                                                                                                  // 17
      var randomNum = Math.floor(Math.random() * 9000) + 1000,                                                        // 18
          userPhoneNumData = UserMaster.findOne({                                                                     // 18
        phoneNum: Data.phoneNum                                                                                       // 19
      });                                                                                                             // 19
                                                                                                                      //
      if (userPhoneNumData) {                                                                                         // 20
        sendSms(userPhoneNumData.phoneNum, randomNum);                                                                // 21
        UserMaster.update({                                                                                           // 22
          phoneNum: Data.phoneNum                                                                                     // 22
        }, {                                                                                                          // 22
          $set: {                                                                                                     // 22
            otp: randomNum                                                                                            // 22
          }                                                                                                           // 22
        });                                                                                                           // 22
        Utility.response(context, 200, successResponse({                                                              // 23
          msg: 'A verification code has been sent to your registered phone number.'                                   // 27
        }));                                                                                                          // 26
      } else {                                                                                                        // 30
        Utility.response(context, 400, failResponse('User does not exist'));                                          // 31
      }                                                                                                               // 32
    } else {                                                                                                          // 33
      Utility.response(context, 400, failResponse("Please fill " + field + " field"));                                // 34
    }                                                                                                                 // 35
  } else {                                                                                                            // 36
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 37
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 41
    this.response.end('Set OPTIONS.');                                                                                // 42
  }                                                                                                                   // 43
}, {                                                                                                                  // 44
  where: 'server'                                                                                                     // 45
});                                                                                                                   // 45
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"signUpWithBankAcc.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/user/signUpWithBankAcc.js                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var checkMandatoryFields = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  checkMandatoryFields: function (v) {                                                                                // 1
    checkMandatoryFields = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
Router.route('/rest/v1/user/signUpWithBankAcc', function () {                                                         // 5
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                        // 8
                                                                                                                      //
  if (this.request.method == 'POST') {                                                                                // 9
    var context = this,                                                                                               // 10
        Data = Utility.getRequestContents(context.request),                                                           // 10
        hasQuery = Utility.hasData(Data),                                                                             // 10
        validData = Utility.validate(Data, {                                                                          // 10
      userId: NonEmptyString,                                                                                         // 14
      idProof: MaybeEmptyString,                                                                                      // 15
      passportNum: MaybeEmptyString,                                                                                  // 16
      addressProof: MaybeEmptyString,                                                                                 // 17
      bankName: MaybeEmptyString,                                                                                     // 18
      accNum: MaybeEmptyString,                                                                                       // 19
      ifscNum: MaybeEmptyString                                                                                       // 20
    }),                                                                                                               // 13
        field = checkMandatoryFields(_.omit(Data, 'idProof', 'passportNum', 'addressProof', 'bankName', 'accNum', 'ifscNum', 'swiftCode', 'accountHolderName'));
    console.log('-----------', field);                                                                                // 23
                                                                                                                      //
    if (!field) {                                                                                                     // 24
      var userData = UserMaster.findOne({                                                                             // 25
        userId: Data.userId                                                                                           // 25
      });                                                                                                             // 25
      console.log('userdata ***** ', userData);                                                                       // 26
                                                                                                                      //
      if (Data.userId != userData.userId && userData == undefined) {                                                  // 27
        Utility.response(context, 400, failResponse('Invalid user or user id. Please check with your user details'));
      } else {                                                                                                        // 33
        if (Data.idProof != '' && Data.passportNum != '' && Data.addressProof != '' && Data.bankName != '' && Data.accNum != '' && Data.ifscNum != '') {
          UserMaster.update({                                                                                         // 36
            userId: Data.userId                                                                                       // 36
          }, {                                                                                                        // 36
            $set: {                                                                                                   // 36
              idProof: Data.idProof,                                                                                  // 37
              passportNum: Data.passportNum,                                                                          // 38
              addressProof: Data.addressProof,                                                                        // 39
              bankName: Data.bankName,                                                                                // 40
              accNum: Data.bankName,                                                                                  // 41
              ifscNum: Data.ifscNum,                                                                                  // 42
              kycSubmitted: true,                                                                                     // 43
              kycVerified: 0,                                                                                         // 44
              swiftCode: Data.swiftCode,                                                                              // 45
              accountHolderName: Data.accountHolderName,                                                              // 46
              updatedAt: Date.now()                                                                                   // 47
            }                                                                                                         // 36
          });                                                                                                         // 36
          Meteor.defer(function () {                                                                                  // 51
            Email.send({                                                                                              // 52
              to: 'testuser1.poolgame@gmail.com',                                                                     // 53
              from: 'notifications@PoolGame.com',                                                                     // 54
              subject: 'User added Kyc Information',                                                                  // 55
              html: "<p>Please check the link below to verify user<./p>\n                      <a href='https://www.uslenterprise.com/'>https://www.uslenterprise.com/</a>\n                      <br>\n                      <p>Regards,</p>\n                      <p>-PoolGame Notifications</p>"
            });                                                                                                       // 52
          });                                                                                                         // 63
        } //let data = UserMaster.findOne({userId:Data.userId})                                                       // 65
        else {                                                                                                        // 35
            UserMaster.update({                                                                                       // 69
              userId: Data.userId                                                                                     // 69
            }, {                                                                                                      // 69
              $set: {                                                                                                 // 70
                idProof: Data.idProof,                                                                                // 71
                passportNum: Data.passportNum,                                                                        // 72
                addressProof: Data.addressProof,                                                                      // 73
                bankName: Data.bankName,                                                                              // 74
                accNum: Data.bankName,                                                                                // 75
                ifscNum: Data.ifscNum                                                                                 // 76
              }                                                                                                       // 70
            });                                                                                                       // 69
          }                                                                                                           // 79
                                                                                                                      //
        userData = UserMaster.findOne({                                                                               // 80
          userId: Data.userId                                                                                         // 80
        });                                                                                                           // 80
        Utility.response(context, 200, successResponse({                                                              // 81
          msg: 'User account details updated successfully',                                                           // 85
          data: userData                                                                                              // 87
        }));                                                                                                          // 84
      }                                                                                                               // 90
    } else {                                                                                                          // 91
      //console.log(Data)                                                                                             // 92
      Utility.response(context, 400, failResponse("Please fill " + field + " field"));                                // 93
    }                                                                                                                 // 94
  } else {                                                                                                            // 95
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 96
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 100
    this.response.end('Set OPTIONS.');                                                                                // 101
  }                                                                                                                   // 102
}, {                                                                                                                  // 103
  where: 'server'                                                                                                     // 104
});                                                                                                                   // 104
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"signup.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/user/signup.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var checkMandatoryFields = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  checkMandatoryFields: function (v) {                                                                                // 1
    checkMandatoryFields = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
Router.route('/rest/v1/user/signUp', function () {                                                                    // 5
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                        // 8
                                                                                                                      //
  if (this.request.method == 'POST') {                                                                                // 9
    var context = this,                                                                                               // 10
        Data = Utility.getRequestContents(context.request),                                                           // 10
        hasQuery = Utility.hasData(Data),                                                                             // 10
        validData = Utility.validate(Data, {                                                                          // 10
      email: NonEmptyString,                                                                                          // 14
      password: NonEmptyString,                                                                                       // 15
      confirmPassword: NonEmptyString,                                                                                // 16
      fullName: NonEmptyString,                                                                                       // 17
      phoneNum: MaybeEmptyString,                                                                                     // 18
      gender: MaybeEmptyString,                                                                                       // 19
      dob: MaybeEmptyString,                                                                                          // 20
      maritalStatus: MaybeEmptyString //deviceInfo:Object                                                             // 21
                                                                                                                      //
    }),                                                                                                               // 13
        field = checkMandatoryFields(_.omit(Data, 'phoneNum', 'gender', 'dob', 'maritalStatus'));                     // 10
                                                                                                                      //
    if (validData) {                                                                                                  // 25
      // Meteor.call('sendGCM','fgDnMNMDGx8:APA91bFD-JQrEcG4NPQaNLvvBhiv03t4V25H9z_ISfE6bJMlUag5W59wrpte3BB4UFLO40OMn4DJhGtOoClIj6nQ9eQcRBuUljR6A4ym0xbaJQXLNmUSVo4FyoiksxzSk4TBU7Wh3FnU');
      if (!isEmail(Data.email)) {                                                                                     // 27
        validData = false;                                                                                            // 28
        Utility.response(context, 400, failResponse('Please enter valid email address'));                             // 29
      } else if (Data.phoneNum != '' && isPhoneNo(Data.phoneNum) == false) {                                          // 30
        validData = false;                                                                                            // 32
        Utility.response(context, 400, failResponse('Please enter valid phone number along with countrycode.'));      // 33
      } // else if (nestedPositionObject(Data.position) == false) {                                                   // 38
      //   validData = false;                                                                                         // 40
      //   Utility.response(context, 400, failResponse('Please enter a valid position'));                             // 41
      // }                                                                                                            // 42
      else if (Data.password != Data.confirmPassword) {                                                               // 31
          Utility.response(context, 400, failResponse('Passwords does not match'));                                   // 44
        } else if (Data.dob != '' && !isDob(Data.dob)) {                                                              // 45
          Utility.response(context, 400, failResponse('Please enter a valid date of birth'));                         // 48
        } else if (Data.gender != '' && !isGender(Data.gender)) {                                                     // 49
          Utility.response(context, 400, failResponse('Please enter a valid gender'));                                // 52
        } else if (Data.maritalStatus != '' && !isMartialStatus(Data.maritalStatus)) {                                // 53
          Utility.response(context, 400, failResponse('Please enter a valid martial status'));                        // 56
        } else {                                                                                                      // 57
          //     else if(!(nesteddeviceInfoObject(Data.deviceInfo)))                                                  // 60
          // {                                                                                                        // 61
          //      Utility.response(context, 200, failResponse('Device Information is not valid'));                    // 62
          // }                                                                                                        // 64
          //let userExists = Meteor.users.findOne({ 'emails.address': Data.email.toLowerCase() });                    // 65
          var checkUserEmail = UserMaster.findOne({                                                                   // 66
            email: Data.email.toLowerCase()                                                                           // 66
          });                                                                                                         // 66
          var checkUserPhoneNum = UserMaster.findOne({                                                                // 67
            phoneNum: Data.phoneNum                                                                                   // 67
          });                                                                                                         // 67
                                                                                                                      //
          if (!checkUserEmail) {                                                                                      // 69
            checkUserEmail = {};                                                                                      // 70
          }                                                                                                           // 71
                                                                                                                      //
          if (!checkUserPhoneNum) {                                                                                   // 72
            checkUserPhoneNum = {};                                                                                   // 73
            checkUserPhoneNum.email = '';                                                                             // 74
          } //let userExists = UserMaster.findOne({ email: Data.email.toLowerCase() });                               // 75
          //console.log('userExists ********* ',userExists)                                                           // 77
                                                                                                                      //
                                                                                                                      //
          if (checkUserEmail.email == Data.email) {                                                                   // 78
            Utility.response(context, 400, failResponse('This email address is already registered. Please try again with a different email address.'));
          } else if (checkUserPhoneNum.phoneNum == Data.phoneNum && Data.phoneNum != '') {                            // 86
            Utility.response(context, 400, failResponse('This phone number is already registered. Please try again with a different number.'));
          } else {                                                                                                    // 94
            //console.log(typeof(Data.favouriteFoods))                                                                // 96
            //Data.favouriteFoods = Data.favouriteFoods.split(",");                                                   // 97
            if (Data.phoneNum != '') {                                                                                // 98
              var randomNum = Math.floor(Math.random() * 9000) + 1000;                                                // 99
              sendSms(Data.phoneNum, randomNum);                                                                      // 100
            }                                                                                                         // 101
                                                                                                                      //
            accountId = Accounts.createUser({                                                                         // 103
              email: Data.email,                                                                                      // 104
              password: Data.password,                                                                                // 105
              profile: {                                                                                              // 106
                isActive: 1                                                                                           // 106
              }                                                                                                       // 106
            });                                                                                                       // 103
            var loginToken = Random.secret();                                                                         // 108
            Roles.addUsersToRoles(accountId, [1]);                                                                    // 109
            var data = {                                                                                              // 110
              userId: accountId,                                                                                      // 111
              auth: {                                                                                                 // 112
                token: loginToken,                                                                                    // 113
                date_created: Date.now()                                                                              // 114
              },                                                                                                      // 112
              //deviceInfo: Data.deviceInfo,                                                                          // 116
              fullName: Data.fullName,                                                                                // 117
              email: Data.email.toLowerCase(),                                                                        // 118
              //password: Data.password,                                                                              // 119
              // phoneNum: Data.phoneNum,                                                                             // 120
              // code: randomNum,''                                                                                   // 121
              phoneNum: Data.phoneNum ? Data.phoneNum : '',                                                           // 122
              gender: Data.gender ? Data.gender : '',                                                                 // 123
              dob: Data.dob ? Data.dob : '',                                                                          // 124
              maritalStatus: Data.maritalStatus ? Data.maritalStatus : '',                                            // 125
              firstTimeLogin: true,                                                                                   // 126
              isEmailVerified: false,                                                                                 // 127
              isPhoneNumVerified: false,                                                                              // 128
              kycSubmitted: false,                                                                                    // 129
              kycVerified: 0,                                                                                         // 130
              createdAt: Date.now(),                                                                                  // 131
              getNotification: 1,                                                                                     // 132
              isActive: 1,                                                                                            // 133
              idProof: Data.idProof,                                                                                  // 134
              coins: 100,                                                                                             // 135
              notes: 100,                                                                                             // 136
              bonusNotes: 100,                                                                                        // 137
              winningStreak: 0,                                                                                       // 138
              passportNum: "",                                                                                        // 139
              addressProof: "",                                                                                       // 140
              bankName: "",                                                                                           // 141
              accNum: "",                                                                                             // 142
              swiftCode: '',                                                                                          // 143
              accountHolderName: '',                                                                                  // 144
              ifscNum: ""                                                                                             // 145
            }; // Meteor.call('sendGCM','abc');                                                                       // 110
                                                                                                                      //
            console.log('before insert ******** ', data); /* save related data to masterCollection */ //Request.upsertUser(data);
                                                                                                                      //
            UserMaster.registerUser(data);                                                                            // 151
            Accounts.sendVerificationEmail(accountId); // Utility.response(                                           // 153
            //   context,                                                                                             // 156
            //   200,                                                                                                 // 157
            //   successResponse({                                                                                    // 158
            //     msg:                                                                                               // 159
            //       'An OTP has been sent to your mobile number to verify your account, please verify in order to complete your account signup',
            //   })                                                                                                   // 161
            // );                                                                                                     // 162
            //UserMaster.saveDeviceInfo(accountId, Data.deviceType, Data.gcmId, Data.deviceToken);                    // 165
                                                                                                                      //
            Utility.response(context, 200, successResponse({                                                          // 166
              msg: 'An email has been sent to your registered address, click on verification link in order to complete your account signup',
              data: data                                                                                              // 172
            }));                                                                                                      // 169
          }                                                                                                           // 175
        }                                                                                                             // 176
    } else {                                                                                                          // 177
      //console.log(Data)                                                                                             // 178
      Utility.response(context, 400, failResponse("Please fill " + field + " field"));                                // 179
    }                                                                                                                 // 180
  } else {                                                                                                            // 181
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 182
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 186
    this.response.end('Set OPTIONS.');                                                                                // 187
  }                                                                                                                   // 188
}, {                                                                                                                  // 189
  where: 'server'                                                                                                     // 190
});                                                                                                                   // 190
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"verify.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/user/verify.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var checkMandatoryFields = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  checkMandatoryFields: function (v) {                                                                                // 1
    checkMandatoryFields = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
//import { Email } from 'meteor/email';                                                                               // 5
Router.route('/rest/v1/user/verify', function () {                                                                    // 6
  this.response.setHeader('Access-Control-Allow-Origin', '*'); //SSR.compileTemplate('welcomeEmail', Assets.getText('emailOnVerification.html'));
                                                                                                                      //
  if (this.request.method == 'POST') {                                                                                // 11
    var context = this,                                                                                               // 12
        Data = Utility.getRequestContents(context.request),                                                           // 12
        hasQuery = Utility.hasData(Data),                                                                             // 12
        validData = Utility.validate(Data, {                                                                          // 12
      userId: NonEmptyString,                                                                                         // 16
      phoneNum: NonEmptyString,                                                                                       // 17
      otp: NonEmptyString                                                                                             // 18
    });                                                                                                               // 15
    field = checkMandatoryFields(Data); //console.log('data **** ', Data.otp)                                         // 20
                                                                                                                      //
    if (validData) {                                                                                                  // 22
      var requestData = UserMaster.findOne({                                                                          // 23
        userId: Data.userId                                                                                           // 23
      });                                                                                                             // 23
      console.log(requestData.code, Data.otp);                                                                        // 24
                                                                                                                      //
      if (requestData) {                                                                                              // 25
        if (requestData.phoneNum != Data.phoneNum) {                                                                  // 26
          Utility.response(context, 400, failResponse('Please enter your registered phone number'));                  // 27
        } else if (requestData.phoneNum == '') {                                                                      // 32
          Utility.response(context, 400, failResponse('This user has not added phone number while sign up'));         // 34
        } else if (requestData.code != Data.otp) {                                                                    // 39
          Utility.response(context, 400, failResponse('Please enter a valid OTP'));                                   // 41
        } else {                                                                                                      // 42
          UserMaster.update({                                                                                         // 45
            userId: Data.userId                                                                                       // 45
          }, {                                                                                                        // 45
            $set: {                                                                                                   // 45
              isPhoneNumVerified: true,                                                                               // 45
              code: ''                                                                                                // 45
            }                                                                                                         // 45
          });                                                                                                         // 45
          var data = UserMaster.findOne({                                                                             // 47
            userId: Data.userId                                                                                       // 47
          });                                                                                                         // 47
          Utility.response(context, 200, successResponse({                                                            // 49
            msg: 'Verified successfully',                                                                             // 52
            data: data                                                                                                // 52
          }));                                                                                                        // 52
        }                                                                                                             // 54
      } else {                                                                                                        // 55
        Utility.response(context, 400, failResponse('Please enter a valid Phone Number'));                            // 56
      }                                                                                                               // 57
    } else {                                                                                                          // 58
      //console.log(Data)                                                                                             // 59
      Utility.response(context, 400, failResponse("Please fill " + field + " field"));                                // 60
    }                                                                                                                 // 61
  } else {                                                                                                            // 62
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 63
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 67
    this.response.end('Set OPTIONS.');                                                                                // 68
  }                                                                                                                   // 69
}, {                                                                                                                  // 70
  where: 'server'                                                                                                     // 71
});                                                                                                                   // 71
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"v2":{"user":{"signup.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v2/user/signup.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var mentionMandatoryFields = void 0,                                                                                  // 1
    feildsCannotBeEdited = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  mentionMandatoryFields: function (v) {                                                                              // 1
    mentionMandatoryFields = v;                                                                                       // 1
  },                                                                                                                  // 1
  feildsCannotBeEdited: function (v) {                                                                                // 1
    feildsCannotBeEdited = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
Router.route('/rest/v2/user/signUp', function () {                                                                    // 5
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                        // 8
                                                                                                                      //
  if (this.request.method == 'POST') {                                                                                // 9
    var context = this,                                                                                               // 10
        Data = Utility.getRequestContents(context.request),                                                           // 10
        field = mentionMandatoryFields(Data, ['email', 'password', 'fullName']);                                      // 10
                                                                                                                      //
    if (field) {                                                                                                      // 13
      Utility.response(context, 400, failResponse(field));                                                            // 14
    } else {                                                                                                          // 20
      Data.email = Data.email.toLowerCase();                                                                          // 21
      var userExists = UserMaster.getUserData(Data.email);                                                            // 23
                                                                                                                      //
      if (userExists) {                                                                                               // 25
        Utility.response(context, 400, failResponse('This email address is already registered. Please try again with a different email address.'));
      } else {                                                                                                        // 33
        var accountId = Accounts.createUser({                                                                         // 34
          email: Data.email,                                                                                          // 35
          password: Data.password,                                                                                    // 36
          profile: {                                                                                                  // 37
            isActive: 1                                                                                               // 37
          }                                                                                                           // 37
        });                                                                                                           // 34
        Roles.addUsersToRoles(accountId, [1]);                                                                        // 39
        var loginToken = Random.secret();                                                                             // 40
        var data = {                                                                                                  // 42
          userId: accountId,                                                                                          // 43
          auth: {                                                                                                     // 44
            token: loginToken,                                                                                        // 45
            date_created: Date.now()                                                                                  // 46
          },                                                                                                          // 44
          deviceInfo: {                                                                                               // 48
            platform: '',                                                                                             // 48
            deviceToken: ''                                                                                           // 48
          },                                                                                                          // 48
          fullName: Data.fullName,                                                                                    // 49
          email: Data.email,                                                                                          // 50
          code: randomNum,                                                                                            // 51
          phoneNum: '',                                                                                               // 52
          gender: '',                                                                                                 // 53
          dob: '',                                                                                                    // 54
          maritalStatus: '',                                                                                          // 55
          firstTimeLogin: true,                                                                                       // 56
          isEmailVerified: false,                                                                                     // 57
          isPhoneNumVerified: false,                                                                                  // 58
          kycSubmitted: false,                                                                                        // 59
          createdAt: Date.now(),                                                                                      // 60
          getNotification: 1,                                                                                         // 61
          isActive: 1                                                                                                 // 62
        };                                                                                                            // 42
        UserMaster.registerUser(data);                                                                                // 65
        Accounts.sendVerificationEmail(accountId);                                                                    // 66
        Utility.response(context, 200, successResponse({                                                              // 68
          msg: 'An email has been sent to your registered address, click on verification link in order to complete your account signup',
          data: data                                                                                                  // 74
        }));                                                                                                          // 71
      }                                                                                                               // 77
    }                                                                                                                 // 78
  } else {                                                                                                            // 81
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 82
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 86
    this.response.end('Set OPTIONS.');                                                                                // 87
  }                                                                                                                   // 88
}, {                                                                                                                  // 89
  where: 'server'                                                                                                     // 90
});                                                                                                                   // 90
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"Auth.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/Auth.js                                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({                                                                                                       // 1
  "default": function () {                                                                                            // 1
    return authentication;                                                                                            // 1
  }                                                                                                                   // 1
});                                                                                                                   // 1
                                                                                                                      //
function authentication(_ref) {                                                                                       // 1
  var userId = _ref.userId,                                                                                           // 1
      token = _ref.token;                                                                                             // 1
                                                                                                                      //
  if (userId) {                                                                                                       // 3
    return Meteor.call('authentication', userId, token);                                                              // 4
  }                                                                                                                   // 5
                                                                                                                      //
  return {                                                                                                            // 7
    isActive: false,                                                                                                  // 7
    authorise: false,                                                                                                 // 7
    message: 'User not found'                                                                                         // 7
  };                                                                                                                  // 7
}                                                                                                                     // 8
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Payload.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/Payload.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
var Payload = function () {                                                                                           //
  function Payload() {                                                                                                //
    (0, _classCallCheck3.default)(this, Payload);                                                                     //
  }                                                                                                                   //
                                                                                                                      //
  Payload.getUserDataFromHeaders = function () {                                                                      //
    function getUserDataFromHeaders(data) {                                                                           //
      return {                                                                                                        // 3
        userId: data['x-user-id'],                                                                                    // 3
        token: data['x-auth-token']                                                                                   // 3
      };                                                                                                              // 3
    }                                                                                                                 // 4
                                                                                                                      //
    return getUserDataFromHeaders;                                                                                    //
  }();                                                                                                                //
                                                                                                                      //
  Payload.checkMandatoryFields = function () {                                                                        //
    function checkMandatoryFields(Data, fields) {                                                                     //
      var field = '';                                                                                                 // 7
      var i = 0;                                                                                                      // 8
                                                                                                                      //
      for (var each in meteorBabelHelpers.sanitizeForInObject(Data)) {                                                // 9
        /*checks which field is blank*/if (!Data[each]) {                                                             // 10
          field = each;                                                                                               // 12
        }                                                                                                             // 13
      }                                                                                                               // 14
                                                                                                                      //
      return field;                                                                                                   // 16
    }                                                                                                                 // 17
                                                                                                                      //
    return checkMandatoryFields;                                                                                      //
  }();                                                                                                                //
                                                                                                                      //
  Payload.mentionMandatoryFields = function () {                                                                      //
    function mentionMandatoryFields(Data, fields) {                                                                   //
      for (var i = 0; i < fields.length; i++) {                                                                       // 20
        if (!Data.hasOwnProperty([fields[i]]) || !Data[fields[i]]) {                                                  // 22
          return "Please enter " + fields[i];                                                                         // 23
        }                                                                                                             // 24
      }                                                                                                               // 25
    }                                                                                                                 // 26
                                                                                                                      //
    return mentionMandatoryFields;                                                                                    //
  }();                                                                                                                //
                                                                                                                      //
  Payload.feildsCannotBeEdited = function () {                                                                        //
    function feildsCannotBeEdited(Data, fields) {                                                                     //
      for (var i = 0; i < fields.length; i++) {                                                                       // 29
        if (Data.hasOwnProperty([fields[i]])) {                                                                       // 30
          return fields[i] + " cannot be edited";                                                                     // 31
        }                                                                                                             // 32
      }                                                                                                               // 33
    }                                                                                                                 // 34
                                                                                                                      //
    return feildsCannotBeEdited;                                                                                      //
  }();                                                                                                                //
                                                                                                                      //
  return Payload;                                                                                                     //
}();                                                                                                                  //
                                                                                                                      //
module.exports = Payload;                                                                                             // 40
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Response.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/Response.js                                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
/*                                                                                                                    // 1
                                                                                                                      //
this class manages the response structure of web services                                                             //
                                                                                                                      //
*/var Response = function () {                                                                                        //
  function Response() {                                                                                               //
    (0, _classCallCheck3.default)(this, Response);                                                                    //
  }                                                                                                                   //
                                                                                                                      //
  Response.successResponse = function () {                                                                            //
    function successResponse(resultObj) {                                                                             //
      //console.log('resultObj ****** ',resultObj.data)                                                               // 9
      return {                                                                                                        // 10
        success: true,                                                                                                // 11
        message: resultObj.msg,                                                                                       // 12
        statusCode: 200,                                                                                              // 13
        result: resultObj.data                                                                                        // 14
      };                                                                                                              // 10
    }                                                                                                                 // 16
                                                                                                                      //
    return successResponse;                                                                                           //
  }();                                                                                                                //
                                                                                                                      //
  Response.failResponse = function () {                                                                               //
    function failResponse(errorDesc) {                                                                                //
      // console.log(errorDesc)                                                                                       // 19
      return {                                                                                                        // 20
        success: false,                                                                                               // 21
        message: errorDesc,                                                                                           // 22
        //errorCode: Meteor.call('getMessagesCode', errorDesc),                                                       // 23
        statusCode: 400                                                                                               // 24
      };                                                                                                              // 20
    }                                                                                                                 // 26
                                                                                                                      //
    return failResponse;                                                                                              //
  }();                                                                                                                //
                                                                                                                      //
  Response.sessionExpired = function () {                                                                             //
    function sessionExpired(errorDesc) {                                                                              //
      return {                                                                                                        // 29
        success: false,                                                                                               // 30
        message: errorDesc,                                                                                           // 31
        errorCode: Meteor.call('getMessagesCode', errorDesc),                                                         // 32
        statusCode: 401                                                                                               // 33
      };                                                                                                              // 29
    }                                                                                                                 // 35
                                                                                                                      //
    return sessionExpired;                                                                                            //
  }();                                                                                                                //
                                                                                                                      //
  Response.suspendedAccount = function () {                                                                           //
    function suspendedAccount(errorDesc) {                                                                            //
      // console.log(errorDesc)                                                                                       // 38
      return {                                                                                                        // 39
        success: false,                                                                                               // 40
        message: errorDesc,                                                                                           // 41
        errorCode: Meteor.call('getMessagesCode', errorDesc),                                                         // 42
        statusCode: 402                                                                                               // 43
      };                                                                                                              // 39
    }                                                                                                                 // 45
                                                                                                                      //
    return suspendedAccount;                                                                                          //
  }();                                                                                                                //
                                                                                                                      //
  return Response;                                                                                                    //
}();                                                                                                                  //
                                                                                                                      //
module.exports = Response;                                                                                            // 48
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"middleware.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/middleware.js                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0,                                                                                            // 1
    sessionExpired = void 0,                                                                                          // 1
    suspendedAccount = void 0;                                                                                        // 1
module.watch(require("./Response"), {                                                                                 // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  },                                                                                                                  // 1
  sessionExpired: function (v) {                                                                                      // 1
    sessionExpired = v;                                                                                               // 1
  },                                                                                                                  // 1
  suspendedAccount: function (v) {                                                                                    // 1
    suspendedAccount = v;                                                                                             // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var authentication = void 0;                                                                                          // 1
module.watch(require("./Auth"), {                                                                                     // 1
  "default": function (v) {                                                                                           // 1
    authentication = v;                                                                                               // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
var getUserDataFromHeaders = void 0;                                                                                  // 1
module.watch(require("./Payload"), {                                                                                  // 1
  getUserDataFromHeaders: function (v) {                                                                              // 1
    getUserDataFromHeaders = v;                                                                                       // 1
  }                                                                                                                   // 1
}, 2);                                                                                                                // 1
// const authNotRequiredURL = [                                                                                       // 5
//   '/rest/v1/user/signUp',                                                                                          // 6
//   '/rest/v1/user/signUpWithBankAcc',                                                                               // 7
//   '/rest/v1/user/verify',                                                                                          // 8
//   '/rest/v1/user/resendOtp',                                                                                       // 9
//   '/rest/v1/files/upload',                                                                                         // 10
//   '/rest/v1/user/forgotpwd',                                                                                       // 11
//   '/rest/v1/user/login',                                                                                           // 12
// ];                                                                                                                 // 13
Router.configureBodyParsers();                                                                                        // 15
Router.onBeforeAction(function (req, res, next) {                                                                     // 17
  var context = this; // Data = getUserDataFromHeaders(req.body);                                                     // 18
                                                                                                                      //
  if (req.body.token) {                                                                                               // 21
    // console.log('authentication *****', req.body);                                                                 // 22
    var checkUser = authentication({                                                                                  // 24
      userId: req.body.userId,                                                                                        // 24
      token: req.body.token                                                                                           // 24
    });                                                                                                               // 24
    console.log(checkUser);                                                                                           // 25
                                                                                                                      //
    if (checkUser) {                                                                                                  // 26
      if (!checkUser.isActive) {                                                                                      // 27
        Utility.response(context, 402, suspendedAccount(checkUser.message));                                          // 28
      } else if (!checkUser.authorise) {                                                                              // 29
        Utility.response(context, 401, sessionExpired(checkUser.message));                                            // 30
      } else {                                                                                                        // 31
        this.next();                                                                                                  // 32
      }                                                                                                               // 33
    } else {                                                                                                          // 34
      Utility.response(context, 401, sessionExpired('userId is not provided '));                                      // 35
    }                                                                                                                 // 36
  } else {                                                                                                            // 37
    this.next();                                                                                                      // 38
  }                                                                                                                   // 39
});                                                                                                                   // 40
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utilities.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/utilities.js                                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/*Utilities for rest services*/Utility = {                                                                            // 1
  getRequestContents: function (request) {                                                                            // 4
    switch (request.method) {                                                                                         // 5
      case 'GET':                                                                                                     // 6
        return _.omit(request.query, '__proto__');                                                                    // 7
                                                                                                                      //
      case 'POST':                                                                                                    // 8
        return _.omit(request.body, '__proto__');                                                                     // 9
                                                                                                                      //
      case 'PUT':                                                                                                     // 10
        return _.omit(request.body, '__proto__');                                                                     // 11
                                                                                                                      //
      case 'DELETE':                                                                                                  // 12
        return _.omit(request.body, '__proto__');                                                                     // 13
    }                                                                                                                 // 5
  },                                                                                                                  // 15
  hasData: function (data) {                                                                                          // 16
    return Object.keys(data).length > 0 ? true : false;                                                               // 17
  },                                                                                                                  // 18
  response: function (context, statusCode, data) {                                                                    // 19
    statusCode = statusCode; // ----------------------------------------------------                                  // 20
                                                                                                                      //
    context.response.setHeader('Content-Type', 'application/json');                                                   // 22
    context.response.statusCode = statusCode;                                                                         // 23
    context.response.end(JSON.stringify(data));                                                                       // 24
  },                                                                                                                  // 25
  validate: function (data, pattern) {                                                                                // 26
    return Match.test(data, pattern);                                                                                 // 27
  }                                                                                                                   // 28
};                                                                                                                    // 3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"configs":{"smtpsettings.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/configs/smtpsettings.js                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
smtp = {                                                                                                              // 1
  username: 'rishiankush',                                                                                            // 2
  password: 'Hello@1a',                                                                                               // 3
  //igniva@3197                                                                                                       // 3
  secure: false,                                                                                                      // 4
  port: 2525,                                                                                                         // 5
  server: 'mail.smtp2go.com'                                                                                          // 6
};                                                                                                                    // 1
process.env.MAIL_URL = 'smtp://' + encodeURIComponent(smtp.username) + ':' + encodeURIComponent(smtp.password) + '@' + encodeURIComponent(smtp.server) + ':' + smtp.port; // By default, the email is sent from no-reply@meteor.com. If you wish to receive email from users asking for help with their account, be sure to set this to an email address that you can receive email at.
                                                                                                                      //
Accounts.emailTemplates.from = '<notifications@PoolGame.com>'; // The public name of your application.                // 20
                                                                                                                      //
Accounts.emailTemplates.siteName = 'PoolGame';                                                                        // 23
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"twilioSettings.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/configs/twilioSettings.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var twilio = void 0;                                                                                                  // 1
module.watch(require("twilio"), {                                                                                     // 1
  "default": function (v) {                                                                                           // 1
    twilio = v;                                                                                                       // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
sms = {                                                                                                               // 6
  accountSid: 'AC70c72bb8ed046cd6a1e461803309ed53',                                                                   // 7
  authToken: '8feb561cabe04896c981cdc8cd97d9c8'                                                                       // 8
};                                                                                                                    // 6
var client = new twilio(sms.accountSid, sms.authToken); //console.log(new twilio(sms.accountSid, sms.authToken))      // 11
//console.log(client)                                                                                                 // 14
                                                                                                                      //
sendSms = function (phoneNum, randomNum) {                                                                            // 15
  client.messages.create({                                                                                            // 16
    body: 'PoolGame one time password:' + randomNum,                                                                  // 18
    to: phoneNum,                                                                                                     // 19
    from: '+16062631146'                                                                                              // 20
  }).then(function (message, err) {                                                                                   // 17
    if (!err) {                                                                                                       // 23
      console.log(message);                                                                                           // 24
    } else {                                                                                                          // 25
      console.log(err);                                                                                               // 26
    }                                                                                                                 // 27
  });                                                                                                                 // 28
}; // customMessage = (phoneNum, body) => {                                                                           // 29
//   client                                                                                                           // 31
//     .sendSms({                                                                                                     // 32
//       body: body,                                                                                                  // 33
//       to: phoneNum,                                                                                                // 34
//       from: '+12243863041',                                                                                        // 35
//     })                                                                                                             // 36
//     .then((message, err) => {                                                                                      // 37
//       if (!err) {                                                                                                  // 38
//         console.log(message);                                                                                      // 39
//       } else {                                                                                                     // 40
//         console.log(err);                                                                                          // 41
//       }                                                                                                            // 42
//     });                                                                                                            // 43
// };                                                                                                                 // 44
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods":{"Counter.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/methods/Counter.js                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Meteor.methods({                                                                                                      // 1
  getNextSequence: function (colName) {                                                                               // 2
    this.unblock();                                                                                                   // 3
    Counter.upsert({                                                                                                  // 5
      _id: colName                                                                                                    // 6
    }, {                                                                                                              // 6
      $inc: {                                                                                                         // 8
        seq: 1                                                                                                        // 9
      },                                                                                                              // 8
      $set: {                                                                                                         // 11
        date_updated: new Date()                                                                                      // 12
      },                                                                                                              // 11
      $setOnInsert: {                                                                                                 // 14
        date_created: new Date()                                                                                      // 15
      }                                                                                                               // 14
    });                                                                                                               // 7
    return Counter.findOne({                                                                                          // 20
      _id: colName                                                                                                    // 20
    }).seq;                                                                                                           // 20
  }                                                                                                                   // 21
});                                                                                                                   // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"SystemMessages.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/methods/SystemMessages.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Meteor.methods({                                                                                                      // 1
  getMessagesCode: function (text) {                                                                                  // 2
    this.unblock();                                                                                                   // 3
    var message = SystemMessages.findOne({                                                                            // 5
      message: text                                                                                                   // 5
    });                                                                                                               // 5
    if (message) return message.code;else {                                                                           // 6
      SystemMessages.insert({                                                                                         // 8
        message: text,                                                                                                // 9
        code: Meteor.call('getNextSequence', 'SystemMessages'),                                                       // 10
        date_created: new Date()                                                                                      // 11
      });                                                                                                             // 8
      return SystemMessages.findOne({                                                                                 // 14
        message: text                                                                                                 // 14
      }).code;                                                                                                        // 14
    }                                                                                                                 // 15
  }                                                                                                                   // 16
});                                                                                                                   // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Users.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/methods/Users.js                                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Meteor.methods({                                                                                                      // 1
  authentication: function (userId, token) {                                                                          // 2
    //let UserData = Meteor.users.findOne({ _id: userId });                                                           // 3
    var UserData = UserMaster.findOne({                                                                               // 4
      userId: userId                                                                                                  // 4
    });                                                                                                               // 4
    var activeUser = UserData ? UserData.isActive : false;                                                            // 5
    console.log('in method', userId, token);                                                                          // 7
                                                                                                                      //
    if (UserData) {                                                                                                   // 9
      // if (!UserData.profile.isActive) {                                                                            // 10
      if (!activeUser) {                                                                                              // 11
        return {                                                                                                      // 12
          isActive: activeUser,                                                                                       // 13
          authorise: false,                                                                                           // 14
          message: 'Your account has been suspended'                                                                  // 15
        };                                                                                                            // 12
      } else if (UserMaster.checkToken(token, userId) && UserData.isActive) {                                         // 17
        //Meteor.call('setUserLastActivityTime', userId);                                                             // 18
        return {                                                                                                      // 19
          isActive: activeUser,                                                                                       // 19
          authorise: true,                                                                                            // 19
          message: 'Authentication Pass'                                                                              // 19
        };                                                                                                            // 19
      } else {                                                                                                        // 20
        return {                                                                                                      // 21
          isActive: activeUser,                                                                                       // 21
          authorise: false,                                                                                           // 21
          message: 'Session Expired'                                                                                  // 21
        };                                                                                                            // 21
      }                                                                                                               // 22
    } else {                                                                                                          // 23
      return {                                                                                                        // 24
        isActive: activeUser,                                                                                         // 24
        authorise: false,                                                                                             // 24
        message: 'User not found'                                                                                     // 24
      };                                                                                                              // 24
    }                                                                                                                 // 25
  },                                                                                                                  // 26
  // setUserLastActivityTime: function(userId) {                                                                      // 28
  //   this.unblock();                                                                                                // 29
  //   UserMaster.setUserLastActivityTime(userId);                                                                    // 31
  // },                                                                                                               // 32
  serverTime: function () {                                                                                           // 34
    return Date.now();                                                                                                // 35
  }                                                                                                                   // 36
});                                                                                                                   // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"adminMethods.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/methods/adminMethods.js                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Meteor.methods({                                                                                                      // 1
	verifyKYC: function (userId, status) {                                                                               // 2
		return UserMaster.update({                                                                                          // 3
			userId: userId                                                                                                     // 3
		}, {                                                                                                                // 3
			$set: {                                                                                                            // 3
				kycVerified: status                                                                                               // 3
			}                                                                                                                  // 3
		});                                                                                                                 // 3
	},                                                                                                                   // 4
	createTournament: function (Data) {                                                                                  // 5
		var mainFolder = void 0;                                                                                            // 6
		var tournamentExists = tournament.serchByTitle(Data.mainFolder);                                                    // 7
                                                                                                                      //
		if (tournamentExists) {// register new sub folder                                                                   // 8
		} else {                                                                                                            // 10
			tournamentExists = tournament.registerTournament(Data.mainFolder);                                                 // 11
		}                                                                                                                   // 12
                                                                                                                      //
		console.log('tournamentExists', tournamentExists);                                                                  // 13
                                                                                                                      //
		if (tournamentExists) {                                                                                             // 14
			// register sub folder                                                                                             // 15
			if (tournamentSubFolder.registerSubFolder({                                                                        // 16
				title: Data.subFolder,                                                                                            // 17
				mainFolder: tournamentExists,                                                                                     // 18
				waitForPlayer: Data.waitForPlayer,                                                                                // 19
				regStartTime: Data.regStartTime,                                                                                  // 20
				regEndTime: Data.regStartTime,                                                                                    // 21
				regEndTime: Data.regEndTime,                                                                                      // 22
				matchEndTime: Data.matchEndTime,                                                                                  // 23
				recursivePlay: Data.recursivePlay,                                                                                // 24
				ticketTournament: Data.ticketTournament,                                                                          // 25
				country: Data.country,                                                                                            // 26
				city: Data.city,                                                                                                  // 27
				gateEntryCoinAmount: Data.gateEntryCoinAmount,                                                                    // 28
				gateEntryNotesAmount: Data.gateEntryNotesAmount,                                                                  // 29
				gateEntryTicketAmount: Data.gateEntryTicketAmount,                                                                // 30
				winnerCoins: Data.winnerCoins,                                                                                    // 31
				winnerNotes: Data.winnerNotes,                                                                                    // 32
				winnerTicket: Data.winnerTicket,                                                                                  // 33
				runnerUpCoins: Data.runnerUpCoins,                                                                                // 34
				runnerUpNotes: Data.runnerUpNotes,                                                                                // 35
				runnerUpTicket: Data.runnerUpTicket,                                                                              // 36
				looserCoins: Data.looserCoins,                                                                                    // 37
				looserNotes: Data.looserNotes,                                                                                    // 38
				round0Notes: Data.round0Notes,                                                                                    // 39
				round1Notes: Data.round1Notes,                                                                                    // 40
				round2Notes: Data.round2Notes,                                                                                    // 41
				round3Notes: Data.round3Notes,                                                                                    // 42
				round4Notes: Data.round4Notes,                                                                                    // 43
				round0Coins: Data.round0Coins,                                                                                    // 44
				round1Coins: Data.round1Coins,                                                                                    // 45
				round2Coins: Data.round2Coins,                                                                                    // 46
				round3Coins: Data.round3Coins,                                                                                    // 47
				round4Coins: Data.round4Coins,                                                                                    // 48
				createdBy: Date.now()                                                                                             // 49
			})) {                                                                                                              // 16
				return true;                                                                                                      // 51
			}                                                                                                                  // 52
		} else {                                                                                                            // 53
			return false;                                                                                                      // 54
		}                                                                                                                   // 55
	},                                                                                                                   // 56
	setSingleGameScore: function (_id, deduction) {                                                                      // 58
		return gamePricing.editGameDeductions(_id, deduction);                                                              // 59
	}                                                                                                                    // 60
});                                                                                                                   // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"emailConfig.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/methods/emailConfig.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Accounts.emailTemplates.resetPassword.text = function (user, url) {                                                   // 1
  url = url.replace("#/", "");                                                                                        // 2
  var uName = user.profile.name,                                                                                      // 3
      msg = 'Your Credentials -\n-----------------------\nemail: ' + user.emails + '\npassword: ' + user.password + '\n\nTo reset your account password click on the following link. \n',
      from = '\n\n\nThank you! \n\nThe PoolGame Team. \n';                                                            // 3
  return 'Hello ' + uName + ', \n\n' + msg + url + from + Meteor.absoluteUrl() + '\n';                                // 12
};                                                                                                                    // 13
                                                                                                                      //
Accounts.emailTemplates.verifyEmail.subject = function (user, url) {                                                  // 15
  return 'Pool Game Verification Link';                                                                               // 16
};                                                                                                                    // 17
                                                                                                                      //
Accounts.emailTemplates.verifyEmail.text = function (user, url) {                                                     // 19
  url = url.replace("#/", ""); //url = url.replace('-', '')                                                           // 20
                                                                                                                      //
  name = UserMaster.findOne({                                                                                         // 22
    userId: user._id                                                                                                  // 22
  }).fullName;                                                                                                        // 22
  return " Hi " + name + "\n\nPlease click on the below verification link to activate your account:\n\n" + url + "\n\n Regards,\nnotifications@PoolGame.com";
};                                                                                                                    // 30
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"publications":{"publications.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/publications/publications.js                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Meteor.publish('users', function () {                                                                                 // 1
  return Meteor.users.find();                                                                                         // 2
});                                                                                                                   // 3
Meteor.publish('UsersList', function () {                                                                             // 5
  return UserMaster.find({});                                                                                         // 6
});                                                                                                                   // 7
Meteor.publish('gamePricings', function () {                                                                          // 9
  return gamePricing.find({});                                                                                        // 10
});                                                                                                                   // 11
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"main.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Meteor = void 0;                                                                                                  // 1
module.watch(require("meteor/meteor"), {                                                                              // 1
  Meteor: function (v) {                                                                                              // 1
    Meteor = v;                                                                                                       // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
Meteor.startup(function () {                                                                                          // 3
  // code to run on server at startup                                                                                 // 4
  // console.log(UserMaster.findOne({userId: 'vSAxTps8TqSbYARm9'}))                                                   // 5
  // let account = Accounts.createUser({username:'superAdmin',password:'admin@123'});                                 // 6
  // // console.log('account',account);                                                                               // 7
  // Roles.addUsersToRoles(account, ['superAdmin']);                                                                  // 8
  var pricings = [{                                                                                                   // 9
    price: 10000,                                                                                                     // 11
    deduction: 3000,                                                                                                  // 12
    type: 1,                                                                                                          // 13
    createdAt: Date.now(),                                                                                            // 14
    updatedAt: Date.now()                                                                                             // 15
  }, {                                                                                                                // 10
    price: 50000,                                                                                                     // 18
    deduction: 15000,                                                                                                 // 19
    type: 1,                                                                                                          // 20
    createdAt: Date.now(),                                                                                            // 21
    updatedAt: Date.now()                                                                                             // 22
  }, {                                                                                                                // 17
    price: 25000,                                                                                                     // 25
    deduction: 50,                                                                                                    // 26
    type: 1,                                                                                                          // 27
    createdAt: Date.now(),                                                                                            // 28
    updatedAt: Date.now()                                                                                             // 29
  }]; // pricings.forEach(each => {                                                                                   // 24
  // 	gamePricing.insert(each)                                                                                        // 35
  //   console.log('type added');                                                                                     // 36
  // });                                                                                                              // 37
});                                                                                                                   // 38
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections":{"Collection.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// collections/Collection.js                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
SystemMessages = new Mongo.Collection("SystemMessages");                                                              // 1
Counter = new Mongo.Collection("Counter");                                                                            // 3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Files.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// collections/Files.js                                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
FS.HTTP.setBaseUrl('/store');                                                                                         // 1
var imageStore = new FS.Store.GridFS("image", {                                                                       // 3
    beforeWrite: function (fileObj) {                                                                                 // 4
        return {                                                                                                      // 5
            'name': slugify(Date.now() + ' ' + fileObj.original.name)                                                 // 6
        };                                                                                                            // 5
    }                                                                                                                 // 8
});                                                                                                                   // 3
var thumbStore = new FS.Store.GridFS("thumb", {                                                                       // 11
    beforeWrite: function (fileObj) {                                                                                 // 12
        if (fileObj.isImage()) {                                                                                      // 13
            return {                                                                                                  // 14
                'name': slugify(Date.now() + ' ' + fileObj.original.name),                                            // 15
                'extension': 'png',                                                                                   // 16
                'type': 'image/png'                                                                                   // 17
            };                                                                                                        // 14
        } else return false;                                                                                          // 19
    },                                                                                                                // 20
    transformWrite: function (fileObj, readStream, writeStream) {                                                     // 21
        var size = 96;                                                                                                // 22
                                                                                                                      //
        if (gm.isAvailable) {                                                                                         // 24
            if (fileObj.isImage()) {                                                                                  // 25
                gm(readStream).autoOrient().resize(size, size + '^').gravity('Center').extent(size, size).stream('PNG').pipe(writeStream);
            } else {                                                                                                  // 33
                // console.log('File is not Image/Video.');                                                           // 34
                return false;                                                                                         // 35
            }                                                                                                         // 36
        } else {                                                                                                      // 37
            console.log('graphicsmagick or imagemagick not available on the system');                                 // 38
            return false;                                                                                             // 39
        }                                                                                                             // 40
    }                                                                                                                 // 41
});                                                                                                                   // 11
Files = new FS.Collection('uploads', {                                                                                // 44
    stores: [imageStore, thumbStore]                                                                                  // 45
});                                                                                                                   // 44
Files.allow({                                                                                                         // 48
    insert: function (userId, doc) {                                                                                  // 49
        return true;                                                                                                  // 50
    },                                                                                                                // 51
    update: function (userId, doc, fieldNames, modifier) {                                                            // 52
        return true;                                                                                                  // 53
    },                                                                                                                // 54
    remove: function (userId, doc) {                                                                                  // 55
        return true;                                                                                                  // 56
    },                                                                                                                // 57
    download: function (userId, fileObj) {                                                                            // 58
        return true;                                                                                                  // 59
    }                                                                                                                 // 60
});                                                                                                                   // 48
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"RequestCollection.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// collections/RequestCollection.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
/*                                                                                                                    // 1
Request collection is a kind of additional collection in which data of unverified user is stored.                     //
After the user is verified, data from this collection is remived and added in main collection i.e                     //
UserMaster collection.                                                                                                //
*/var RequestCollection = function (_Mongo$Collection) {                                                              //
    (0, _inherits3.default)(RequestCollection, _Mongo$Collection);                                                    //
                                                                                                                      //
    function RequestCollection() {                                                                                    //
        (0, _classCallCheck3.default)(this, RequestCollection);                                                       //
        return (0, _possibleConstructorReturn3.default)(this, _Mongo$Collection.apply(this, arguments));              //
    }                                                                                                                 //
                                                                                                                      //
    RequestCollection.prototype.registerUser = function () {                                                          //
        function registerUser(data) {                                                                                 //
            /* save related data to RequestCollection */return _Mongo$Collection.prototype.insert.call(this, data);   // 9
        }                                                                                                             // 11
                                                                                                                      //
        return registerUser;                                                                                          //
    }(); // upsert user for Request collection                                                                        //
                                                                                                                      //
                                                                                                                      //
    RequestCollection.prototype.upsertUser = function () {                                                            //
        function upsertUser(Data) {                                                                                   //
            console.log(Data, "%%%%%%%%%%%%%%%");                                                                     // 15
                                                                                                                      //
            var checkEmail = _Mongo$Collection.prototype.findOne.call(this, {                                         // 16
                email: Data.email                                                                                     // 16
            }),                                                                                                       // 16
                checkPhone = _Mongo$Collection.prototype.findOne.call(this, {                                         // 16
                phoneNum: Data.phoneNum                                                                               // 17
            }); // console.log(checkPhone, "check phoene is hereeeeee");                                              // 17
            // console.log(checkEmail, "check email is hereeeeee")                                                    // 19
                                                                                                                      //
                                                                                                                      //
            if (checkEmail) {                                                                                         // 20
                return _Mongo$Collection.prototype.update.call(this, {                                                // 21
                    email: Data.email                                                                                 // 22
                }, Data, {                                                                                            // 21
                    upsert: true                                                                                      // 23
                });                                                                                                   // 23
            } else if (checkPhone) {                                                                                  // 24
                return _Mongo$Collection.prototype.update.call(this, {                                                // 25
                    phoneNum: Data.phoneNum                                                                           // 26
                }, Data, {                                                                                            // 25
                    upsert: true                                                                                      // 27
                });                                                                                                   // 27
            } else {                                                                                                  // 28
                return _Mongo$Collection.prototype.update.call(this, {                                                // 29
                    email: Data.email,                                                                                // 30
                    phoneNum: Data.phoneNum                                                                           // 31
                }, Data, {                                                                                            // 29
                    upsert: true                                                                                      // 32
                });                                                                                                   // 32
            }                                                                                                         // 33
        }                                                                                                             // 34
                                                                                                                      //
        return upsertUser;                                                                                            //
    }();                                                                                                              //
                                                                                                                      //
    return RequestCollection;                                                                                         //
}(Mongo.Collection);                                                                                                  //
                                                                                                                      //
Request = new RequestCollection("Request");                                                                           // 37
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"UserMaster.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// collections/UserMaster.js                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
var MasterCollection = function (_Mongo$Collection) {                                                                 //
    (0, _inherits3.default)(MasterCollection, _Mongo$Collection);                                                     //
                                                                                                                      //
    function MasterCollection() {                                                                                     //
        (0, _classCallCheck3.default)(this, MasterCollection);                                                        //
        return (0, _possibleConstructorReturn3.default)(this, _Mongo$Collection.apply(this, arguments));              //
    }                                                                                                                 //
                                                                                                                      //
    MasterCollection.prototype.registerUser = function () {                                                           //
        function registerUser(data) {                                                                                 //
            /* save related data to masterCollection */return _Mongo$Collection.prototype.insert.call(this, data);    // 4
        }                                                                                                             // 6
                                                                                                                      //
        return registerUser;                                                                                          //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.getUserLoacation = function () {                                                       //
        function getUserLoacation(userId) {                                                                           //
            return _Mongo$Collection.prototype.findOne.call(this, {                                                   // 9
                userId: userId                                                                                        // 9
            }).location;                                                                                              // 9
        }                                                                                                             // 10
                                                                                                                      //
        return getUserLoacation;                                                                                      //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.generateToken = function () {                                                          //
        function generateToken(id) {                                                                                  //
            return _Mongo$Collection.prototype.update.call(this, {                                                    // 13
                userId: id                                                                                            // 13
            }, {                                                                                                      // 13
                $set: {                                                                                               // 14
                    auth: {                                                                                           // 15
                        token: Random.secret(),                                                                       // 16
                        date_created: Date.now()                                                                      // 17
                    }                                                                                                 // 15
                }                                                                                                     // 14
            });                                                                                                       // 13
        }                                                                                                             // 21
                                                                                                                      //
        return generateToken;                                                                                         //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.getDeviceInfo = function () {                                                          //
        function getDeviceInfo(userId) {                                                                              //
            return _Mongo$Collection.prototype.findOne.call(this, {                                                   // 24
                userId: userId                                                                                        // 24
            }).deviceInfo;                                                                                            // 24
        }                                                                                                             // 25
                                                                                                                      //
        return getDeviceInfo;                                                                                         //
    }(); // saveDeviceInfoLogOut(id, deviceType, gcmId, deviceToken,token) {                                          //
                                                                                                                      //
                                                                                                                      //
    MasterCollection.prototype.saveDeviceInfoLogOut = function () {                                                   //
        function saveDeviceInfoLogOut(id, deviceToken, token) {                                                       //
            return _Mongo$Collection.prototype.update.call(this, {                                                    // 29
                userId: id                                                                                            // 29
            }, {                                                                                                      // 29
                $set: {                                                                                               // 30
                    'deviceInfo.deviceToken': deviceToken,                                                            // 31
                    // given device token is deleted                                                                  // 31
                    'auth.token': token // given token is deleted to log out.                                         // 32
                                                                                                                      //
                }                                                                                                     // 30
            });                                                                                                       // 29
        }                                                                                                             // 35
                                                                                                                      //
        return saveDeviceInfoLogOut;                                                                                  //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.saveDeviceInfoLogIn = function () {                                                    //
        function saveDeviceInfoLogIn(id, deviceType, deviceToken) {                                                   //
            //console.log(id,deviceType,gcmId,deviceToken);                                                           // 38
            return _Mongo$Collection.prototype.update.call(this, {                                                    // 39
                userId: id                                                                                            // 39
            }, {                                                                                                      // 39
                $set: {                                                                                               // 40
                    deviceInfo: {                                                                                     // 41
                        deviceType: deviceType,                                                                       // 42
                        deviceToken: deviceToken                                                                      // 43
                    }                                                                                                 // 41
                }                                                                                                     // 40
            });                                                                                                       // 39
        }                                                                                                             // 47
                                                                                                                      //
        return saveDeviceInfoLogIn;                                                                                   //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.checkToken = function () {                                                             //
        function checkToken(token, userId) {                                                                          //
            if (_Mongo$Collection.prototype.findOne.call(this, {                                                      // 49
                "auth.token": token,                                                                                  // 49
                userId: userId                                                                                        // 49
            })) return true;else {                                                                                    // 49
                return false;                                                                                         // 51
            }                                                                                                         // 52
        }                                                                                                             // 53
                                                                                                                      //
        return checkToken;                                                                                            //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.setNotification = function () {                                                        //
        function setNotification(Data) {                                                                              //
            return _Mongo$Collection.prototype.update.call(this, {                                                    // 56
                userId: Data.userId                                                                                   // 56
            }, {                                                                                                      // 56
                $set: {                                                                                               // 57
                    getNotification: Data.status                                                                      // 58
                }                                                                                                     // 57
            });                                                                                                       // 56
        }                                                                                                             // 61
                                                                                                                      //
        return setNotification;                                                                                       //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.getNotification = function () {                                                        //
        function getNotification(id) {                                                                                //
            return _Mongo$Collection.prototype.findOne.call(this, {                                                   // 64
                userId: id                                                                                            // 64
            }).getNotification;                                                                                       // 64
        }                                                                                                             // 65
                                                                                                                      //
        return getNotification;                                                                                       //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.getUserData = function () {                                                            //
        function getUserData(Data) {                                                                                  //
            return _Mongo$Collection.prototype.findOne.call(this, {                                                   // 68
                $or: [{                                                                                               // 69
                    email: Data                                                                                       // 69
                }, {                                                                                                  // 69
                    userId: Data                                                                                      // 69
                }]                                                                                                    // 69
            });                                                                                                       // 68
        }                                                                                                             // 71
                                                                                                                      //
        return getUserData;                                                                                           //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.setUserLastActivityTime = function () {                                                //
        function setUserLastActivityTime(userId) {                                                                    //
            return _Mongo$Collection.prototype.update.call(this, {                                                    // 74
                userId: userId                                                                                        // 74
            }, {                                                                                                      // 74
                $set: {                                                                                               // 75
                    seen: Date.now() // last activity time                                                            // 76
                                                                                                                      //
                }                                                                                                     // 75
            });                                                                                                       // 74
        }                                                                                                             // 79
                                                                                                                      //
        return setUserLastActivityTime;                                                                               //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.updateGains = function () {                                                            //
        function updateGains(userId, coins, notes, bonusNotes) {                                                      //
            var winningStreak = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 0;                // 81
            return _Mongo$Collection.prototype.update.call(this, {                                                    // 82
                userId: userId                                                                                        // 82
            }, {                                                                                                      // 82
                $inc: {                                                                                               // 82
                    coins: coins,                                                                                     // 82
                    notes: notes,                                                                                     // 83
                    bonusNotes: bonusNotes,                                                                           // 84
                    winningStreak: winningStreak                                                                      // 85
                }                                                                                                     // 82
            });                                                                                                       // 82
        }                                                                                                             // 88
                                                                                                                      //
        return updateGains;                                                                                           //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.endStreak = function () {                                                              //
        function endStreak(looserId) {                                                                                //
            return _Mongo$Collection.prototype.update.call(this, {                                                    // 91
                userId: looserId                                                                                      // 91
            }, {                                                                                                      // 91
                $set: {                                                                                               // 91
                    winningStreak: 0                                                                                  // 91
                }                                                                                                     // 91
            });                                                                                                       // 91
        }                                                                                                             // 92
                                                                                                                      //
        return endStreak;                                                                                             //
    }();                                                                                                              //
                                                                                                                      //
    return MasterCollection;                                                                                          //
}(Mongo.Collection);                                                                                                  //
                                                                                                                      //
UserMaster = new MasterCollection("UserMaster");                                                                      // 96
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"singleGamePricing.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// collections/singleGamePricing.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
var gamePricings = function (_Mongo$Collection) {                                                                     //
	(0, _inherits3.default)(gamePricings, _Mongo$Collection);                                                            //
                                                                                                                      //
	function gamePricings() {                                                                                            //
		(0, _classCallCheck3.default)(this, gamePricings);                                                                  //
		return (0, _possibleConstructorReturn3.default)(this, _Mongo$Collection.apply(this, arguments));                    //
	}                                                                                                                    //
                                                                                                                      //
	gamePricings.prototype.addPrice = function () {                                                                      //
		function addPrice(Data) {                                                                                           //
			return _Mongo$Collection.prototype.findOne.call(this, {                                                            // 3
				title: title                                                                                                      // 3
			});                                                                                                                // 3
		}                                                                                                                   // 4
                                                                                                                      //
		return addPrice;                                                                                                    //
	}();                                                                                                                 //
                                                                                                                      //
	gamePricings.prototype.getGamePriceByType = function () {                                                            //
		function getGamePriceByType(type, fields) {                                                                         //
			return _Mongo$Collection.prototype.find.call(this, {                                                               // 7
				type: type                                                                                                        // 7
			}, {                                                                                                               // 7
				fields: fields                                                                                                    // 7
			}).fetch();                                                                                                        // 7
		}                                                                                                                   // 8
                                                                                                                      //
		return getGamePriceByType;                                                                                          //
	}();                                                                                                                 //
                                                                                                                      //
	gamePricings.prototype.editGameDeductions = function () {                                                            //
		function editGameDeductions(_id, deduction) {                                                                       //
			return _Mongo$Collection.prototype.update.call(this, {                                                             // 11
				_id: _id                                                                                                          // 11
			}, {                                                                                                               // 11
				$set: {                                                                                                           // 11
					deduction: deduction                                                                                             // 11
				}                                                                                                                 // 11
			});                                                                                                                // 11
		}                                                                                                                   // 12
                                                                                                                      //
		return editGameDeductions;                                                                                          //
	}();                                                                                                                 //
                                                                                                                      //
	gamePricings.prototype.getPricingDetail = function () {                                                              //
		function getPricingDetail(_id, fields) {                                                                            //
			return _Mongo$Collection.prototype.findOne.call(this, {                                                            // 15
				_id: _id                                                                                                          // 15
			}, {                                                                                                               // 15
				fields: fields                                                                                                    // 15
			});                                                                                                                // 15
		}                                                                                                                   // 16
                                                                                                                      //
		return getPricingDetail;                                                                                            //
	}();                                                                                                                 //
                                                                                                                      //
	return gamePricings;                                                                                                 //
}(Mongo.Collection);                                                                                                  //
                                                                                                                      //
module.exportDefault(gamePricing = new gamePricings("gamePricings"));                                                 // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"singleGames.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// collections/singleGames.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _extends2 = require("babel-runtime/helpers/extends");                                                             //
                                                                                                                      //
var _extends3 = _interopRequireDefault(_extends2);                                                                    //
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
var singleGames = function (_Mongo$Collection) {                                                                      //
	(0, _inherits3.default)(singleGames, _Mongo$Collection);                                                             //
                                                                                                                      //
	function singleGames() {                                                                                             //
		(0, _classCallCheck3.default)(this, singleGames);                                                                   //
		return (0, _possibleConstructorReturn3.default)(this, _Mongo$Collection.apply(this, arguments));                    //
	}                                                                                                                    //
                                                                                                                      //
	singleGames.prototype.addSingleGame = function () {                                                                  //
		function addSingleGame(Data) {                                                                                      //
			console.log(Data);                                                                                                 // 3
			return _Mongo$Collection.prototype.insert.call(this, (0, _extends3.default)({}, Data));                            // 4
		}                                                                                                                   // 5
                                                                                                                      //
		return addSingleGame;                                                                                               //
	}();                                                                                                                 //
                                                                                                                      //
	singleGames.prototype.winningPercentage = function () {                                                              //
		function winningPercentage(userId) {                                                                                //
			var wins = _Mongo$Collection.prototype.find.call(this, {                                                           // 7
				winner: userId                                                                                                    // 7
			}).count();                                                                                                        // 7
                                                                                                                      //
			var losses = _Mongo$Collection.prototype.find.call(this, {                                                         // 8
				looserId: userId                                                                                                  // 8
			}).count();                                                                                                        // 8
                                                                                                                      //
			return wins / (wins + losses) * 100;                                                                               // 9
		}                                                                                                                   // 10
                                                                                                                      //
		return winningPercentage;                                                                                           //
	}();                                                                                                                 //
                                                                                                                      //
	return singleGames;                                                                                                  //
}(Mongo.Collection);                                                                                                  //
                                                                                                                      //
module.exportDefault(singleGames = new singleGames("singleGames"));                                                   // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tournamentFolder.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// collections/tournamentFolder.js                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
var TournamentFolder = function (_Mongo$Collection) {                                                                 //
	(0, _inherits3.default)(TournamentFolder, _Mongo$Collection);                                                        //
                                                                                                                      //
	function TournamentFolder() {                                                                                        //
		(0, _classCallCheck3.default)(this, TournamentFolder);                                                              //
		return (0, _possibleConstructorReturn3.default)(this, _Mongo$Collection.apply(this, arguments));                    //
	}                                                                                                                    //
                                                                                                                      //
	TournamentFolder.prototype.serchByTitle = function () {                                                              //
		function serchByTitle(title) {                                                                                      //
			return _Mongo$Collection.prototype.findOne.call(this, {                                                            // 3
				title: title                                                                                                      // 3
			});                                                                                                                // 3
		}                                                                                                                   // 4
                                                                                                                      //
		return serchByTitle;                                                                                                //
	}();                                                                                                                 //
                                                                                                                      //
	TournamentFolder.prototype.registerTournament = function () {                                                        //
		function registerTournament(title) {                                                                                //
			return _Mongo$Collection.prototype.insert.call(this, {                                                             // 6
				title: title,                                                                                                     // 6
				createdAt: Date.now(),                                                                                            // 6
				updateAt: Date.now()                                                                                              // 6
			});                                                                                                                // 6
		}                                                                                                                   // 7
                                                                                                                      //
		return registerTournament;                                                                                          //
	}();                                                                                                                 //
                                                                                                                      //
	TournamentFolder.prototype.searchById = function () {                                                                //
		function searchById(_id) {                                                                                          //
			return _Mongo$Collection.prototype.findOne.call(this, {                                                            // 9
				_id: _id                                                                                                          // 9
			});                                                                                                                // 9
		}                                                                                                                   // 10
                                                                                                                      //
		return searchById;                                                                                                  //
	}();                                                                                                                 //
                                                                                                                      //
	TournamentFolder.prototype.getAllTournaments = function () {                                                         //
		function getAllTournaments() {                                                                                      //
			return _Mongo$Collection.prototype.find.call(this).fetch();                                                        // 12
		}                                                                                                                   // 13
                                                                                                                      //
		return getAllTournaments;                                                                                           //
	}();                                                                                                                 //
                                                                                                                      //
	return TournamentFolder;                                                                                             //
}(Mongo.Collection);                                                                                                  //
                                                                                                                      //
tournament = new TournamentFolder("TournamentFolder");                                                                // 16
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tournamentSubFolder.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// collections/tournamentSubFolder.js                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _extends2 = require("babel-runtime/helpers/extends");                                                             //
                                                                                                                      //
var _extends3 = _interopRequireDefault(_extends2);                                                                    //
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
var TournamentSubFolder = function (_Mongo$Collection) {                                                              //
	(0, _inherits3.default)(TournamentSubFolder, _Mongo$Collection);                                                     //
                                                                                                                      //
	function TournamentSubFolder() {                                                                                     //
		(0, _classCallCheck3.default)(this, TournamentSubFolder);                                                           //
		return (0, _possibleConstructorReturn3.default)(this, _Mongo$Collection.apply(this, arguments));                    //
	}                                                                                                                    //
                                                                                                                      //
	TournamentSubFolder.prototype.registerSubFolder = function () {                                                      //
		function registerSubFolder(Data) {                                                                                  //
			//console.log('registerSubFolder',Data);                                                                           // 3
			return _Mongo$Collection.prototype.insert.call(this, (0, _extends3.default)({}, Data));                            // 4
		}                                                                                                                   // 5
                                                                                                                      //
		return registerSubFolder;                                                                                           //
	}();                                                                                                                 //
                                                                                                                      //
	TournamentSubFolder.prototype.getAllTournaments = function () {                                                      //
		function getAllTournaments() {                                                                                      //
			return _Mongo$Collection.prototype.find.call(this).fetch();                                                        // 7
		}                                                                                                                   // 8
                                                                                                                      //
		return getAllTournaments;                                                                                           //
	}();                                                                                                                 //
                                                                                                                      //
	TournamentSubFolder.prototype.getSubTournamentsByMainTournament = function () {                                      //
		function getSubTournamentsByMainTournament(id) {                                                                    //
			return _Mongo$Collection.prototype.find.call(this, {                                                               // 10
				mainFolder: id                                                                                                    // 10
			}).fetch();                                                                                                        // 10
		}                                                                                                                   // 11
                                                                                                                      //
		return getSubTournamentsByMainTournament;                                                                           //
	}();                                                                                                                 //
                                                                                                                      //
	return TournamentSubFolder;                                                                                          //
}(Mongo.Collection);                                                                                                  //
                                                                                                                      //
tournamentSubFolder = new TournamentSubFolder("TournamentSubFolder");                                                 // 14
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validations":{"validations.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// validations/validations.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
NonEmptyString = Match.Where(function (x) {                                                                           // 1
  //console.log('function called for non empty string *******',x)                                                     // 2
  return x.length > 0 && typeof String(x) === "string";                                                               // 3
});                                                                                                                   // 4
checkNumber = Match.Where(function (x) {                                                                              // 6
  // console.log('function called for number check *******',x)                                                        // 7
  return parseInt(x);                                                                                                 // 8
});                                                                                                                   // 9
MaybeEmptyString = Match.Where(function (x) {                                                                         // 11
  return x.length >= 0;                                                                                               // 12
});                                                                                                                   // 13
                                                                                                                      //
isEmail = function (email) {                                                                                          // 15
  var filter = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                                                                                                                      //
  if (filter.test(email)) {                                                                                           // 17
    return true;                                                                                                      // 18
  }                                                                                                                   // 19
};                                                                                                                    // 20
                                                                                                                      //
isPhoneNo = function (mobile) {                                                                                       // 22
  // return (mobile.match(/^\d{10,15}$/));                                                                            // 23
  //if (mobile.match(/^\d{11,15}$/)) {                                                                                // 24
  if (mobile.match(/^\+(?:[0-9] ?){6,14}[0-9]$/)) {                                                                   // 25
    return true;                                                                                                      // 26
  } else {                                                                                                            // 27
    return false;                                                                                                     // 28
  }                                                                                                                   // 29
};                                                                                                                    // 30
                                                                                                                      //
isDob = function (dob) {                                                                                              // 32
  // return (mobile.match(/^\d{10,15}$/));                                                                            // 33
  //if (mobile.match(/^\d{11,15}$/)) {                                                                                // 34
  if (dob.match(/^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/)) {                                                            // 35
    return true;                                                                                                      // 36
  } else {                                                                                                            // 37
    return false;                                                                                                     // 38
  }                                                                                                                   // 39
};                                                                                                                    // 40
                                                                                                                      //
isGender = function (gender) {                                                                                        // 42
  if (gender.match(/^male$|^Male$|^female$|^Female$|^others$|^Others$/)) {                                            // 43
    return true;                                                                                                      // 44
  } else {                                                                                                            // 45
    return false;                                                                                                     // 46
  }                                                                                                                   // 47
};                                                                                                                    // 48
                                                                                                                      //
isMartialStatus = function (martialStatus) {                                                                          // 50
  if (martialStatus.match(/^single$|^Single$|^married$|^Married$|^divorced$|^Divorced$/)) {                           // 51
    return true;                                                                                                      // 52
  } else {                                                                                                            // 53
    return false;                                                                                                     // 54
  }                                                                                                                   // 55
};                                                                                                                    // 56
                                                                                                                      //
onlyNumber = function (experience) {                                                                                  // 58
  // let filter = /^[0-4][0-9]?$/;                                                                                    // 59
  var filter = /^((\d|[1-9]\d+)(\.\d{0,1})?|\.\d{0,1})$/;                                                             // 60
                                                                                                                      //
  if (filter.test(experience)) {                                                                                      // 61
    return true;                                                                                                      // 62
  } else {                                                                                                            // 63
    return false;                                                                                                     // 64
  }                                                                                                                   // 65
};                                                                                                                    // 66
                                                                                                                      //
capitalizeFirstLetter = function (name) {                                                                             // 68
  return name.charAt(0).toUpperCase() + name.slice(1);                                                                // 69
};                                                                                                                    // 71
                                                                                                                      //
capitalizeEachLetter = function () {                                                                                  // 73
  return this.toLowerCase().split(' ').map(function (word) {                                                          // 74
    return word.capitalizeFirstLetter();                                                                              // 77
  }).join(' ');                                                                                                       // 78
};                                                                                                                    // 80
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./server/rest/v1/File/upload.js");
require("./server/rest/v1/gamePricings/gamePricings.js");
require("./server/rest/v1/singleGames/makeBet.js");
require("./server/rest/v1/singleGames/saveGameResult.js");
require("./server/rest/v1/tournaments/getTournaments.js");
require("./server/rest/v1/user/addCoinsNotesOrBonusNotes.js");
require("./server/rest/v1/user/completeProfile1.js");
require("./server/rest/v1/user/deleteUser.js");
require("./server/rest/v1/user/editProfile.js");
require("./server/rest/v1/user/forgotpwd.js");
require("./server/rest/v1/user/login.js");
require("./server/rest/v1/user/resendOtp.js");
require("./server/rest/v1/user/signUpWithBankAcc.js");
require("./server/rest/v1/user/signup.js");
require("./server/rest/v1/user/verify.js");
require("./server/rest/v2/user/signup.js");
require("./server/configs/smtpsettings.js");
require("./server/configs/twilioSettings.js");
require("./server/methods/Counter.js");
require("./server/methods/SystemMessages.js");
require("./server/methods/Users.js");
require("./server/methods/adminMethods.js");
require("./server/methods/emailConfig.js");
require("./server/publications/publications.js");
require("./server/rest/Auth.js");
require("./server/rest/Payload.js");
require("./server/rest/Response.js");
require("./server/rest/middleware.js");
require("./server/rest/utilities.js");
require("./collections/Collection.js");
require("./collections/Files.js");
require("./collections/RequestCollection.js");
require("./collections/UserMaster.js");
require("./collections/singleGamePricing.js");
require("./collections/singleGames.js");
require("./collections/tournamentFolder.js");
require("./collections/tournamentSubFolder.js");
require("./validations/validations.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
