(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var NpmModuleBcrypt = Package['npm-bcrypt'].NpmModuleBcrypt;
var WebApp = Package.webapp.WebApp;
var WebAppInternals = Package.webapp.WebAppInternals;
var main = Package.webapp.main;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var HTML = Package.htmljs.HTML;

(function(){

/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// packages/bjwiley2_serverside-login/packages/bjwiley2_serverside-login.j //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
                                                                           //
(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/bjwiley2:serverside-login/bjwiley2:serverside-login.js   //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
if(!Meteor.isServer) {                                               // 1
  return;                                                            // 2
}                                                                    // 3
                                                                     // 4
var bcrypt = NpmModuleBcrypt;                                        // 5
var bcryptCompare = Meteor.wrapAsync(bcrypt.compare);                // 6
var sha256 = Npm.require("sha256");                                  // 7
                                                                     // 8
var error = {                                                        // 9
  success: false,                                                    // 10
  error: true,                                                       // 11
  message: "Invalid login attempt"                                   // 12
};                                                                   // 13
                                                                     // 14
this.serverSideLogin = function (email, password) {                  // 15
  if(!(email && password)) {                                         // 16
    return error;                                                    // 17
  }                                                                  // 18
                                                                     // 19
  var user = Meteor.users.findOne({                                  // 20
    "emails.address": email                                          // 21
  });                                                                // 22
                                                                     // 23
  if(!(user && user.services && user.services.password)) {           // 24
    return error;                                                    // 25
  }                                                                  // 26
                                                                     // 27
  var passwordHash = sha256(password);                               // 28
                                                                     // 29
  if(!bcryptCompare(passwordHash, user.services.password.bcrypt)) {  // 30
    return error;                                                    // 31
  }                                                                  // 32
                                                                     // 33
  var success = {                                                    // 34
    success: true,                                                   // 35
    error: false,                                                    // 36
    user: user                                                       // 37
  };                                                                 // 38
                                                                     // 39
  return success;                                                    // 40
};                                                                   // 41
                                                                     // 42
///////////////////////////////////////////////////////////////////////

}).call(this);

/////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['bjwiley2:serverside-login'] = {};

})();
