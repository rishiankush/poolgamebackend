(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['cleandersonlobo:sweetalert2'] = {};

})();
