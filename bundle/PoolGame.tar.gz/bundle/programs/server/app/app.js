var require = meteorInstall({"server":{"rest":{"v1":{"File":{"upload.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/rest/v1/File/upload.js                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var Busboy = void 0;                                                                                                // 1
module.watch(require("busboy"), {                                                                                   // 1
  "default": function (v) {                                                                                         // 1
    Busboy = v;                                                                                                     // 1
  }                                                                                                                 // 1
}, 0);                                                                                                              // 1
var successResponse = void 0,                                                                                       // 1
    failResponse = void 0;                                                                                          // 1
module.watch(require("../../Response"), {                                                                           // 1
  successResponse: function (v) {                                                                                   // 1
    successResponse = v;                                                                                            // 1
  },                                                                                                                // 1
  failResponse: function (v) {                                                                                      // 1
    failResponse = v;                                                                                               // 1
  }                                                                                                                 // 1
}, 1);                                                                                                              // 1
                                                                                                                    //
var uploadBeforeAction = function (req, res, next) {                                                                // 6
  var files = []; // Store files in an array and then pass them to request.                                         // 7
                                                                                                                    //
  if (req.method === 'POST') {                                                                                      // 9
    //console.log(req.body.token)                                                                                   // 10
    // console.log(req.body);                                                                                       // 11
    var busboy = new Busboy({                                                                                       // 13
      headers: req.headers                                                                                          // 13
    });                                                                                                             // 13
    busboy.on('file', function (fieldname, file, filename, encoding, mimetype) {                                    // 15
      var fileObj = {}; // crate an fileObj object                                                                  // 16
                                                                                                                    //
      fileObj.mimeType = mimetype;                                                                                  // 18
      fileObj.encoding = encoding;                                                                                  // 19
      fileObj.filename = filename; // buffer the read chunks                                                        // 20
                                                                                                                    //
      var buffers = [];                                                                                             // 22
      file.on('data', function (data) {                                                                             // 24
        buffers.push(data);                                                                                         // 25
      });                                                                                                           // 26
      file.on('end', function () {                                                                                  // 28
        // concat the chunks                                                                                        // 29
        fileObj.data = Buffer.concat(buffers); // push the image object to the file array                           // 30
                                                                                                                    //
        files.push(fileObj);                                                                                        // 32
      });                                                                                                           // 33
    });                                                                                                             // 34
    busboy.on('field', function (fieldname, value) {                                                                // 36
      req.body[fieldname] = value;                                                                                  // 37
    });                                                                                                             // 38
    busboy.on('finish', function () {                                                                               // 40
      // Pass the file array together with the request                                                              // 41
      req.files = files;                                                                                            // 42
      next();                                                                                                       // 43
    }); // Pass request to busboy                                                                                   // 44
                                                                                                                    //
    req.pipe(busboy);                                                                                               // 47
  } else {                                                                                                          // 48
    this.next();                                                                                                    // 49
  }                                                                                                                 // 50
};                                                                                                                  // 51
                                                                                                                    //
Router.route('/rest/v1/files/upload', function () {                                                                 // 53
  this.response.setHeader('Access-Control-Allow-Origin', '*'); // Meteor.log._('ios test', this.request.headers);   // 56
  // Meteor.call('storeLog', this.request.headers);                                                                 // 59
                                                                                                                    //
  var context = this,                                                                                               // 61
      filesData = this.request.files,                                                                               // 61
      filesUrls = [];                                                                                               // 61
  console.log('request file ******* ', filesData);                                                                  // 64
                                                                                                                    //
  _.each(filesData, function (file) {                                                                               // 65
    var newFile = new FS.File();                                                                                    // 66
    newFile.attachData(file.data, {                                                                                 // 68
      type: file.mimeType                                                                                           // 68
    }, function (err) {                                                                                             // 68
      newFile.name(file.filename);                                                                                  // 69
      Files.insert(newFile, function (err, fileObj) {                                                               // 71
        while (fileObj.url() == null) {} //let ext = fileObj.url().split('/store/files/uploads/'+fileObj._id+'/')[1].split('.').pop();
                                                                                                                    //
                                                                                                                    //
        filesUrls.push({                                                                                            // 74
          _id: fileObj._id,                                                                                         // 74
          url: fileObj.url(),                                                                                       // 74
          type: fileObj.type()                                                                                      // 74
        }); //console.log(fileObj.url().split('/store/files/uploads/'+fileObj._id+'/')[1]);                         // 74
                                                                                                                    //
        if (filesData.length === filesUrls.length) Utility.response(context, 200, successResponse({                 // 77
          msg: 'File uploaded successfully',                                                                        // 81
          data: filesUrls                                                                                           // 81
        }));                                                                                                        // 81
      });                                                                                                           // 83
    });                                                                                                             // 84
  });                                                                                                               // 85
}, {                                                                                                                // 86
  where: 'server',                                                                                                  // 88
  onBeforeAction: uploadBeforeAction                                                                                // 89
});                                                                                                                 // 87
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"user":{"forgotpwd.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/rest/v1/user/forgotpwd.js                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var checkMandatoryFields = void 0;                                                                                  // 1
module.watch(require("../../Payload"), {                                                                            // 1
  checkMandatoryFields: function (v) {                                                                              // 1
    checkMandatoryFields = v;                                                                                       // 1
  }                                                                                                                 // 1
}, 0);                                                                                                              // 1
var Email = void 0;                                                                                                 // 1
module.watch(require("meteor/email"), {                                                                             // 1
  Email: function (v) {                                                                                             // 1
    Email = v;                                                                                                      // 1
  }                                                                                                                 // 1
}, 1);                                                                                                              // 1
var successResponse = void 0,                                                                                       // 1
    failResponse = void 0;                                                                                          // 1
module.watch(require("../../Response"), {                                                                           // 1
  successResponse: function (v) {                                                                                   // 1
    successResponse = v;                                                                                            // 1
  },                                                                                                                // 1
  failResponse: function (v) {                                                                                      // 1
    failResponse = v;                                                                                               // 1
  }                                                                                                                 // 1
}, 2);                                                                                                              // 1
Router.route('/rest/v1/user/forgotpwd', function () {                                                               // 5
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                      // 8
                                                                                                                    //
  if (this.request.method === 'POST') {                                                                             // 9
    SSR.compileTemplate('htmlEmail', Assets.getText('emailTemplate.html'));                                         // 10
    var context = this,                                                                                             // 11
        feild = '',                                                                                                 // 11
        Data = Utility.getRequestContents(context.request),                                                         // 11
        hasQuery = Utility.hasData(Data),                                                                           // 11
        validData = Utility.validate(Data, {                                                                        // 11
      phoneNum: NonEmptyString // edited phoneNumber to phoneNum                                                    // 16
                                                                                                                    //
    });                                                                                                             // 15
    field = checkMandatoryFields(Data);                                                                             // 19
                                                                                                                    //
    if (validData) {                                                                                                // 21
      if (isPhoneNo(Data.phoneNum) == false) {                                                                      // 22
        validData = false;                                                                                          // 23
        Utility.response(context, 400, failResponse('Please enter valid phone number along with countrycode.'));    // 24
      } else {                                                                                                      // 29
        var UserData = UserMaster.findOne({                                                                         // 30
          phoneNum: Data.phoneNum                                                                                   // 30
        });                                                                                                         // 30
                                                                                                                    //
        if (UserData) {                                                                                             // 32
          if (Data && hasQuery && validData) {                                                                      // 33
            var randomNum = Math.floor(Math.random() * 9000) + 1000;                                                // 34
            console.log('otp *********** ', UserData.otp);                                                          // 35
            sendSms(Data.phoneNum, randomNum);                                                                      // 36
            UserMaster.update({                                                                                     // 38
              phoneNum: Data.phoneNum                                                                               // 39
            }, {                                                                                                    // 39
              $set: {                                                                                               // 40
                otp: randomNum,                                                                                     // 40
                verifiedOtp: false                                                                                  // 40
              }                                                                                                     // 40
            }); // otp for forgot password                                                                          // 40
            // let emailData = {                                                                                    // 43
            //   msg: 'Your one time password is: ' + randomNum,                                                    // 44
            //   fullName: capitalizeFirstLetter(UserData.fullName),                                                // 45
            // };                                                                                                   // 46
                                                                                                                    //
            Email.send({                                                                                            // 47
              from: 'e.life096@gmail.com',                                                                          // 48
              to: UserData.email,                                                                                   // 49
              subject: 'Chef Order: Forgot Password OTP',                                                           // 50
              text: 'Your one time password is: ' + randomNum                                                       // 51
            });                                                                                                     // 47
            Utility.response(context, 200, successResponse({                                                        // 54
              msg: 'An OTP is sent to your registered Mobile number.'                                               // 57
            }));                                                                                                    // 57
          } else {                                                                                                  // 59
            Utility.response(context, 200, failResponse('Invalid OTP'));                                            // 60
          }                                                                                                         // 61
        } else {                                                                                                    // 62
          Utility.response(context, 200, failResponse('Your number is not registered with us'));                    // 63
        }                                                                                                           // 64
      }                                                                                                             // 65
    } else {                                                                                                        // 66
      Utility.response(context, 400, failResponse("Please fill " + field + " field"));                              // 67
    }                                                                                                               // 68
  } else {                                                                                                          // 69
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                             // 74
    this.response.end('Set OPTIONS.'); //console.log(Data, hasQuery, validData);                                    // 75
  }                                                                                                                 // 77
}, {                                                                                                                // 78
  where: 'server'                                                                                                   // 79
});                                                                                                                 // 79
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"resendOtp.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/rest/v1/user/resendOtp.js                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var checkMandatoryFields = void 0;                                                                                  // 1
module.watch(require("../../Payload"), {                                                                            // 1
  checkMandatoryFields: function (v) {                                                                              // 1
    checkMandatoryFields = v;                                                                                       // 1
  }                                                                                                                 // 1
}, 0);                                                                                                              // 1
var successResponse = void 0,                                                                                       // 1
    failResponse = void 0;                                                                                          // 1
module.watch(require("../../Response"), {                                                                           // 1
  successResponse: function (v) {                                                                                   // 1
    successResponse = v;                                                                                            // 1
  },                                                                                                                // 1
  failResponse: function (v) {                                                                                      // 1
    failResponse = v;                                                                                               // 1
  }                                                                                                                 // 1
}, 1);                                                                                                              // 1
Router.route('/rest/v1/user/resendOtp', function () {                                                               // 5
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                      // 8
                                                                                                                    //
  if (this.request.method == 'POST') {                                                                              // 9
    var context = this,                                                                                             // 10
        Data = Utility.getRequestContents(context.request),                                                         // 10
        hasQuery = Utility.hasData(Data),                                                                           // 10
        validData = Utility.validate(Data, {                                                                        // 10
      phoneNum: NonEmptyString                                                                                      // 14
    }),                                                                                                             // 13
        field = checkMandatoryFields(Data);                                                                         // 10
                                                                                                                    //
    if (validData) {                                                                                                // 17
      var randomNum = Math.floor(Math.random() * 9000) + 1000,                                                      // 18
          userPhoneNumData = UserMaster.findOne({                                                                   // 18
        phoneNum: Data.phoneNum                                                                                     // 19
      }),                                                                                                           // 19
          requestPhoneNumData = Request.findOne({                                                                   // 18
        phoneNum: Data.phoneNum                                                                                     // 20
      });                                                                                                           // 20
                                                                                                                    //
      if (requestPhoneNumData) {                                                                                    // 22
        sendSms(requestPhoneNumData.phoneNum, randomNum);                                                           // 23
        Request.update({                                                                                            // 24
          phoneNum: Data.phoneNum                                                                                   // 24
        }, {                                                                                                        // 24
          $set: {                                                                                                   // 24
            code: randomNum                                                                                         // 24
          }                                                                                                         // 24
        });                                                                                                         // 24
        Utility.response(context, 200, successResponse({                                                            // 25
          msg: 'A verification code has been sent to your registered phone number.'                                 // 29
        }));                                                                                                        // 28
      } else if (userPhoneNumData) {                                                                                // 32
        sendSms(userPhoneNumData.phoneNum, randomNum);                                                              // 33
        UserMaster.update({                                                                                         // 34
          phoneNum: Data.phoneNum                                                                                   // 34
        }, {                                                                                                        // 34
          $set: {                                                                                                   // 34
            otp: randomNum                                                                                          // 34
          }                                                                                                         // 34
        });                                                                                                         // 34
        Utility.response(context, 200, successResponse({                                                            // 35
          msg: 'A verification code has been sent to your registered phone number.'                                 // 39
        }));                                                                                                        // 38
      } else {                                                                                                      // 42
        Utility.response(context, 400, failResponse('User does not exist'));                                        // 43
      }                                                                                                             // 44
    } else {                                                                                                        // 45
      Utility.response(context, 400, failResponse("Please fill " + field + " field"));                              // 46
    }                                                                                                               // 47
  } else {                                                                                                          // 48
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                             // 53
    this.response.end('Set OPTIONS.');                                                                              // 54
  }                                                                                                                 // 55
}, {                                                                                                                // 56
  where: 'server'                                                                                                   // 57
});                                                                                                                 // 57
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"signup.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/rest/v1/user/signup.js                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var checkMandatoryFields = void 0;                                                                                  // 1
module.watch(require("../../Payload"), {                                                                            // 1
  checkMandatoryFields: function (v) {                                                                              // 1
    checkMandatoryFields = v;                                                                                       // 1
  }                                                                                                                 // 1
}, 0);                                                                                                              // 1
var successResponse = void 0,                                                                                       // 1
    failResponse = void 0;                                                                                          // 1
module.watch(require("../../Response"), {                                                                           // 1
  successResponse: function (v) {                                                                                   // 1
    successResponse = v;                                                                                            // 1
  },                                                                                                                // 1
  failResponse: function (v) {                                                                                      // 1
    failResponse = v;                                                                                               // 1
  }                                                                                                                 // 1
}, 1);                                                                                                              // 1
Router.route('/rest/v1/user/signUp', function () {                                                                  // 5
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                      // 8
                                                                                                                    //
  if (this.request.method == 'POST') {                                                                              // 9
    var context = this,                                                                                             // 10
        Data = Utility.getRequestContents(context.request),                                                         // 10
        hasQuery = Utility.hasData(Data),                                                                           // 10
        validData = Utility.validate(Data, {                                                                        // 10
      email: NonEmptyString,                                                                                        // 14
      password: NonEmptyString,                                                                                     // 15
      confirmPassword: NonEmptyString,                                                                              // 16
      fullName: NonEmptyString,                                                                                     // 17
      phoneNum: NonEmptyString,                                                                                     // 18
      gender: NonEmptyString,                                                                                       // 19
      dob: NonEmptyString,                                                                                          // 20
      martialStatus: NonEmptyString                                                                                 // 21
    }),                                                                                                             // 13
        field = checkMandatoryFields(Data);                                                                         // 10
    role = 0;                                                                                                       // 24
                                                                                                                    //
    if (validData) {                                                                                                // 25
      // Meteor.call('sendGCM','fgDnMNMDGx8:APA91bFD-JQrEcG4NPQaNLvvBhiv03t4V25H9z_ISfE6bJMlUag5W59wrpte3BB4UFLO40OMn4DJhGtOoClIj6nQ9eQcRBuUljR6A4ym0xbaJQXLNmUSVo4FyoiksxzSk4TBU7Wh3FnU');
      if (!isEmail(Data.email)) {                                                                                   // 27
        validData = false;                                                                                          // 28
        Utility.response(context, 400, failResponse('Please enter valid email address'));                           // 29
      } else if (isPhoneNo(Data.phoneNum) == false) {                                                               // 30
        validData = false;                                                                                          // 32
        Utility.response(context, 400, failResponse('Please enter valid phone number along with countrycode.'));    // 33
      } // else if (nestedPositionObject(Data.position) == false) {                                                 // 38
      //   validData = false;                                                                                       // 40
      //   Utility.response(context, 400, failResponse('Please enter a valid position'));                           // 41
      // }                                                                                                          // 42
      else if (Data.password != Data.confirmPassword) {                                                             // 31
          Utility.response(context, 400, failResponse('Passwords does not match'));                                 // 44
        } else if (!isDob(Data.dob)) {                                                                              // 45
          Utility.response(context, 400, failResponse('Please enter a valid date of birth'));                       // 48
        } else if (!isGender(Data.gender)) {                                                                        // 49
          Utility.response(context, 400, failResponse('Please enter a valid gender'));                              // 52
        } else {                                                                                                    // 53
          //     else if(!(nesteddeviceInfoObject(Data.deviceInfo)))                                                // 56
          // {                                                                                                      // 57
          //      Utility.response(context, 200, failResponse('Device Information is not valid'));                  // 58
          // }                                                                                                      // 60
          //let userExists = Meteor.users.findOne({ 'emails.address': Data.email.toLowerCase() });                  // 61
          var checkUserEmail = UserMaster.findOne({                                                                 // 62
            email: Data.email.toLowerCase()                                                                         // 62
          });                                                                                                       // 62
          var checkUserPhoneNum = UserMaster.findOne({                                                              // 63
            phoneNum: Data.phoneNum                                                                                 // 63
          });                                                                                                       // 63
                                                                                                                    //
          if (!checkUserEmail) {                                                                                    // 65
            checkUserEmail = {};                                                                                    // 66
          }                                                                                                         // 67
                                                                                                                    //
          if (!checkUserPhoneNum) {                                                                                 // 68
            checkUserPhoneNum = {};                                                                                 // 69
            checkUserPhoneNum.email = '';                                                                           // 70
            checkUserPhoneNum.role = '';                                                                            // 71
          } //let userExists = UserMaster.findOne({ email: Data.email.toLowerCase() });                             // 72
          //console.log('userExists ********* ',userExists)                                                         // 74
                                                                                                                    //
                                                                                                                    //
          if (checkUserEmail.email == Data.email) {                                                                 // 75
            Utility.response(context, 400, failResponse('This email address is already registered. Please try again with a different email address.'));
          } else if (checkUserPhoneNum.phoneNum == Data.phoneNum) {                                                 // 83
            Utility.response(context, 200, failResponse('This phone number is already registered. Please try again with a different number.'));
          } else {                                                                                                  // 91
            //console.log(typeof(Data.favouriteFoods))                                                              // 93
            //Data.favouriteFoods = Data.favouriteFoods.split(",");                                                 // 94
            var randomNum = Math.floor(Math.random() * 9000) + 1000;                                                // 95
            sendSms(Data.phoneNum, randomNum); // accountId = Accounts.createUser({                                 // 96
            //   email: Data.email,                                                                                 // 99
            //   password: Data.password,                                                                           // 100
            //   profile: { isActive: 1 },                                                                          // 101
            // });                                                                                                  // 102
                                                                                                                    //
            var data = {                                                                                            // 104
              //userId: accountId,                                                                                  // 105
              fullName: Data.fullName,                                                                              // 106
              email: Data.email.toLowerCase(),                                                                      // 107
              password: Data.password,                                                                              // 108
              phoneNum: Data.phoneNum,                                                                              // 109
              code: randomNum,                                                                                      // 110
              firstTimeLogin: true,                                                                                 // 111
              isVerified: false,                                                                                    // 112
              createdAt: Date.now(),                                                                                // 113
              getNotification: 1,                                                                                   // 114
              isActive: 1                                                                                           // 115
            }; // Meteor.call('sendGCM','abc');                                                                     // 104
                                                                                                                    //
            console.log('before upsert ******** ', data); /* save related data to masterCollection */               // 118
            Request.upsertUser(data); //UserMaster.registerUser(data);                                              // 120
            //Accounts.sendVerificationEmail(accountId);                                                            // 123
                                                                                                                    //
            Utility.response(context, 200, successResponse({                                                        // 125
              msg: 'An OTP has been sent to your mobile number to verify your account, please verify in order to complete your account signup'
            })); //UserMaster.saveDeviceInfo(accountId, Data.deviceType, Data.gcmId, Data.deviceToken);             // 128
            // Utility.response(                                                                                    // 136
            //   context,                                                                                           // 137
            //   200,                                                                                               // 138
            //   successResponse({                                                                                  // 139
            //     msg:                                                                                             // 140
            //       'An email has been sent to your registered address, click on verification link in order to complete your account signup',
            //   })                                                                                                 // 142
            // );                                                                                                   // 143
          }                                                                                                         // 144
        }                                                                                                           // 145
    } else {                                                                                                        // 146
      //console.log(Data)                                                                                           // 147
      Utility.response(context, 400, failResponse("Please fill " + field + " field"));                              // 148
    }                                                                                                               // 149
  } else {                                                                                                          // 150
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                             // 155
    this.response.end('Set OPTIONS.');                                                                              // 156
  }                                                                                                                 // 157
}, {                                                                                                                // 158
  where: 'server'                                                                                                   // 159
});                                                                                                                 // 159
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"verify.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/rest/v1/user/verify.js                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var checkMandatoryFields = void 0;                                                                                  // 1
module.watch(require("../../Payload"), {                                                                            // 1
  checkMandatoryFields: function (v) {                                                                              // 1
    checkMandatoryFields = v;                                                                                       // 1
  }                                                                                                                 // 1
}, 0);                                                                                                              // 1
var successResponse = void 0,                                                                                       // 1
    failResponse = void 0;                                                                                          // 1
module.watch(require("../../Response"), {                                                                           // 1
  successResponse: function (v) {                                                                                   // 1
    successResponse = v;                                                                                            // 1
  },                                                                                                                // 1
  failResponse: function (v) {                                                                                      // 1
    failResponse = v;                                                                                               // 1
  }                                                                                                                 // 1
}, 1);                                                                                                              // 1
//import { Email } from 'meteor/email';                                                                             // 5
Router.route('/rest/v1/user/verify', function () {                                                                  // 6
  this.response.setHeader('Access-Control-Allow-Origin', '*'); //SSR.compileTemplate('welcomeEmail', Assets.getText('emailOnVerification.html'));
                                                                                                                    //
  if (this.request.method == 'POST') {                                                                              // 11
    var context = this,                                                                                             // 12
        Data = Utility.getRequestContents(context.request),                                                         // 12
        hasQuery = Utility.hasData(Data),                                                                           // 12
        validData = Utility.validate(Data, {                                                                        // 12
      phoneNum: NonEmptyString,                                                                                     // 16
      otp: NonEmptyString,                                                                                          // 17
      deviceInfo: Object                                                                                            // 18
    });                                                                                                             // 15
    field = checkMandatoryFields(Data); //console.log('data **** ', Data.otp)                                       // 20
                                                                                                                    //
    if (validData) {                                                                                                // 22
      var requestData = Request.findOne({                                                                           // 23
        phoneNum: Data.phoneNum                                                                                     // 23
      });                                                                                                           // 23
                                                                                                                    //
      if (requestData) {                                                                                            // 25
        if (requestData.phoneNum != Data.phoneNum) {                                                                // 26
          Utility.response(context, 200, failResponse('Please enter your registered phone number'));                // 27
        } else if (requestData.code != Data.otp) {                                                                  // 32
          Utility.response(context, 400, failResponse('Please enter a valid OTP'));                                 // 33
        } else {                                                                                                    // 34
          accountId = Accounts.createUser({                                                                         // 35
            email: requestData.email,                                                                               // 36
            password: requestData.password,                                                                         // 37
            profile: {                                                                                              // 38
              isActive: 1                                                                                           // 38
            }                                                                                                       // 38
          });                                                                                                       // 35
          var loginToken = Random.secret();                                                                         // 40
          var data = {                                                                                              // 41
            userId: accountId,                                                                                      // 42
            auth: {                                                                                                 // 43
              token: loginToken,                                                                                    // 44
              date_created: new Date()                                                                              // 45
            },                                                                                                      // 43
            deviceInfo: Data.deviceInfo,                                                                            // 47
            fullName: requestData.fullName,                                                                         // 48
            email: requestData.email.toLowerCase(),                                                                 // 49
            phoneNum: requestData.phoneNum,                                                                         // 50
            firstTimeLogin: true,                                                                                   // 51
            isVerified: true,                                                                                       // 52
            createdAt: Date.now(),                                                                                  // 53
            getNotification: 1,                                                                                     // 54
            isActive: 1 // rating: {                                                                                // 55
            //   avgRating: 0,                                                                                      // 57
            //   count: 0,                                                                                          // 58
            //   updated_at: Date.now(),                                                                            // 59
            // },                                                                                                   // 60
            /* save related data to masterCollection */                                                             // 62
          };                                                                                                        // 41
          UserMaster.registerUser(data);                                                                            // 63
          Request.remove({                                                                                          // 65
            _id: requestData._id                                                                                    // 65
          }); // Remove data from Request Collection                                                                // 65
                                                                                                                    //
          serverSideLogin(requestData.email.toLowerCase(), requestData.password); //    console.log(login , "login status============");
                                                                                                                    //
          Accounts.sendVerificationEmail(accountId); // Email.send({                                                // 69
          //   from: "e.life096@gmail.com",                                                                         // 71
          //   to: data.email,                                                                                      // 72
          //   subject: "Welcome mail",                                                                             // 73
          //   html: SSR.render('welcomeEmail',data),                                                               // 74
          // });                                                                                                    // 75
                                                                                                                    //
          Utility.response(context, 200, successResponse({                                                          // 77
            msg: 'Verified successfully',                                                                           // 80
            data: data                                                                                              // 80
          }));                                                                                                      // 80
        }                                                                                                           // 82
      } else {                                                                                                      // 83
        Utility.response(context, 400, failResponse('Please enter a valid Phone Number'));                          // 84
      }                                                                                                             // 85
    } else {                                                                                                        // 86
      //console.log(Data)                                                                                           // 87
      Utility.response(context, 400, failResponse("Please fill " + field + " field"));                              // 88
    }                                                                                                               // 89
  } else {                                                                                                          // 90
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                             // 95
    this.response.end('Set OPTIONS.');                                                                              // 96
  }                                                                                                                 // 97
}, {                                                                                                                // 98
  where: 'server'                                                                                                   // 99
});                                                                                                                 // 99
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"Auth.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/rest/Auth.js                                                                                              //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({                                                                                                     // 1
  "default": function () {                                                                                          // 1
    return authentication;                                                                                          // 1
  }                                                                                                                 // 1
});                                                                                                                 // 1
                                                                                                                    //
function authentication(_ref) {                                                                                     // 1
  var userId = _ref.userId,                                                                                         // 1
      token = _ref.token;                                                                                           // 1
                                                                                                                    //
  if (userId) {                                                                                                     // 2
    return Meteor.call('authentication', userId, token);                                                            // 3
  }                                                                                                                 // 4
                                                                                                                    //
  return {                                                                                                          // 6
    isActive: false,                                                                                                // 6
    authorise: false,                                                                                               // 6
    message: 'User not found'                                                                                       // 6
  };                                                                                                                // 6
}                                                                                                                   // 7
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Payload.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/rest/Payload.js                                                                                           //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                             //
                                                                                                                    //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                    //
                                                                                                                    //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                   //
                                                                                                                    //
var Payload = function () {                                                                                         //
  function Payload() {                                                                                              //
    (0, _classCallCheck3.default)(this, Payload);                                                                   //
  }                                                                                                                 //
                                                                                                                    //
  Payload.getUserDataFromHeaders = function () {                                                                    //
    function getUserDataFromHeaders(data) {                                                                         //
      return {                                                                                                      // 3
        userId: data['x-user-id'],                                                                                  // 3
        token: data['x-auth-token']                                                                                 // 3
      };                                                                                                            // 3
    }                                                                                                               // 4
                                                                                                                    //
    return getUserDataFromHeaders;                                                                                  //
  }();                                                                                                              //
                                                                                                                    //
  Payload.checkMandatoryFields = function () {                                                                      //
    function checkMandatoryFields(Data, fields) {                                                                   //
      var field = '';                                                                                               // 7
      var i = 0;                                                                                                    // 8
                                                                                                                    //
      for (var each in meteorBabelHelpers.sanitizeForInObject(Data)) {                                              // 9
        /*checks which field is blank*/if (!Data[each]) {                                                           // 10
          field = each;                                                                                             // 12
        }                                                                                                           // 13
      }                                                                                                             // 14
                                                                                                                    //
      return field;                                                                                                 // 16
    }                                                                                                               // 17
                                                                                                                    //
    return checkMandatoryFields;                                                                                    //
  }();                                                                                                              //
                                                                                                                    //
  return Payload;                                                                                                   //
}();                                                                                                                //
                                                                                                                    //
module.exports = Payload;                                                                                           // 20
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Response.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/rest/Response.js                                                                                          //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                             //
                                                                                                                    //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                    //
                                                                                                                    //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                   //
                                                                                                                    //
/*                                                                                                                  // 1
                                                                                                                    //
this class manages the response structure of web services                                                           //
                                                                                                                    //
*/var Response = function () {                                                                                      //
  function Response() {                                                                                             //
    (0, _classCallCheck3.default)(this, Response);                                                                  //
  }                                                                                                                 //
                                                                                                                    //
  Response.successResponse = function () {                                                                          //
    function successResponse(resultObj) {                                                                           //
      //console.log('resultObj ****** ',resultObj.data)                                                             // 9
      return {                                                                                                      // 10
        success: true,                                                                                              // 11
        message: resultObj.msg,                                                                                     // 12
        statusCode: 200,                                                                                            // 13
        result: resultObj.data                                                                                      // 14
      };                                                                                                            // 10
    }                                                                                                               // 16
                                                                                                                    //
    return successResponse;                                                                                         //
  }();                                                                                                              //
                                                                                                                    //
  Response.failResponse = function () {                                                                             //
    function failResponse(errorDesc) {                                                                              //
      // console.log(errorDesc)                                                                                     // 19
      return {                                                                                                      // 20
        success: false,                                                                                             // 21
        message: errorDesc,                                                                                         // 22
        //errorCode: Meteor.call('getMessagesCode', errorDesc),                                                     // 23
        statusCode: 400                                                                                             // 24
      };                                                                                                            // 20
    }                                                                                                               // 26
                                                                                                                    //
    return failResponse;                                                                                            //
  }();                                                                                                              //
                                                                                                                    //
  Response.sessionExpired = function () {                                                                           //
    function sessionExpired(errorDesc) {                                                                            //
      return {                                                                                                      // 29
        success: false,                                                                                             // 30
        message: errorDesc,                                                                                         // 31
        errorCode: Meteor.call('getMessagesCode', errorDesc),                                                       // 32
        statusCode: 401                                                                                             // 33
      };                                                                                                            // 29
    }                                                                                                               // 35
                                                                                                                    //
    return sessionExpired;                                                                                          //
  }();                                                                                                              //
                                                                                                                    //
  Response.suspendedAccount = function () {                                                                         //
    function suspendedAccount(errorDesc) {                                                                          //
      // console.log(errorDesc)                                                                                     // 38
      return {                                                                                                      // 39
        success: false,                                                                                             // 40
        message: errorDesc,                                                                                         // 41
        errorCode: Meteor.call('getMessagesCode', errorDesc),                                                       // 42
        statusCode: 402                                                                                             // 43
      };                                                                                                            // 39
    }                                                                                                               // 45
                                                                                                                    //
    return suspendedAccount;                                                                                        //
  }();                                                                                                              //
                                                                                                                    //
  return Response;                                                                                                  //
}();                                                                                                                //
                                                                                                                    //
module.exports = Response;                                                                                          // 48
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"middleware.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/rest/middleware.js                                                                                        //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var successResponse = void 0,                                                                                       // 1
    failResponse = void 0,                                                                                          // 1
    sessionExpired = void 0,                                                                                        // 1
    suspendedAccount = void 0;                                                                                      // 1
module.watch(require("./Response"), {                                                                               // 1
  successResponse: function (v) {                                                                                   // 1
    successResponse = v;                                                                                            // 1
  },                                                                                                                // 1
  failResponse: function (v) {                                                                                      // 1
    failResponse = v;                                                                                               // 1
  },                                                                                                                // 1
  sessionExpired: function (v) {                                                                                    // 1
    sessionExpired = v;                                                                                             // 1
  },                                                                                                                // 1
  suspendedAccount: function (v) {                                                                                  // 1
    suspendedAccount = v;                                                                                           // 1
  }                                                                                                                 // 1
}, 0);                                                                                                              // 1
var authentication = void 0;                                                                                        // 1
module.watch(require("./Auth"), {                                                                                   // 1
  "default": function (v) {                                                                                         // 1
    authentication = v;                                                                                             // 1
  }                                                                                                                 // 1
}, 1);                                                                                                              // 1
var getUserDataFromHeaders = void 0;                                                                                // 1
module.watch(require("./Payload"), {                                                                                // 1
  getUserDataFromHeaders: function (v) {                                                                            // 1
    getUserDataFromHeaders = v;                                                                                     // 1
  }                                                                                                                 // 1
}, 2);                                                                                                              // 1
var authNotRequiredURL = [// '/rest/v1/stripe/createCustomer',                                                      // 5
// '/rest/v1/stripe/cardToken',                                                                                     // 7
// '/rest/v1/stripe/cron',                                                                                          // 8
'/rest/v1/user/signUp', '/rest/v1/user/verify', // '/rest/v1/user/checkuser',                                       // 9
// '/rest/v1/user/forgotpwd',                                                                                       // 12
// '/rest/v1/user/login',                                                                                           // 13
'/rest/v1/user/resendOtp'];                                                                                         // 14
Router.configureBodyParsers();                                                                                      // 23
Router.onBeforeAction(function (req, res, next) {                                                                   // 25
  var context = this,                                                                                               // 26
      Data = getUserDataFromHeaders(req.headers);                                                                   // 26
                                                                                                                    //
  if (!_.contains(authNotRequiredURL, req.url)) {                                                                   // 29
    console.log('authentication *****', req.url, Data);                                                             // 30
    var checkUser = authentication(Data);                                                                           // 32
                                                                                                                    //
    if (checkUser) {                                                                                                // 34
      if (!checkUser.isActive) {                                                                                    // 35
        Utility.response(context, 402, suspendedAccount(checkUser.message));                                        // 36
      } else if (!checkUser.authorise) {                                                                            // 37
        Utility.response(context, 401, sessionExpired(checkUser.message));                                          // 38
      } else {                                                                                                      // 39
        this.next();                                                                                                // 40
      }                                                                                                             // 41
    } else {                                                                                                        // 42
      Utility.response(context, 401, sessionExpired('userId is not provided '));                                    // 43
    }                                                                                                               // 44
  } else {                                                                                                          // 45
    this.next();                                                                                                    // 46
  }                                                                                                                 // 47
});                                                                                                                 // 48
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utilities.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/rest/utilities.js                                                                                         //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
/*Utilities for rest services*/Utility = {                                                                          // 1
  getRequestContents: function (request) {                                                                          // 4
    switch (request.method) {                                                                                       // 5
      case 'GET':                                                                                                   // 6
        return _.omit(request.query, '__proto__');                                                                  // 7
                                                                                                                    //
      case 'POST':                                                                                                  // 8
        return _.omit(request.body, '__proto__');                                                                   // 9
                                                                                                                    //
      case 'PUT':                                                                                                   // 10
        return _.omit(request.body, '__proto__');                                                                   // 11
                                                                                                                    //
      case 'DELETE':                                                                                                // 12
        return _.omit(request.body, '__proto__');                                                                   // 13
    }                                                                                                               // 5
  },                                                                                                                // 15
  hasData: function (data) {                                                                                        // 16
    return Object.keys(data).length > 0 ? true : false;                                                             // 17
  },                                                                                                                // 18
  response: function (context, statusCode, data) {                                                                  // 19
    statusCode = statusCode; // ----------------------------------------------------                                // 20
                                                                                                                    //
    context.response.setHeader('Content-Type', 'application/json');                                                 // 22
    context.response.statusCode = statusCode;                                                                       // 23
    context.response.end(JSON.stringify(data));                                                                     // 24
  },                                                                                                                // 25
  validate: function (data, pattern) {                                                                              // 26
    return Match.test(data, pattern);                                                                               // 27
  }                                                                                                                 // 28
};                                                                                                                  // 3
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"configs":{"smtpsettings.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/configs/smtpsettings.js                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
smtp = {                                                                                                            // 1
  username: 'rishiankush',                                                                                          // 2
  password: 'Hello@1a',                                                                                             // 3
  //igniva@3197                                                                                                     // 3
  secure: false,                                                                                                    // 4
  port: 2525,                                                                                                       // 5
  server: 'mail.smtp2go.com'                                                                                        // 6
};                                                                                                                  // 1
process.env.MAIL_URL = 'smtp://' + encodeURIComponent(smtp.username) + ':' + encodeURIComponent(smtp.password) + '@' + encodeURIComponent(smtp.server) + ':' + smtp.port; // By default, the email is sent from no-reply@meteor.com. If you wish to receive email from users asking for help with their account, be sure to set this to an email address that you can receive email at.
                                                                                                                    //
Accounts.emailTemplates.from = '<notifications@PoolGame.com>'; // The public name of your application.              // 20
                                                                                                                    //
Accounts.emailTemplates.siteName = 'PoolGame';                                                                      // 23
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"twilioSettings.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/configs/twilioSettings.js                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var twilio = void 0;                                                                                                // 1
module.watch(require("twilio"), {                                                                                   // 1
  "default": function (v) {                                                                                         // 1
    twilio = v;                                                                                                     // 1
  }                                                                                                                 // 1
}, 0);                                                                                                              // 1
sms = {                                                                                                             // 6
  accountSid: 'AC70c72bb8ed046cd6a1e461803309ed53',                                                                 // 7
  authToken: '8feb561cabe04896c981cdc8cd97d9c8'                                                                     // 8
};                                                                                                                  // 6
var client = new twilio(sms.accountSid, sms.authToken); //console.log(new twilio(sms.accountSid, sms.authToken))    // 11
                                                                                                                    //
sendSms = function (phoneNum, randomNum) {                                                                          // 15
  client.sendSms({                                                                                                  // 16
    body: 'PoolGame one time password:' + randomNum,                                                                // 18
    to: phoneNum,                                                                                                   // 19
    from: '+16062631146'                                                                                            // 20
  }).then(function (message, err) {                                                                                 // 17
    if (!err) {                                                                                                     // 23
      console.log(message);                                                                                         // 24
    } else {                                                                                                        // 25
      console.log(err);                                                                                             // 26
    }                                                                                                               // 27
  });                                                                                                               // 28
}; // customMessage = (phoneNum, body) => {                                                                         // 29
//   client                                                                                                         // 31
//     .sendSms({                                                                                                   // 32
//       body: body,                                                                                                // 33
//       to: phoneNum,                                                                                              // 34
//       from: '+12243863041',                                                                                      // 35
//     })                                                                                                           // 36
//     .then((message, err) => {                                                                                    // 37
//       if (!err) {                                                                                                // 38
//         console.log(message);                                                                                    // 39
//       } else {                                                                                                   // 40
//         console.log(err);                                                                                        // 41
//       }                                                                                                          // 42
//     });                                                                                                          // 43
// };                                                                                                               // 44
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods":{"Counter.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/methods/Counter.js                                                                                        //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Meteor.methods({                                                                                                    // 1
  getNextSequence: function (colName) {                                                                             // 2
    this.unblock();                                                                                                 // 3
    Counter.upsert({                                                                                                // 5
      _id: colName                                                                                                  // 6
    }, {                                                                                                            // 6
      $inc: {                                                                                                       // 8
        seq: 1                                                                                                      // 9
      },                                                                                                            // 8
      $set: {                                                                                                       // 11
        date_updated: new Date()                                                                                    // 12
      },                                                                                                            // 11
      $setOnInsert: {                                                                                               // 14
        date_created: new Date()                                                                                    // 15
      }                                                                                                             // 14
    });                                                                                                             // 7
    return Counter.findOne({                                                                                        // 20
      _id: colName                                                                                                  // 20
    }).seq;                                                                                                         // 20
  }                                                                                                                 // 21
});                                                                                                                 // 1
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"SystemMessages.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/methods/SystemMessages.js                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Meteor.methods({                                                                                                    // 1
  getMessagesCode: function (text) {                                                                                // 2
    this.unblock();                                                                                                 // 3
    var message = SystemMessages.findOne({                                                                          // 5
      message: text                                                                                                 // 5
    });                                                                                                             // 5
    if (message) return message.code;else {                                                                         // 6
      SystemMessages.insert({                                                                                       // 8
        message: text,                                                                                              // 9
        code: Meteor.call('getNextSequence', 'SystemMessages'),                                                     // 10
        date_created: new Date()                                                                                    // 11
      });                                                                                                           // 8
      return SystemMessages.findOne({                                                                               // 14
        message: text                                                                                               // 14
      }).code;                                                                                                      // 14
    }                                                                                                               // 15
  }                                                                                                                 // 16
});                                                                                                                 // 1
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Users.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/methods/Users.js                                                                                          //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Meteor.methods({                                                                                                    // 1
  authentication: function (userId, token) {                                                                        // 2
    //let UserData = Meteor.users.findOne({ _id: userId });                                                         // 3
    var UserData = UserMaster.findOne({                                                                             // 4
      userId: userId                                                                                                // 4
    });                                                                                                             // 4
    var activeUser = UserData ? UserData.isActive : false; // console.log(userId, token);                           // 5
                                                                                                                    //
    if (UserData) {                                                                                                 // 9
      // if (!UserData.profile.isActive) {                                                                          // 10
      if (!activeUser) {                                                                                            // 11
        return {                                                                                                    // 12
          isActive: activeUser,                                                                                     // 13
          authorise: false,                                                                                         // 14
          message: 'Your account has been suspended'                                                                // 15
        };                                                                                                          // 12
      } else if (UserMaster.checkToken(token, userId) && UserData.isActive) {                                       // 17
        Meteor.call('setUserLastActivityTime', userId);                                                             // 18
        return {                                                                                                    // 19
          isActive: activeUser,                                                                                     // 19
          authorise: true,                                                                                          // 19
          message: 'Authentication Pass'                                                                            // 19
        };                                                                                                          // 19
      } else {                                                                                                      // 20
        return {                                                                                                    // 21
          isActive: activeUser,                                                                                     // 21
          authorise: false,                                                                                         // 21
          message: 'Session Expired'                                                                                // 21
        };                                                                                                          // 21
      }                                                                                                             // 22
    } else {                                                                                                        // 23
      return {                                                                                                      // 24
        isActive: activeUser,                                                                                       // 24
        authorise: false,                                                                                           // 24
        message: 'User not found'                                                                                   // 24
      };                                                                                                            // 24
    }                                                                                                               // 25
  },                                                                                                                // 26
  // setUserLastActivityTime: function(userId) {                                                                    // 28
  //   this.unblock();                                                                                              // 29
  //   UserMaster.setUserLastActivityTime(userId);                                                                  // 31
  // },                                                                                                             // 32
  serverTime: function () {                                                                                         // 34
    return Date.now();                                                                                              // 35
  }                                                                                                                 // 36
});                                                                                                                 // 1
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"emailConfig.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/methods/emailConfig.js                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Accounts.emailTemplates.resetPassword.text = function (user, url) {                                                 // 1
  var uName = Meteor.user().profile.name,                                                                           // 2
      msg = 'Your Credentials -\n-----------------------\nemail: ' + Meteor.user().emails + '\npassword: ' + Meteor.user().password + '\n\nTo reset your account password click on the following link. \n',
      from = '\n\n\nThank you! \n\nThe PoolGame Team. \n';                                                          // 2
  return 'Hello ' + uName + ', \n\n' + msg + url + from + Meteor.absoluteUrl() + '\n';                              // 11
};                                                                                                                  // 12
                                                                                                                    //
Accounts.emailTemplates.verifyEmail.subject = function (user, url) {                                                // 14
  return 'Pool Game Verification Link';                                                                             // 15
};                                                                                                                  // 16
                                                                                                                    //
Accounts.emailTemplates.verifyEmail.text = function (user, url) {                                                   // 18
  url = url.replace("#/", ""); //url = url.replace('-', '')                                                         // 19
                                                                                                                    //
  name = UserMaster.findOne({                                                                                       // 21
    userId: user._id                                                                                                // 21
  }).fullName;                                                                                                      // 21
  return " Hi " + name + "\n\nPlease click on the below verification link to activate your account:\n\n" + url + "\n\n Regards,\nnotifications@PoolGame.com";
};                                                                                                                  // 29
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"publications":{"publications.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/publications/publications.js                                                                              //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Meteor.publish('users', function () {                                                                               // 1
  return Meteor.users.find();                                                                                       // 2
});                                                                                                                 // 3
Meteor.publish('UsersList', function () {                                                                           // 5
  return UserMaster.find({});                                                                                       // 6
});                                                                                                                 // 7
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"main.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/main.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var Meteor = void 0;                                                                                                // 1
module.watch(require("meteor/meteor"), {                                                                            // 1
  Meteor: function (v) {                                                                                            // 1
    Meteor = v;                                                                                                     // 1
  }                                                                                                                 // 1
}, 0);                                                                                                              // 1
Meteor.startup(function () {// code to run on server at startup                                                     // 3
});                                                                                                                 // 5
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections":{"Collection.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// collections/Collection.js                                                                                        //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
SystemMessages = new Mongo.Collection("SystemMessages");                                                            // 1
Counter = new Mongo.Collection("Counter");                                                                          // 3
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"RequestCollection.js":function(require){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// collections/RequestCollection.js                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                             //
                                                                                                                    //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                    //
                                                                                                                    //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                       //
                                                                                                                    //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                              //
                                                                                                                    //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                         //
                                                                                                                    //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                //
                                                                                                                    //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                   //
                                                                                                                    //
/*                                                                                                                  // 1
Request collection is a kind of additional collection in which data of unverified user is stored.                   //
After the user is verified, data from this collection is remived and added in main collection i.e                   //
UserMaster collection.                                                                                              //
*/var RequestCollection = function (_Mongo$Collection) {                                                            //
    (0, _inherits3.default)(RequestCollection, _Mongo$Collection);                                                  //
                                                                                                                    //
    function RequestCollection() {                                                                                  //
        (0, _classCallCheck3.default)(this, RequestCollection);                                                     //
        return (0, _possibleConstructorReturn3.default)(this, _Mongo$Collection.apply(this, arguments));            //
    }                                                                                                               //
                                                                                                                    //
    RequestCollection.prototype.registerUser = function () {                                                        //
        function registerUser(data) {                                                                               //
            /* save related data to RequestCollection */return _Mongo$Collection.prototype.insert.call(this, data);
        }                                                                                                           // 11
                                                                                                                    //
        return registerUser;                                                                                        //
    }(); // upsert user for Request collection                                                                      //
                                                                                                                    //
                                                                                                                    //
    RequestCollection.prototype.upsertUser = function () {                                                          //
        function upsertUser(Data) {                                                                                 //
            console.log(Data, "%%%%%%%%%%%%%%%");                                                                   // 15
                                                                                                                    //
            var checkEmail = _Mongo$Collection.prototype.findOne.call(this, {                                       // 16
                email: Data.email                                                                                   // 16
            }),                                                                                                     // 16
                checkPhone = _Mongo$Collection.prototype.findOne.call(this, {                                       // 16
                phoneNum: Data.phoneNum                                                                             // 17
            }); // console.log(checkPhone, "check phoene is hereeeeee");                                            // 17
            // console.log(checkEmail, "check email is hereeeeee")                                                  // 19
                                                                                                                    //
                                                                                                                    //
            if (checkEmail) {                                                                                       // 20
                return _Mongo$Collection.prototype.update.call(this, {                                              // 21
                    email: Data.email                                                                               // 22
                }, Data, {                                                                                          // 21
                    upsert: true                                                                                    // 23
                });                                                                                                 // 23
            } else if (checkPhone) {                                                                                // 24
                return _Mongo$Collection.prototype.update.call(this, {                                              // 25
                    phoneNum: Data.phoneNum                                                                         // 26
                }, Data, {                                                                                          // 25
                    upsert: true                                                                                    // 27
                });                                                                                                 // 27
            } else {                                                                                                // 28
                return _Mongo$Collection.prototype.update.call(this, {                                              // 29
                    email: Data.email,                                                                              // 30
                    phoneNum: Data.phoneNum                                                                         // 31
                }, Data, {                                                                                          // 29
                    upsert: true                                                                                    // 32
                });                                                                                                 // 32
            }                                                                                                       // 33
        }                                                                                                           // 34
                                                                                                                    //
        return upsertUser;                                                                                          //
    }();                                                                                                            //
                                                                                                                    //
    return RequestCollection;                                                                                       //
}(Mongo.Collection);                                                                                                //
                                                                                                                    //
Request = new RequestCollection("Request");                                                                         // 37
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"UserMaster.js":function(require){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// collections/UserMaster.js                                                                                        //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                             //
                                                                                                                    //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                    //
                                                                                                                    //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                       //
                                                                                                                    //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                              //
                                                                                                                    //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                         //
                                                                                                                    //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                //
                                                                                                                    //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                   //
                                                                                                                    //
var MasterCollection = function (_Mongo$Collection) {                                                               //
    (0, _inherits3.default)(MasterCollection, _Mongo$Collection);                                                   //
                                                                                                                    //
    function MasterCollection() {                                                                                   //
        (0, _classCallCheck3.default)(this, MasterCollection);                                                      //
        return (0, _possibleConstructorReturn3.default)(this, _Mongo$Collection.apply(this, arguments));            //
    }                                                                                                               //
                                                                                                                    //
    MasterCollection.prototype.registerUser = function () {                                                         //
        function registerUser(data) {                                                                               //
            /* save related data to masterCollection */return _Mongo$Collection.prototype.insert.call(this, data);  // 4
        }                                                                                                           // 6
                                                                                                                    //
        return registerUser;                                                                                        //
    }();                                                                                                            //
                                                                                                                    //
    MasterCollection.prototype.getUserLoacation = function () {                                                     //
        function getUserLoacation(userId) {                                                                         //
            return _Mongo$Collection.prototype.findOne.call(this, {                                                 // 9
                userId: userId                                                                                      // 9
            }).location;                                                                                            // 9
        }                                                                                                           // 10
                                                                                                                    //
        return getUserLoacation;                                                                                    //
    }();                                                                                                            //
                                                                                                                    //
    MasterCollection.prototype.generateToken = function () {                                                        //
        function generateToken(id) {                                                                                //
            return _Mongo$Collection.prototype.update.call(this, {                                                  // 13
                userId: id                                                                                          // 13
            }, {                                                                                                    // 13
                $set: {                                                                                             // 14
                    auth: {                                                                                         // 15
                        token: Random.secret(),                                                                     // 16
                        date_created: Date.now()                                                                    // 17
                    }                                                                                               // 15
                }                                                                                                   // 14
            });                                                                                                     // 13
        }                                                                                                           // 21
                                                                                                                    //
        return generateToken;                                                                                       //
    }();                                                                                                            //
                                                                                                                    //
    MasterCollection.prototype.getDeviceInfo = function () {                                                        //
        function getDeviceInfo(userId) {                                                                            //
            return _Mongo$Collection.prototype.findOne.call(this, {                                                 // 24
                userId: userId                                                                                      // 24
            }).deviceInfo;                                                                                          // 24
        }                                                                                                           // 25
                                                                                                                    //
        return getDeviceInfo;                                                                                       //
    }(); // saveDeviceInfoLogOut(id, deviceType, gcmId, deviceToken,token) {                                        //
                                                                                                                    //
                                                                                                                    //
    MasterCollection.prototype.saveDeviceInfoLogOut = function () {                                                 //
        function saveDeviceInfoLogOut(id, deviceToken, token) {                                                     //
            return _Mongo$Collection.prototype.update.call(this, {                                                  // 29
                userId: id                                                                                          // 29
            }, {                                                                                                    // 29
                $set: {                                                                                             // 30
                    'deviceInfo.deviceToken': deviceToken,                                                          // 31
                    // given device token is deleted                                                                // 31
                    'auth.token': token // given token is deleted to log out.                                       // 32
                                                                                                                    //
                }                                                                                                   // 30
            });                                                                                                     // 29
        }                                                                                                           // 35
                                                                                                                    //
        return saveDeviceInfoLogOut;                                                                                //
    }();                                                                                                            //
                                                                                                                    //
    MasterCollection.prototype.saveDeviceInfoLogIn = function () {                                                  //
        function saveDeviceInfoLogIn(id, deviceType, deviceToken) {                                                 //
            //console.log(id,deviceType,gcmId,deviceToken);                                                         // 38
            return _Mongo$Collection.prototype.update.call(this, {                                                  // 39
                userId: id                                                                                          // 39
            }, {                                                                                                    // 39
                $set: {                                                                                             // 40
                    deviceInfo: {                                                                                   // 41
                        deviceType: deviceType,                                                                     // 42
                        deviceToken: deviceToken                                                                    // 43
                    }                                                                                               // 41
                }                                                                                                   // 40
            });                                                                                                     // 39
        }                                                                                                           // 47
                                                                                                                    //
        return saveDeviceInfoLogIn;                                                                                 //
    }();                                                                                                            //
                                                                                                                    //
    MasterCollection.prototype.updateStatus = function () {                                                         //
        function updateStatus(condition, query) {                                                                   //
            return _Mongo$Collection.prototype.update.call(this, condition, query, {                                // 50
                upsert: true                                                                                        // 50
            });                                                                                                     // 50
        }                                                                                                           // 51
                                                                                                                    //
        return updateStatus;                                                                                        //
    }();                                                                                                            //
                                                                                                                    //
    MasterCollection.prototype.checkToken = function () {                                                           //
        function checkToken(token, userId) {                                                                        //
            if (_Mongo$Collection.prototype.findOne.call(this, {                                                    // 54
                "auth.token": token,                                                                                // 54
                userId: userId                                                                                      // 54
            })) return true;else {                                                                                  // 54
                return false;                                                                                       // 56
            }                                                                                                       // 57
        }                                                                                                           // 58
                                                                                                                    //
        return checkToken;                                                                                          //
    }();                                                                                                            //
                                                                                                                    //
    MasterCollection.prototype.setNotification = function () {                                                      //
        function setNotification(Data) {                                                                            //
            return _Mongo$Collection.prototype.update.call(this, {                                                  // 61
                userId: Data.userId                                                                                 // 61
            }, {                                                                                                    // 61
                $set: {                                                                                             // 62
                    getNotification: Data.status                                                                    // 63
                }                                                                                                   // 62
            });                                                                                                     // 61
        }                                                                                                           // 66
                                                                                                                    //
        return setNotification;                                                                                     //
    }();                                                                                                            //
                                                                                                                    //
    MasterCollection.prototype.getNotification = function () {                                                      //
        function getNotification(id) {                                                                              //
            return _Mongo$Collection.prototype.findOne.call(this, {                                                 // 69
                userId: id                                                                                          // 69
            }).getNotification;                                                                                     // 69
        }                                                                                                           // 70
                                                                                                                    //
        return getNotification;                                                                                     //
    }();                                                                                                            //
                                                                                                                    //
    MasterCollection.prototype.getUserData = function () {                                                          //
        function getUserData(Data) {                                                                                //
            return _Mongo$Collection.prototype.findOne.call(this, {                                                 // 73
                $or: [{                                                                                             // 74
                    email: Data                                                                                     // 74
                }, {                                                                                                // 74
                    phoneNum: Data                                                                                  // 74
                }, {                                                                                                // 74
                    userId: Data                                                                                    // 74
                }]                                                                                                  // 74
            });                                                                                                     // 73
        }                                                                                                           // 76
                                                                                                                    //
        return getUserData;                                                                                         //
    }(); // setUserLastActivityTime(userId) {                                                                       //
    //     return super.update({ userId }, {                                                                        // 79
    //         $set: {                                                                                              // 80
    //             seen: Date.now() // last activity time                                                           // 81
    //         }                                                                                                    // 82
    //     });                                                                                                      // 83
    // }                                                                                                            // 84
                                                                                                                    //
                                                                                                                    //
    return MasterCollection;                                                                                        //
}(Mongo.Collection);                                                                                                //
                                                                                                                    //
UserMaster = new MasterCollection("UserMaster");                                                                    // 88
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validations":{"validations.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// validations/validations.js                                                                                       //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
NonEmptyString = Match.Where(function (x) {                                                                         // 1
  console.log('function called for non empty string *******', x);                                                   // 2
  return x.length > 0 && typeof String(x) === "string";                                                             // 3
});                                                                                                                 // 4
checkNumber = Match.Where(function (x) {                                                                            // 6
  console.log('function called for number check *******', x);                                                       // 7
  return parseInt(x);                                                                                               // 8
});                                                                                                                 // 9
MaybeEmptyString = Match.Where(function (x) {                                                                       // 11
  return x.length >= 0;                                                                                             // 12
});                                                                                                                 // 13
                                                                                                                    //
isEmail = function (email) {                                                                                        // 15
  var filter = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                                                                                                                    //
  if (filter.test(email)) {                                                                                         // 17
    return true;                                                                                                    // 18
  }                                                                                                                 // 19
};                                                                                                                  // 20
                                                                                                                    //
isPhoneNo = function (mobile) {                                                                                     // 22
  // return (mobile.match(/^\d{10,15}$/));                                                                          // 23
  //if (mobile.match(/^\d{11,15}$/)) {                                                                              // 24
  if (mobile.match(/^\+(?:[0-9] ?){6,14}[0-9]$/)) {                                                                 // 25
    return true;                                                                                                    // 26
  } else {                                                                                                          // 27
    return false;                                                                                                   // 28
  }                                                                                                                 // 29
};                                                                                                                  // 30
                                                                                                                    //
isDob = function (dob) {                                                                                            // 32
  // return (mobile.match(/^\d{10,15}$/));                                                                          // 33
  //if (mobile.match(/^\d{11,15}$/)) {                                                                              // 34
  if (dob.match(/^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/)) {                                                          // 35
    return true;                                                                                                    // 36
  } else {                                                                                                          // 37
    return false;                                                                                                   // 38
  }                                                                                                                 // 39
};                                                                                                                  // 40
                                                                                                                    //
isGender = function (gender) {                                                                                      // 42
  if (gender.match(/^male$|^female$/)) {                                                                            // 43
    return true;                                                                                                    // 44
  } else {                                                                                                          // 45
    return false;                                                                                                   // 46
  }                                                                                                                 // 47
};                                                                                                                  // 48
                                                                                                                    //
onlyNumber = function (experience) {                                                                                // 50
  // let filter = /^[0-4][0-9]?$/;                                                                                  // 51
  var filter = /^((\d|[1-9]\d+)(\.\d{0,1})?|\.\d{0,1})$/;                                                           // 52
                                                                                                                    //
  if (filter.test(experience)) {                                                                                    // 53
    return true;                                                                                                    // 54
  } else {                                                                                                          // 55
    return false;                                                                                                   // 56
  }                                                                                                                 // 57
};                                                                                                                  // 58
                                                                                                                    //
capitalizeFirstLetter = function (name) {                                                                           // 60
  return name.charAt(0).toUpperCase() + name.slice(1);                                                              // 61
};                                                                                                                  // 63
                                                                                                                    //
capitalizeEachLetter = function () {                                                                                // 65
  return this.toLowerCase().split(' ').map(function (word) {                                                        // 66
    return word.capitalizeFirstLetter();                                                                            // 69
  }).join(' ');                                                                                                     // 70
};                                                                                                                  // 72
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./server/rest/v1/File/upload.js");
require("./server/rest/v1/user/forgotpwd.js");
require("./server/rest/v1/user/resendOtp.js");
require("./server/rest/v1/user/signup.js");
require("./server/rest/v1/user/verify.js");
require("./server/configs/smtpsettings.js");
require("./server/configs/twilioSettings.js");
require("./server/methods/Counter.js");
require("./server/methods/SystemMessages.js");
require("./server/methods/Users.js");
require("./server/methods/emailConfig.js");
require("./server/publications/publications.js");
require("./server/rest/Auth.js");
require("./server/rest/Payload.js");
require("./server/rest/Response.js");
require("./server/rest/middleware.js");
require("./server/rest/utilities.js");
require("./collections/Collection.js");
require("./collections/RequestCollection.js");
require("./collections/UserMaster.js");
require("./validations/validations.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
