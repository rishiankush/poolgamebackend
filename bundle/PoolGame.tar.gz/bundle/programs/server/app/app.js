var require = meteorInstall({"server":{"rest":{"v1":{"File":{"upload.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/File/upload.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Busboy = void 0;                                                                                                  // 1
module.watch(require("busboy"), {                                                                                     // 1
  "default": function (v) {                                                                                           // 1
    Busboy = v;                                                                                                       // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
                                                                                                                      //
var uploadBeforeAction = function (req, res, next) {                                                                  // 6
  var files = []; // Store files in an array and then pass them to request.                                           // 7
                                                                                                                      //
  if (req.method === 'POST') {                                                                                        // 9
    //console.log(req.body.token)                                                                                     // 10
    // console.log(req.body);                                                                                         // 11
    var busboy = new Busboy({                                                                                         // 13
      headers: req.headers                                                                                            // 13
    });                                                                                                               // 13
    busboy.on('file', function (fieldname, file, filename, encoding, mimetype) {                                      // 15
      var fileObj = {}; // crate an fileObj object                                                                    // 16
                                                                                                                      //
      fileObj.mimeType = mimetype;                                                                                    // 18
      fileObj.encoding = encoding;                                                                                    // 19
      fileObj.filename = filename; // buffer the read chunks                                                          // 20
                                                                                                                      //
      var buffers = [];                                                                                               // 22
      file.on('data', function (data) {                                                                               // 24
        buffers.push(data);                                                                                           // 25
      });                                                                                                             // 26
      file.on('end', function () {                                                                                    // 28
        // concat the chunks                                                                                          // 29
        fileObj.data = Buffer.concat(buffers); // push the image object to the file array                             // 30
                                                                                                                      //
        files.push(fileObj);                                                                                          // 32
      });                                                                                                             // 33
    });                                                                                                               // 34
    busboy.on('field', function (fieldname, value) {                                                                  // 36
      req.body[fieldname] = value;                                                                                    // 37
    });                                                                                                               // 38
    busboy.on('finish', function () {                                                                                 // 40
      // Pass the file array together with the request                                                                // 41
      req.files = files;                                                                                              // 42
      next();                                                                                                         // 43
    }); // Pass request to busboy                                                                                     // 44
                                                                                                                      //
    req.pipe(busboy);                                                                                                 // 47
  } else {                                                                                                            // 48
    this.next();                                                                                                      // 49
  }                                                                                                                   // 50
};                                                                                                                    // 51
                                                                                                                      //
Router.route('/rest/v1/files/upload', function () {                                                                   // 53
  this.response.setHeader('Access-Control-Allow-Origin', '*'); // Meteor.log._('ios test', this.request.headers);     // 56
  // Meteor.call('storeLog', this.request.headers);                                                                   // 59
                                                                                                                      //
  var context = this,                                                                                                 // 61
      filesData = this.request.files,                                                                                 // 61
      filesUrls = [];                                                                                                 // 61
  console.log('request file ******* ', filesData);                                                                    // 64
                                                                                                                      //
  _.each(filesData, function (file) {                                                                                 // 65
    var newFile = new FS.File();                                                                                      // 66
    newFile.attachData(file.data, {                                                                                   // 68
      type: file.mimeType                                                                                             // 68
    }, function (err) {                                                                                               // 68
      newFile.name(file.filename);                                                                                    // 69
      Files.insert(newFile, function (err, fileObj) {                                                                 // 71
        while (fileObj.url() == null) {} //let ext = fileObj.url().split('/store/files/uploads/'+fileObj._id+'/')[1].split('.').pop();
                                                                                                                      //
                                                                                                                      //
        filesUrls.push({                                                                                              // 74
          _id: fileObj._id,                                                                                           // 74
          url: fileObj.url(),                                                                                         // 74
          type: fileObj.type()                                                                                        // 74
        }); //console.log(fileObj.url().split('/store/files/uploads/'+fileObj._id+'/')[1]);                           // 74
                                                                                                                      //
        if (filesData.length === filesUrls.length) Utility.response(context, 200, successResponse({                   // 77
          msg: 'File uploaded successfully',                                                                          // 81
          data: filesUrls                                                                                             // 81
        }));                                                                                                          // 81
      });                                                                                                             // 83
    });                                                                                                               // 84
  });                                                                                                                 // 85
}, {                                                                                                                  // 86
  where: 'server',                                                                                                    // 88
  onBeforeAction: uploadBeforeAction                                                                                  // 89
});                                                                                                                   // 87
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"user":{"forgotpwd.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/user/forgotpwd.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var checkMandatoryFields = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  checkMandatoryFields: function (v) {                                                                                // 1
    checkMandatoryFields = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var Email = void 0;                                                                                                   // 1
module.watch(require("meteor/email"), {                                                                               // 1
  Email: function (v) {                                                                                               // 1
    Email = v;                                                                                                        // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 2);                                                                                                                // 1
Router.route('/rest/v1/user/forgotpwd', function () {                                                                 // 5
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                        // 8
                                                                                                                      //
  if (this.request.method === 'POST') {                                                                               // 9
    var context = this,                                                                                               // 10
        feild = '',                                                                                                   // 10
        Data = Utility.getRequestContents(context.request),                                                           // 10
        hasQuery = Utility.hasData(Data),                                                                             // 10
        validData = Utility.validate(Data, {                                                                          // 10
      email: NonEmptyString                                                                                           // 15
    });                                                                                                               // 14
    field = checkMandatoryFields(Data);                                                                               // 18
                                                                                                                      //
    if (validData) {                                                                                                  // 20
      if (isEmail(Data.phoneNum) == false) {                                                                          // 21
        validData = false;                                                                                            // 22
        Utility.response(context, 400, failResponse('Please enter valid email address'));                             // 23
      } else {                                                                                                        // 28
        var UserData = UserMaster.findOne({                                                                           // 29
          email: Data.email                                                                                           // 29
        }); // let checkVerifiedUser = Meteor.users.findOne({ 'emails.verified': true })                              // 29
        //   console.log(checkVerifiedUser)                                                                           // 31
                                                                                                                      //
        if (UserData) {                                                                                               // 32
          if (Data && hasQuery && validData) {                                                                        // 33
            var userId = Meteor.userId(); //console.log('userId ******** ', userId)                                   // 34
                                                                                                                      //
            Accounts.sendResetPasswordEmail(userId, Data.email);                                                      // 36
            Utility.response(context, 200, successResponse({                                                          // 37
              msg: 'An email is sent to your registered address.'                                                     // 40
            }));                                                                                                      // 40
          } else {                                                                                                    // 42
            Utility.response(context, 400, failResponse('Invalid email address'));                                    // 43
          }                                                                                                           // 44
        } else {                                                                                                      // 45
          Utility.response(context, 400, failResponse('Your email is not registered with us'));                       // 46
        }                                                                                                             // 47
      }                                                                                                               // 48
    } else {                                                                                                          // 49
      Utility.response(context, 400, failResponse("Please fill " + field + " field"));                                // 50
    }                                                                                                                 // 51
  } else {                                                                                                            // 52
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 53
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 57
    this.response.end('Set OPTIONS.'); //console.log(Data, hasQuery, validData);                                      // 58
  }                                                                                                                   // 60
}, {                                                                                                                  // 61
  where: 'server'                                                                                                     // 62
});                                                                                                                   // 62
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"login.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/user/login.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var checkMandatoryFields = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  checkMandatoryFields: function (v) {                                                                                // 1
    checkMandatoryFields = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0,                                                                                            // 1
    suspendedAccount = void 0;                                                                                        // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  },                                                                                                                  // 1
  suspendedAccount: function (v) {                                                                                    // 1
    suspendedAccount = v;                                                                                             // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
Router.route('/rest/v1/user/login', function () {                                                                     // 5
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                        // 8
                                                                                                                      //
  if (this.request.method == 'POST') {                                                                                // 9
    var context = this,                                                                                               // 10
        Data = Utility.getRequestContents(context.request),                                                           // 10
        hasQuery = Utility.hasData(Data),                                                                             // 10
        validData = Utility.validate(Data, {                                                                          // 10
      email: NonEmptyString,                                                                                          // 14
      // here email field is just a name of field which takes both phone number and email                             // 14
      password: NonEmptyString //deviceInfo: Object,                                                                  // 15
                                                                                                                      //
    }),                                                                                                               // 13
        field = checkMandatoryFields(Data); // if (!nesteddeviceInfoObject(Data.deviceInfo)) {                        // 10
    //   Utility.response(context, 400, failResponse('Device Information is not valid'));                             // 20
    // }                                                                                                              // 21
                                                                                                                      //
    if (validData) {                                                                                                  // 23
      // let UserData = '';                                                                                           // 24
      // // if user has filled email, we get emailMatch                                                               // 25
      // emailMatch =                                                                                                 // 26
      //   UserMaster.findOne({ email: Data.email.toLowerCase() })                                                    // 27
      // if (emailMatch) {                                                                                            // 29
      //   // checking whether account is verified or not                                                             // 30
      //   if (emailMatch.isActive == 0) {                                                                            // 31
      //     Utility.response(context, 402, failResponse('Your account has been suspended'));                         // 32
      //   } else if (emailMatch.isVerified) {                                                                        // 33
      //     UserData = serverSideLogin(emailMatch.email.toLowerCase(), Data.password);                               // 34
      //   } else {                                                                                                   // 35
      //     UserData = '';                                                                                           // 36
      //     Utility.response(                                                                                        // 37
      //       context,                                                                                               // 38
      //       400,                                                                                                   // 39
      //       failResponse('Credentials does not exists Please go for Sign up process')                              // 40
      //     );                                                                                                       // 41
      //   }                                                                                                          // 42
      // } else {                                                                                                     // 43
      //   UserData = '';                                                                                             // 44
      // }                                                                                                            // 45
      // // checking if login function response is undefined,blank or error                                           // 46
      // if (!(UserData == '' || UserData == null || UserData.error)) {                                               // 47
      //   //console.log(UserData.user._id , "userdata is here")                                                      // 48
      //   UserMaster.generateToken(UserData.user._id);                                                               // 49
      //   // console.log(token);                                                                                     // 50
      //   // code to check whether a person is logged in and try to log in again.                                    // 51
      //   // console.log(loginInfo,"hahahh");                                                                        // 53
      //   UserMaster.saveDeviceInfoLogIn(                                                                            // 54
      //     UserData.user._id,                                                                                       // 55
      //     Data.deviceInfo.deviceType,                                                                              // 56
      //     Data.deviceInfo.deviceToken                                                                              // 57
      //   );                                                                                                         // 58
      //   let data = UserMaster.getUserData(Data.email);                                                             // 59
      //   //console.log('here is data****** ',data)                                                                  // 60
      var userData = UserMaster.findOne({                                                                             // 62
        email: Data.email                                                                                             // 62
      });                                                                                                             // 62
      var emailMatch = Meteor.users.findOne({                                                                         // 63
        'emails.address': Data.email                                                                                  // 63
      });                                                                                                             // 63
      console.log('emailMatch ****** ', emailMatch.emails[0].verified);                                               // 64
                                                                                                                      //
      if (!isEmail(Data.email)) {                                                                                     // 65
        validData = false;                                                                                            // 66
        Utility.response(context, 400, failResponse('Please enter valid email address.'));                            // 67
      } else if (userData.email != Data.email) {                                                                      // 68
        Utility.response(context, 400, failResponse('This email is not registered with us.'));                        // 71
      } else if (emailMatch.emails[0].verified == false) {                                                            // 72
        Utility.response(context, 400, failResponse('This email is not verified with us.'));                          // 75
      } else {                                                                                                        // 76
        Utility.response(context, 200, successResponse({                                                              // 79
          msg: 'User logged in successfully',                                                                         // 82
          data: userData                                                                                              // 82
        }));                                                                                                          // 82
      }                                                                                                               // 84
    } else {                                                                                                          // 86
      // in case of invalid data                                                                                      // 87
      Utility.response(context, 400, failResponse("Please fill " + field + " field"));                                // 88
    }                                                                                                                 // 89
  } else {                                                                                                            // 90
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 91
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 95
    this.response.end('Set OPTIONS.');                                                                                // 96
  }                                                                                                                   // 97
}, {                                                                                                                  // 98
  where: 'server'                                                                                                     // 99
});                                                                                                                   // 99
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"resendOtp.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/user/resendOtp.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var checkMandatoryFields = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  checkMandatoryFields: function (v) {                                                                                // 1
    checkMandatoryFields = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
Router.route('/rest/v1/user/resendOtp', function () {                                                                 // 5
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                        // 8
                                                                                                                      //
  if (this.request.method == 'POST') {                                                                                // 9
    var context = this,                                                                                               // 10
        Data = Utility.getRequestContents(context.request),                                                           // 10
        hasQuery = Utility.hasData(Data),                                                                             // 10
        validData = Utility.validate(Data, {                                                                          // 10
      phoneNum: NonEmptyString                                                                                        // 14
    }),                                                                                                               // 13
        field = checkMandatoryFields(Data);                                                                           // 10
                                                                                                                      //
    if (validData) {                                                                                                  // 17
      var randomNum = Math.floor(Math.random() * 9000) + 1000,                                                        // 18
          userPhoneNumData = UserMaster.findOne({                                                                     // 18
        phoneNum: Data.phoneNum                                                                                       // 19
      }),                                                                                                             // 19
          requestPhoneNumData = Request.findOne({                                                                     // 18
        phoneNum: Data.phoneNum                                                                                       // 20
      });                                                                                                             // 20
                                                                                                                      //
      if (requestPhoneNumData) {                                                                                      // 22
        sendSms(requestPhoneNumData.phoneNum, randomNum);                                                             // 23
        Request.update({                                                                                              // 24
          phoneNum: Data.phoneNum                                                                                     // 24
        }, {                                                                                                          // 24
          $set: {                                                                                                     // 24
            code: randomNum                                                                                           // 24
          }                                                                                                           // 24
        });                                                                                                           // 24
        Utility.response(context, 200, successResponse({                                                              // 25
          msg: 'A verification code has been sent to your registered phone number.'                                   // 29
        }));                                                                                                          // 28
      } else if (userPhoneNumData) {                                                                                  // 32
        sendSms(userPhoneNumData.phoneNum, randomNum);                                                                // 33
        UserMaster.update({                                                                                           // 34
          phoneNum: Data.phoneNum                                                                                     // 34
        }, {                                                                                                          // 34
          $set: {                                                                                                     // 34
            otp: randomNum                                                                                            // 34
          }                                                                                                           // 34
        });                                                                                                           // 34
        Utility.response(context, 200, successResponse({                                                              // 35
          msg: 'A verification code has been sent to your registered phone number.'                                   // 39
        }));                                                                                                          // 38
      } else {                                                                                                        // 42
        Utility.response(context, 400, failResponse('User does not exist'));                                          // 43
      }                                                                                                               // 44
    } else {                                                                                                          // 45
      Utility.response(context, 400, failResponse("Please fill " + field + " field"));                                // 46
    }                                                                                                                 // 47
  } else {                                                                                                            // 48
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 49
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 53
    this.response.end('Set OPTIONS.');                                                                                // 54
  }                                                                                                                   // 55
}, {                                                                                                                  // 56
  where: 'server'                                                                                                     // 57
});                                                                                                                   // 57
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"signUpWithBankAcc.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/user/signUpWithBankAcc.js                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var checkMandatoryFields = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  checkMandatoryFields: function (v) {                                                                                // 1
    checkMandatoryFields = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
Router.route('/rest/v1/user/signUpWithBankAcc', function () {                                                         // 5
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                        // 8
                                                                                                                      //
  if (this.request.method == 'POST') {                                                                                // 9
    var context = this,                                                                                               // 10
        Data = Utility.getRequestContents(context.request),                                                           // 10
        hasQuery = Utility.hasData(Data),                                                                             // 10
        validData = Utility.validate(Data, {                                                                          // 10
      userId: NonEmptyString,                                                                                         // 14
      idProof: MaybeEmptyString,                                                                                      // 15
      passportNum: MaybeEmptyString,                                                                                  // 16
      addressProof: MaybeEmptyString,                                                                                 // 17
      bankName: MaybeEmptyString,                                                                                     // 18
      accNum: MaybeEmptyString,                                                                                       // 19
      ifscNum: MaybeEmptyString                                                                                       // 20
    }),                                                                                                               // 13
        field = checkMandatoryFields(_.omit(Data, 'idProof', 'passportNum', 'addressProof', 'bankName', 'accNum', 'ifscNum'));
                                                                                                                      //
    if (validData) {                                                                                                  // 23
      var userData = UserMaster.findOne({                                                                             // 24
        userId: Data.userId                                                                                           // 24
      });                                                                                                             // 24
      console.log('userdata ***** ', userData);                                                                       // 25
                                                                                                                      //
      if (Data.userId != userData.userId && userData == undefined) {                                                  // 26
        Utility.response(context, 400, failResponse('Invalid user or user id. Please check with your user details'));
      } else {                                                                                                        // 32
        if (Data.idProof != '' && Data.passportNum != '' && Data.addressProof != '' && Data.bankName != '' && Data.accNum != '' && Data.ifscNum != '') {
          UserMaster.update({                                                                                         // 35
            userId: Data.userId                                                                                       // 35
          }, {                                                                                                        // 35
            $set: {                                                                                                   // 35
              idProof: Data.idProof,                                                                                  // 36
              passportNum: Data.passportNum,                                                                          // 37
              addressProof: Data.addressProof,                                                                        // 38
              bankName: Data.bankName,                                                                                // 39
              accNum: Data.bankName,                                                                                  // 40
              ifscNum: Data.ifscNum,                                                                                  // 41
              isBankVerified: true                                                                                    // 42
            }                                                                                                         // 35
          });                                                                                                         // 35
        } //let data = UserMaster.findOne({userId:Data.userId})                                                       // 44
        else {                                                                                                        // 34
            UserMaster.update({                                                                                       // 48
              userId: Data.userId                                                                                     // 48
            }, {                                                                                                      // 48
              $set: {                                                                                                 // 49
                idProof: Data.idProof,                                                                                // 50
                passportNum: Data.passportNum,                                                                        // 51
                addressProof: Data.addressProof,                                                                      // 52
                bankName: Data.bankName,                                                                              // 53
                accNum: Data.bankName,                                                                                // 54
                ifscNum: Data.ifscNum                                                                                 // 55
              }                                                                                                       // 49
            });                                                                                                       // 48
          }                                                                                                           // 58
                                                                                                                      //
        Utility.response(context, 200, successResponse({                                                              // 60
          msg: 'User account details updated successfully',                                                           // 64
          data: userData                                                                                              // 66
        }));                                                                                                          // 63
      }                                                                                                               // 69
    } else {                                                                                                          // 70
      //console.log(Data)                                                                                             // 71
      Utility.response(context, 400, failResponse("Please fill " + field + " field"));                                // 72
    }                                                                                                                 // 73
  } else {                                                                                                            // 74
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 75
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 79
    this.response.end('Set OPTIONS.');                                                                                // 80
  }                                                                                                                   // 81
}, {                                                                                                                  // 82
  where: 'server'                                                                                                     // 83
});                                                                                                                   // 83
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"signup.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/user/signup.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var checkMandatoryFields = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  checkMandatoryFields: function (v) {                                                                                // 1
    checkMandatoryFields = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
Router.route('/rest/v1/user/signUp', function () {                                                                    // 5
  this.response.setHeader('Access-Control-Allow-Origin', '*');                                                        // 8
                                                                                                                      //
  if (this.request.method == 'POST') {                                                                                // 9
    var context = this,                                                                                               // 10
        Data = Utility.getRequestContents(context.request),                                                           // 10
        hasQuery = Utility.hasData(Data),                                                                             // 10
        validData = Utility.validate(Data, {                                                                          // 10
      email: NonEmptyString,                                                                                          // 14
      password: NonEmptyString,                                                                                       // 15
      confirmPassword: NonEmptyString,                                                                                // 16
      fullName: NonEmptyString,                                                                                       // 17
      phoneNum: MaybeEmptyString,                                                                                     // 18
      gender: MaybeEmptyString,                                                                                       // 19
      dob: MaybeEmptyString,                                                                                          // 20
      martialStatus: MaybeEmptyString //deviceInfo:Object                                                             // 21
                                                                                                                      //
    }),                                                                                                               // 13
        field = checkMandatoryFields(_.omit(Data, 'phoneNum', 'gender', 'dob', 'martialStatus'));                     // 10
                                                                                                                      //
    if (validData) {                                                                                                  // 25
      // Meteor.call('sendGCM','fgDnMNMDGx8:APA91bFD-JQrEcG4NPQaNLvvBhiv03t4V25H9z_ISfE6bJMlUag5W59wrpte3BB4UFLO40OMn4DJhGtOoClIj6nQ9eQcRBuUljR6A4ym0xbaJQXLNmUSVo4FyoiksxzSk4TBU7Wh3FnU');
      if (!isEmail(Data.email)) {                                                                                     // 27
        validData = false;                                                                                            // 28
        Utility.response(context, 400, failResponse('Please enter valid email address'));                             // 29
      } else if (Data.phoneNum != '' && isPhoneNo(Data.phoneNum) == false) {                                          // 30
        validData = false;                                                                                            // 32
        Utility.response(context, 400, failResponse('Please enter valid phone number along with countrycode.'));      // 33
      } // else if (nestedPositionObject(Data.position) == false) {                                                   // 38
      //   validData = false;                                                                                         // 40
      //   Utility.response(context, 400, failResponse('Please enter a valid position'));                             // 41
      // }                                                                                                            // 42
      else if (Data.password != Data.confirmPassword) {                                                               // 31
          Utility.response(context, 400, failResponse('Passwords does not match'));                                   // 44
        } else if (Data.dob != '' && !isDob(Data.dob)) {                                                              // 45
          Utility.response(context, 400, failResponse('Please enter a valid date of birth'));                         // 48
        } else if (Data.gender != '' && !isGender(Data.gender)) {                                                     // 49
          Utility.response(context, 400, failResponse('Please enter a valid gender'));                                // 52
        } else if (Data.martialStatus != '' && !isMartialStatus(Data.martialStatus)) {                                // 53
          Utility.response(context, 400, failResponse('Please enter a valid martial status'));                        // 56
        } else {                                                                                                      // 57
          //     else if(!(nesteddeviceInfoObject(Data.deviceInfo)))                                                  // 60
          // {                                                                                                        // 61
          //      Utility.response(context, 200, failResponse('Device Information is not valid'));                    // 62
          // }                                                                                                        // 64
          //let userExists = Meteor.users.findOne({ 'emails.address': Data.email.toLowerCase() });                    // 65
          var checkUserEmail = UserMaster.findOne({                                                                   // 66
            email: Data.email.toLowerCase()                                                                           // 66
          });                                                                                                         // 66
          var checkUserPhoneNum = UserMaster.findOne({                                                                // 67
            phoneNum: Data.phoneNum                                                                                   // 67
          });                                                                                                         // 67
                                                                                                                      //
          if (!checkUserEmail) {                                                                                      // 69
            checkUserEmail = {};                                                                                      // 70
          }                                                                                                           // 71
                                                                                                                      //
          if (!checkUserPhoneNum) {                                                                                   // 72
            checkUserPhoneNum = {};                                                                                   // 73
            checkUserPhoneNum.email = '';                                                                             // 74
          } //let userExists = UserMaster.findOne({ email: Data.email.toLowerCase() });                               // 75
          //console.log('userExists ********* ',userExists)                                                           // 77
                                                                                                                      //
                                                                                                                      //
          if (checkUserEmail.email == Data.email) {                                                                   // 78
            Utility.response(context, 400, failResponse('This email address is already registered. Please try again with a different email address.'));
          } else if (checkUserPhoneNum.phoneNum == Data.phoneNum && Data.phoneNum != '') {                            // 86
            Utility.response(context, 400, failResponse('This phone number is already registered. Please try again with a different number.'));
          } else {                                                                                                    // 94
            //console.log(typeof(Data.favouriteFoods))                                                                // 96
            //Data.favouriteFoods = Data.favouriteFoods.split(",");                                                   // 97
            if (Data.phoneNum != '') {                                                                                // 98
              var randomNum = Math.floor(Math.random() * 9000) + 1000;                                                // 99
              sendSms(Data.phoneNum, randomNum);                                                                      // 100
            }                                                                                                         // 101
                                                                                                                      //
            accountId = Accounts.createUser({                                                                         // 103
              email: Data.email,                                                                                      // 104
              password: Data.password,                                                                                // 105
              profile: {                                                                                              // 106
                isActive: 1                                                                                           // 106
              }                                                                                                       // 106
            });                                                                                                       // 103
            var loginToken = Random.secret();                                                                         // 108
            var data = {                                                                                              // 109
              userId: accountId,                                                                                      // 110
              auth: {                                                                                                 // 111
                token: loginToken,                                                                                    // 112
                date_created: new Date()                                                                              // 113
              },                                                                                                      // 111
              //deviceInfo: Data.deviceInfo,                                                                          // 115
              fullName: Data.fullName,                                                                                // 116
              email: Data.email.toLowerCase(),                                                                        // 117
              //password: Data.password,                                                                              // 118
              phoneNum: Data.phoneNum,                                                                                // 119
              code: randomNum,                                                                                        // 120
              firstTimeLogin: true,                                                                                   // 121
              isVerified: false,                                                                                      // 122
              isPhoneNumVerified: false,                                                                              // 123
              isBankVerified: false,                                                                                  // 124
              createdAt: Date.now(),                                                                                  // 125
              getNotification: 1,                                                                                     // 126
              isActive: 1                                                                                             // 127
            }; // Meteor.call('sendGCM','abc');                                                                       // 109
                                                                                                                      //
            console.log('before insert ******** ', data); /* save related data to masterCollection */ //Request.upsertUser(data);
                                                                                                                      //
            UserMaster.registerUser(data);                                                                            // 133
            Accounts.sendVerificationEmail(accountId); // Utility.response(                                           // 135
            //   context,                                                                                             // 138
            //   200,                                                                                                 // 139
            //   successResponse({                                                                                    // 140
            //     msg:                                                                                               // 141
            //       'An OTP has been sent to your mobile number to verify your account, please verify in order to complete your account signup',
            //   })                                                                                                   // 143
            // );                                                                                                     // 144
            //UserMaster.saveDeviceInfo(accountId, Data.deviceType, Data.gcmId, Data.deviceToken);                    // 147
                                                                                                                      //
            Utility.response(context, 200, successResponse({                                                          // 148
              msg: 'An email has been sent to your registered address, click on verification link in order to complete your account signup',
              data: data                                                                                              // 154
            }));                                                                                                      // 151
          }                                                                                                           // 157
        }                                                                                                             // 158
    } else {                                                                                                          // 159
      //console.log(Data)                                                                                             // 160
      Utility.response(context, 400, failResponse("Please fill " + field + " field"));                                // 161
    }                                                                                                                 // 162
  } else {                                                                                                            // 163
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 164
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 168
    this.response.end('Set OPTIONS.');                                                                                // 169
  }                                                                                                                   // 170
}, {                                                                                                                  // 171
  where: 'server'                                                                                                     // 172
});                                                                                                                   // 172
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"verify.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/v1/user/verify.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var checkMandatoryFields = void 0;                                                                                    // 1
module.watch(require("../../Payload"), {                                                                              // 1
  checkMandatoryFields: function (v) {                                                                                // 1
    checkMandatoryFields = v;                                                                                         // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0;                                                                                            // 1
module.watch(require("../../Response"), {                                                                             // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
//import { Email } from 'meteor/email';                                                                               // 5
Router.route('/rest/v1/user/verify', function () {                                                                    // 6
  this.response.setHeader('Access-Control-Allow-Origin', '*'); //SSR.compileTemplate('welcomeEmail', Assets.getText('emailOnVerification.html'));
                                                                                                                      //
  if (this.request.method == 'POST') {                                                                                // 11
    var context = this,                                                                                               // 12
        Data = Utility.getRequestContents(context.request),                                                           // 12
        hasQuery = Utility.hasData(Data),                                                                             // 12
        validData = Utility.validate(Data, {                                                                          // 12
      userId: NonEmptyString,                                                                                         // 16
      phoneNum: NonEmptyString,                                                                                       // 17
      otp: NonEmptyString                                                                                             // 18
    });                                                                                                               // 15
    field = checkMandatoryFields(Data); //console.log('data **** ', Data.otp)                                         // 20
                                                                                                                      //
    if (validData) {                                                                                                  // 22
      var requestData = UserMaster.findOne({                                                                          // 23
        phoneNum: Data.phoneNum                                                                                       // 23
      });                                                                                                             // 23
                                                                                                                      //
      if (requestData) {                                                                                              // 25
        if (requestData.phoneNum != Data.phoneNum) {                                                                  // 26
          Utility.response(context, 400, failResponse('Please enter your registered phone number'));                  // 27
        } else if (requestData.phoneNum == '') {                                                                      // 32
          Utility.response(context, 400, failResponse('This user has not added phone number while sign up'));         // 34
        } else if (requestData.code != Data.otp) {                                                                    // 39
          Utility.response(context, 400, failResponse('Please enter a valid OTP'));                                   // 41
        } else {                                                                                                      // 42
          // accountId = Accounts.createUser({                                                                        // 43
          //   email: requestData.email,                                                                              // 44
          //   password: requestData.password,                                                                        // 45
          //   profile: { isActive: 1 },                                                                              // 46
          // });                                                                                                      // 47
          // let loginToken = Random.secret();                                                                        // 48
          //     let data = {                                                                                         // 49
          //       userId: accountId,                                                                                 // 50
          //       auth: {                                                                                            // 51
          //         token: loginToken,                                                                               // 52
          //         date_created: new Date(),                                                                        // 53
          //       },                                                                                                 // 54
          //       deviceInfo: Data.deviceInfo,                                                                       // 55
          //       fullName: requestData.fullName,                                                                    // 56
          //       email: requestData.email.toLowerCase(),                                                            // 57
          //       phoneNum: requestData.phoneNum,                                                                    // 58
          //       firstTimeLogin: true,                                                                              // 59
          //       isVerified: true,                                                                                  // 60
          //       createdAt: Date.now(),                                                                             // 61
          //       getNotification: 1,                                                                                // 62
          //       isActive: 1,                                                                                       // 63
          //       // rating: {                                                                                       // 64
          //       //   avgRating: 0,                                                                                 // 65
          //       //   count: 0,                                                                                     // 66
          //       //   updated_at: Date.now(),                                                                       // 67
          //       // },                                                                                              // 68
          //     }                                                                                                    // 69
          /* save related data to masterCollection */ //UserMaster.registerUser(data);                                // 70
          //Request.remove({ _id: requestData._id }); // Remove data from Request Collection                          // 73
          //serverSideLogin(requestData.email.toLowerCase(), requestData.password);                                   // 75
          //    console.log(login , "login status============");                                                      // 76
          ////Accounts.sendVerificationEmail(accountId);                                                              // 77
          // Email.send({                                                                                             // 78
          //   from: "e.life096@gmail.com",                                                                           // 79
          //   to: data.email,                                                                                        // 80
          //   subject: "Welcome mail",                                                                               // 81
          //   html: SSR.render('welcomeEmail',data),                                                                 // 82
          // });                                                                                                      // 83
          UserMaster.update({                                                                                         // 85
            userId: Data.userId                                                                                       // 85
          }, {                                                                                                        // 85
            $set: {                                                                                                   // 85
              isPhoneNumVerified: true                                                                                // 85
            }                                                                                                         // 85
          });                                                                                                         // 85
          var data = UserMaster.findOne({                                                                             // 87
            userId: Data.userId                                                                                       // 87
          }); //console.log('data is here ********* ', data)                                                          // 87
                                                                                                                      //
          Utility.response(context, 200, successResponse({                                                            // 91
            msg: 'Verified successfully',                                                                             // 94
            data: data                                                                                                // 94
          }));                                                                                                        // 94
        }                                                                                                             // 96
      } else {                                                                                                        // 97
        Utility.response(context, 400, failResponse('Please enter a valid Phone Number'));                            // 98
      }                                                                                                               // 99
    } else {                                                                                                          // 100
      //console.log(Data)                                                                                             // 101
      Utility.response(context, 400, failResponse("Please fill " + field + " field"));                                // 102
    }                                                                                                                 // 103
  } else {                                                                                                            // 104
    this.response.setHeader('Access-Control-Alatlongow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');   // 105
    this.response.setHeader('Access-Control-Alatlongow-Methods', 'GET, POST, OPTIONS');                               // 109
    this.response.end('Set OPTIONS.');                                                                                // 110
  }                                                                                                                   // 111
}, {                                                                                                                  // 112
  where: 'server'                                                                                                     // 113
});                                                                                                                   // 113
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"Auth.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/Auth.js                                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({                                                                                                       // 1
  "default": function () {                                                                                            // 1
    return authentication;                                                                                            // 1
  }                                                                                                                   // 1
});                                                                                                                   // 1
                                                                                                                      //
function authentication(_ref) {                                                                                       // 1
  var userId = _ref.userId,                                                                                           // 1
      token = _ref.token;                                                                                             // 1
                                                                                                                      //
  if (userId) {                                                                                                       // 2
    return Meteor.call('authentication', userId, token);                                                              // 3
  }                                                                                                                   // 4
                                                                                                                      //
  return {                                                                                                            // 6
    isActive: false,                                                                                                  // 6
    authorise: false,                                                                                                 // 6
    message: 'User not found'                                                                                         // 6
  };                                                                                                                  // 6
}                                                                                                                     // 7
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Payload.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/Payload.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
var Payload = function () {                                                                                           //
  function Payload() {                                                                                                //
    (0, _classCallCheck3.default)(this, Payload);                                                                     //
  }                                                                                                                   //
                                                                                                                      //
  Payload.getUserDataFromHeaders = function () {                                                                      //
    function getUserDataFromHeaders(data) {                                                                           //
      return {                                                                                                        // 3
        userId: data['x-user-id'],                                                                                    // 3
        token: data['x-auth-token']                                                                                   // 3
      };                                                                                                              // 3
    }                                                                                                                 // 4
                                                                                                                      //
    return getUserDataFromHeaders;                                                                                    //
  }();                                                                                                                //
                                                                                                                      //
  Payload.checkMandatoryFields = function () {                                                                        //
    function checkMandatoryFields(Data, fields) {                                                                     //
      var field = '';                                                                                                 // 7
      var i = 0;                                                                                                      // 8
                                                                                                                      //
      for (var each in meteorBabelHelpers.sanitizeForInObject(Data)) {                                                // 9
        /*checks which field is blank*/if (!Data[each]) {                                                             // 10
          field = each;                                                                                               // 12
        }                                                                                                             // 13
      }                                                                                                               // 14
                                                                                                                      //
      return field;                                                                                                   // 16
    }                                                                                                                 // 17
                                                                                                                      //
    return checkMandatoryFields;                                                                                      //
  }();                                                                                                                //
                                                                                                                      //
  return Payload;                                                                                                     //
}();                                                                                                                  //
                                                                                                                      //
module.exports = Payload;                                                                                             // 20
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Response.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/Response.js                                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
/*                                                                                                                    // 1
                                                                                                                      //
this class manages the response structure of web services                                                             //
                                                                                                                      //
*/var Response = function () {                                                                                        //
  function Response() {                                                                                               //
    (0, _classCallCheck3.default)(this, Response);                                                                    //
  }                                                                                                                   //
                                                                                                                      //
  Response.successResponse = function () {                                                                            //
    function successResponse(resultObj) {                                                                             //
      //console.log('resultObj ****** ',resultObj.data)                                                               // 9
      return {                                                                                                        // 10
        success: true,                                                                                                // 11
        message: resultObj.msg,                                                                                       // 12
        statusCode: 200,                                                                                              // 13
        result: resultObj.data                                                                                        // 14
      };                                                                                                              // 10
    }                                                                                                                 // 16
                                                                                                                      //
    return successResponse;                                                                                           //
  }();                                                                                                                //
                                                                                                                      //
  Response.failResponse = function () {                                                                               //
    function failResponse(errorDesc) {                                                                                //
      // console.log(errorDesc)                                                                                       // 19
      return {                                                                                                        // 20
        success: false,                                                                                               // 21
        message: errorDesc,                                                                                           // 22
        //errorCode: Meteor.call('getMessagesCode', errorDesc),                                                       // 23
        statusCode: 400                                                                                               // 24
      };                                                                                                              // 20
    }                                                                                                                 // 26
                                                                                                                      //
    return failResponse;                                                                                              //
  }();                                                                                                                //
                                                                                                                      //
  Response.sessionExpired = function () {                                                                             //
    function sessionExpired(errorDesc) {                                                                              //
      return {                                                                                                        // 29
        success: false,                                                                                               // 30
        message: errorDesc,                                                                                           // 31
        errorCode: Meteor.call('getMessagesCode', errorDesc),                                                         // 32
        statusCode: 401                                                                                               // 33
      };                                                                                                              // 29
    }                                                                                                                 // 35
                                                                                                                      //
    return sessionExpired;                                                                                            //
  }();                                                                                                                //
                                                                                                                      //
  Response.suspendedAccount = function () {                                                                           //
    function suspendedAccount(errorDesc) {                                                                            //
      // console.log(errorDesc)                                                                                       // 38
      return {                                                                                                        // 39
        success: false,                                                                                               // 40
        message: errorDesc,                                                                                           // 41
        errorCode: Meteor.call('getMessagesCode', errorDesc),                                                         // 42
        statusCode: 402                                                                                               // 43
      };                                                                                                              // 39
    }                                                                                                                 // 45
                                                                                                                      //
    return suspendedAccount;                                                                                          //
  }();                                                                                                                //
                                                                                                                      //
  return Response;                                                                                                    //
}();                                                                                                                  //
                                                                                                                      //
module.exports = Response;                                                                                            // 48
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"middleware.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/middleware.js                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var successResponse = void 0,                                                                                         // 1
    failResponse = void 0,                                                                                            // 1
    sessionExpired = void 0,                                                                                          // 1
    suspendedAccount = void 0;                                                                                        // 1
module.watch(require("./Response"), {                                                                                 // 1
  successResponse: function (v) {                                                                                     // 1
    successResponse = v;                                                                                              // 1
  },                                                                                                                  // 1
  failResponse: function (v) {                                                                                        // 1
    failResponse = v;                                                                                                 // 1
  },                                                                                                                  // 1
  sessionExpired: function (v) {                                                                                      // 1
    sessionExpired = v;                                                                                               // 1
  },                                                                                                                  // 1
  suspendedAccount: function (v) {                                                                                    // 1
    suspendedAccount = v;                                                                                             // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var authentication = void 0;                                                                                          // 1
module.watch(require("./Auth"), {                                                                                     // 1
  "default": function (v) {                                                                                           // 1
    authentication = v;                                                                                               // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
var getUserDataFromHeaders = void 0;                                                                                  // 1
module.watch(require("./Payload"), {                                                                                  // 1
  getUserDataFromHeaders: function (v) {                                                                              // 1
    getUserDataFromHeaders = v;                                                                                       // 1
  }                                                                                                                   // 1
}, 2);                                                                                                                // 1
var authNotRequiredURL = ['/rest/v1/user/signUp', '/rest/v1/user/signUpWithBankAcc', '/rest/v1/user/verify', '/rest/v1/user/resendOtp', '/rest/v1/files/upload', '/rest/v1/user/forgotpwd', '/rest/v1/user/login'];
Router.configureBodyParsers();                                                                                        // 15
Router.onBeforeAction(function (req, res, next) {                                                                     // 17
  var context = this,                                                                                                 // 18
      Data = getUserDataFromHeaders(req.headers);                                                                     // 18
                                                                                                                      //
  if (!_.contains(authNotRequiredURL, req.url)) {                                                                     // 21
    console.log('authentication *****', req.url, Data);                                                               // 22
    var checkUser = authentication(Data);                                                                             // 24
                                                                                                                      //
    if (checkUser) {                                                                                                  // 26
      if (!checkUser.isActive) {                                                                                      // 27
        Utility.response(context, 402, suspendedAccount(checkUser.message));                                          // 28
      } else if (!checkUser.authorise) {                                                                              // 29
        Utility.response(context, 401, sessionExpired(checkUser.message));                                            // 30
      } else {                                                                                                        // 31
        this.next();                                                                                                  // 32
      }                                                                                                               // 33
    } else {                                                                                                          // 34
      Utility.response(context, 401, sessionExpired('userId is not provided '));                                      // 35
    }                                                                                                                 // 36
  } else {                                                                                                            // 37
    this.next();                                                                                                      // 38
  }                                                                                                                   // 39
});                                                                                                                   // 40
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utilities.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/rest/utilities.js                                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/*Utilities for rest services*/Utility = {                                                                            // 1
  getRequestContents: function (request) {                                                                            // 4
    switch (request.method) {                                                                                         // 5
      case 'GET':                                                                                                     // 6
        return _.omit(request.query, '__proto__');                                                                    // 7
                                                                                                                      //
      case 'POST':                                                                                                    // 8
        return _.omit(request.body, '__proto__');                                                                     // 9
                                                                                                                      //
      case 'PUT':                                                                                                     // 10
        return _.omit(request.body, '__proto__');                                                                     // 11
                                                                                                                      //
      case 'DELETE':                                                                                                  // 12
        return _.omit(request.body, '__proto__');                                                                     // 13
    }                                                                                                                 // 5
  },                                                                                                                  // 15
  hasData: function (data) {                                                                                          // 16
    return Object.keys(data).length > 0 ? true : false;                                                               // 17
  },                                                                                                                  // 18
  response: function (context, statusCode, data) {                                                                    // 19
    statusCode = statusCode; // ----------------------------------------------------                                  // 20
                                                                                                                      //
    context.response.setHeader('Content-Type', 'application/json');                                                   // 22
    context.response.statusCode = statusCode;                                                                         // 23
    context.response.end(JSON.stringify(data));                                                                       // 24
  },                                                                                                                  // 25
  validate: function (data, pattern) {                                                                                // 26
    return Match.test(data, pattern);                                                                                 // 27
  }                                                                                                                   // 28
};                                                                                                                    // 3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"configs":{"smtpsettings.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/configs/smtpsettings.js                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
smtp = {                                                                                                              // 1
  username: 'rishiankush',                                                                                            // 2
  password: 'Hello@1a',                                                                                               // 3
  //igniva@3197                                                                                                       // 3
  secure: false,                                                                                                      // 4
  port: 2525,                                                                                                         // 5
  server: 'mail.smtp2go.com'                                                                                          // 6
};                                                                                                                    // 1
process.env.MAIL_URL = 'smtp://' + encodeURIComponent(smtp.username) + ':' + encodeURIComponent(smtp.password) + '@' + encodeURIComponent(smtp.server) + ':' + smtp.port; // By default, the email is sent from no-reply@meteor.com. If you wish to receive email from users asking for help with their account, be sure to set this to an email address that you can receive email at.
                                                                                                                      //
Accounts.emailTemplates.from = '<notifications@PoolGame.com>'; // The public name of your application.                // 20
                                                                                                                      //
Accounts.emailTemplates.siteName = 'PoolGame';                                                                        // 23
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"twilioSettings.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/configs/twilioSettings.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var twilio = void 0;                                                                                                  // 1
module.watch(require("twilio"), {                                                                                     // 1
  "default": function (v) {                                                                                           // 1
    twilio = v;                                                                                                       // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
sms = {                                                                                                               // 6
  accountSid: 'AC70c72bb8ed046cd6a1e461803309ed53',                                                                   // 7
  authToken: '8feb561cabe04896c981cdc8cd97d9c8'                                                                       // 8
};                                                                                                                    // 6
var client = new twilio(sms.accountSid, sms.authToken); //console.log(new twilio(sms.accountSid, sms.authToken))      // 11
                                                                                                                      //
sendSms = function (phoneNum, randomNum) {                                                                            // 15
  client.sendSms({                                                                                                    // 16
    body: 'PoolGame one time password:' + randomNum,                                                                  // 18
    to: phoneNum,                                                                                                     // 19
    from: '+16062631146'                                                                                              // 20
  }).then(function (message, err) {                                                                                   // 17
    if (!err) {                                                                                                       // 23
      console.log(message);                                                                                           // 24
    } else {                                                                                                          // 25
      console.log(err);                                                                                               // 26
    }                                                                                                                 // 27
  });                                                                                                                 // 28
}; // customMessage = (phoneNum, body) => {                                                                           // 29
//   client                                                                                                           // 31
//     .sendSms({                                                                                                     // 32
//       body: body,                                                                                                  // 33
//       to: phoneNum,                                                                                                // 34
//       from: '+12243863041',                                                                                        // 35
//     })                                                                                                             // 36
//     .then((message, err) => {                                                                                      // 37
//       if (!err) {                                                                                                  // 38
//         console.log(message);                                                                                      // 39
//       } else {                                                                                                     // 40
//         console.log(err);                                                                                          // 41
//       }                                                                                                            // 42
//     });                                                                                                            // 43
// };                                                                                                                 // 44
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods":{"Counter.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/methods/Counter.js                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Meteor.methods({                                                                                                      // 1
  getNextSequence: function (colName) {                                                                               // 2
    this.unblock();                                                                                                   // 3
    Counter.upsert({                                                                                                  // 5
      _id: colName                                                                                                    // 6
    }, {                                                                                                              // 6
      $inc: {                                                                                                         // 8
        seq: 1                                                                                                        // 9
      },                                                                                                              // 8
      $set: {                                                                                                         // 11
        date_updated: new Date()                                                                                      // 12
      },                                                                                                              // 11
      $setOnInsert: {                                                                                                 // 14
        date_created: new Date()                                                                                      // 15
      }                                                                                                               // 14
    });                                                                                                               // 7
    return Counter.findOne({                                                                                          // 20
      _id: colName                                                                                                    // 20
    }).seq;                                                                                                           // 20
  }                                                                                                                   // 21
});                                                                                                                   // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"SystemMessages.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/methods/SystemMessages.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Meteor.methods({                                                                                                      // 1
  getMessagesCode: function (text) {                                                                                  // 2
    this.unblock();                                                                                                   // 3
    var message = SystemMessages.findOne({                                                                            // 5
      message: text                                                                                                   // 5
    });                                                                                                               // 5
    if (message) return message.code;else {                                                                           // 6
      SystemMessages.insert({                                                                                         // 8
        message: text,                                                                                                // 9
        code: Meteor.call('getNextSequence', 'SystemMessages'),                                                       // 10
        date_created: new Date()                                                                                      // 11
      });                                                                                                             // 8
      return SystemMessages.findOne({                                                                                 // 14
        message: text                                                                                                 // 14
      }).code;                                                                                                        // 14
    }                                                                                                                 // 15
  }                                                                                                                   // 16
});                                                                                                                   // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Users.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/methods/Users.js                                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Meteor.methods({                                                                                                      // 1
  authentication: function (userId, token) {                                                                          // 2
    //let UserData = Meteor.users.findOne({ _id: userId });                                                           // 3
    var UserData = UserMaster.findOne({                                                                               // 4
      userId: userId                                                                                                  // 4
    });                                                                                                               // 4
    var activeUser = UserData ? UserData.isActive : false; // console.log(userId, token);                             // 5
                                                                                                                      //
    if (UserData) {                                                                                                   // 9
      // if (!UserData.profile.isActive) {                                                                            // 10
      if (!activeUser) {                                                                                              // 11
        return {                                                                                                      // 12
          isActive: activeUser,                                                                                       // 13
          authorise: false,                                                                                           // 14
          message: 'Your account has been suspended'                                                                  // 15
        };                                                                                                            // 12
      } else if (UserMaster.checkToken(token, userId) && UserData.isActive) {                                         // 17
        //Meteor.call('setUserLastActivityTime', userId);                                                             // 18
        return {                                                                                                      // 19
          isActive: activeUser,                                                                                       // 19
          authorise: true,                                                                                            // 19
          message: 'Authentication Pass'                                                                              // 19
        };                                                                                                            // 19
      } else {                                                                                                        // 20
        return {                                                                                                      // 21
          isActive: activeUser,                                                                                       // 21
          authorise: false,                                                                                           // 21
          message: 'Session Expired'                                                                                  // 21
        };                                                                                                            // 21
      }                                                                                                               // 22
    } else {                                                                                                          // 23
      return {                                                                                                        // 24
        isActive: activeUser,                                                                                         // 24
        authorise: false,                                                                                             // 24
        message: 'User not found'                                                                                     // 24
      };                                                                                                              // 24
    }                                                                                                                 // 25
  },                                                                                                                  // 26
  // setUserLastActivityTime: function(userId) {                                                                      // 28
  //   this.unblock();                                                                                                // 29
  //   UserMaster.setUserLastActivityTime(userId);                                                                    // 31
  // },                                                                                                               // 32
  serverTime: function () {                                                                                           // 34
    return Date.now();                                                                                                // 35
  }                                                                                                                   // 36
});                                                                                                                   // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"adminMethods.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/methods/adminMethods.js                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Meteor.methods({});                                                                                                   // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"emailConfig.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/methods/emailConfig.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Accounts.emailTemplates.resetPassword.text = function (user, url) {                                                   // 1
  var uName = Meteor.user().profile.name,                                                                             // 2
      msg = 'Your Credentials -\n-----------------------\nemail: ' + Meteor.user().emails + '\npassword: ' + Meteor.user().password + '\n\nTo reset your account password click on the following link. \n',
      from = '\n\n\nThank you! \n\nThe PoolGame Team. \n';                                                            // 2
  return 'Hello ' + uName + ', \n\n' + msg + url + from + Meteor.absoluteUrl() + '\n';                                // 11
};                                                                                                                    // 12
                                                                                                                      //
Accounts.emailTemplates.verifyEmail.subject = function (user, url) {                                                  // 14
  return 'Pool Game Verification Link';                                                                               // 15
};                                                                                                                    // 16
                                                                                                                      //
Accounts.emailTemplates.verifyEmail.text = function (user, url) {                                                     // 18
  url = url.replace("#/", ""); //url = url.replace('-', '')                                                           // 19
                                                                                                                      //
  name = UserMaster.findOne({                                                                                         // 21
    userId: user._id                                                                                                  // 21
  }).fullName;                                                                                                        // 21
  return " Hi " + name + "\n\nPlease click on the below verification link to activate your account:\n\n" + url + "\n\n Regards,\nnotifications@PoolGame.com";
};                                                                                                                    // 29
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"publications":{"publications.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/publications/publications.js                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Meteor.publish('users', function () {                                                                                 // 1
  return Meteor.users.find();                                                                                         // 2
});                                                                                                                   // 3
Meteor.publish('UsersList', function () {                                                                             // 5
  return UserMaster.find({});                                                                                         // 6
});                                                                                                                   // 7
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"main.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Meteor = void 0;                                                                                                  // 1
module.watch(require("meteor/meteor"), {                                                                              // 1
  Meteor: function (v) {                                                                                              // 1
    Meteor = v;                                                                                                       // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
Meteor.startup(function () {// code to run on server at startup                                                       // 3
  // console.log(UserMaster.findOne({userId: 'vSAxTps8TqSbYARm9'}))                                                   // 5
});                                                                                                                   // 6
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections":{"Collection.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// collections/Collection.js                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
SystemMessages = new Mongo.Collection("SystemMessages");                                                              // 1
Counter = new Mongo.Collection("Counter");                                                                            // 3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Files.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// collections/Files.js                                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
FS.HTTP.setBaseUrl('/store');                                                                                         // 1
var imageStore = new FS.Store.GridFS("image", {                                                                       // 3
    beforeWrite: function (fileObj) {                                                                                 // 4
        return {                                                                                                      // 5
            'name': slugify(Date.now() + ' ' + fileObj.original.name)                                                 // 6
        };                                                                                                            // 5
    }                                                                                                                 // 8
});                                                                                                                   // 3
var thumbStore = new FS.Store.GridFS("thumb", {                                                                       // 11
    beforeWrite: function (fileObj) {                                                                                 // 12
        if (fileObj.isImage()) {                                                                                      // 13
            return {                                                                                                  // 14
                'name': slugify(Date.now() + ' ' + fileObj.original.name),                                            // 15
                'extension': 'png',                                                                                   // 16
                'type': 'image/png'                                                                                   // 17
            };                                                                                                        // 14
        } else return false;                                                                                          // 19
    },                                                                                                                // 20
    transformWrite: function (fileObj, readStream, writeStream) {                                                     // 21
        var size = 96;                                                                                                // 22
                                                                                                                      //
        if (gm.isAvailable) {                                                                                         // 24
            if (fileObj.isImage()) {                                                                                  // 25
                gm(readStream).autoOrient().resize(size, size + '^').gravity('Center').extent(size, size).stream('PNG').pipe(writeStream);
            } else {                                                                                                  // 33
                // console.log('File is not Image/Video.');                                                           // 34
                return false;                                                                                         // 35
            }                                                                                                         // 36
        } else {                                                                                                      // 37
            console.log('graphicsmagick or imagemagick not available on the system');                                 // 38
            return false;                                                                                             // 39
        }                                                                                                             // 40
    }                                                                                                                 // 41
});                                                                                                                   // 11
Files = new FS.Collection('uploads', {                                                                                // 44
    stores: [imageStore, thumbStore]                                                                                  // 45
});                                                                                                                   // 44
Files.allow({                                                                                                         // 48
    insert: function (userId, doc) {                                                                                  // 49
        return true;                                                                                                  // 50
    },                                                                                                                // 51
    update: function (userId, doc, fieldNames, modifier) {                                                            // 52
        return true;                                                                                                  // 53
    },                                                                                                                // 54
    remove: function (userId, doc) {                                                                                  // 55
        return true;                                                                                                  // 56
    },                                                                                                                // 57
    download: function (userId, fileObj) {                                                                            // 58
        return true;                                                                                                  // 59
    }                                                                                                                 // 60
});                                                                                                                   // 48
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"RequestCollection.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// collections/RequestCollection.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
/*                                                                                                                    // 1
Request collection is a kind of additional collection in which data of unverified user is stored.                     //
After the user is verified, data from this collection is remived and added in main collection i.e                     //
UserMaster collection.                                                                                                //
*/var RequestCollection = function (_Mongo$Collection) {                                                              //
    (0, _inherits3.default)(RequestCollection, _Mongo$Collection);                                                    //
                                                                                                                      //
    function RequestCollection() {                                                                                    //
        (0, _classCallCheck3.default)(this, RequestCollection);                                                       //
        return (0, _possibleConstructorReturn3.default)(this, _Mongo$Collection.apply(this, arguments));              //
    }                                                                                                                 //
                                                                                                                      //
    RequestCollection.prototype.registerUser = function () {                                                          //
        function registerUser(data) {                                                                                 //
            /* save related data to RequestCollection */return _Mongo$Collection.prototype.insert.call(this, data);   // 9
        }                                                                                                             // 11
                                                                                                                      //
        return registerUser;                                                                                          //
    }(); // upsert user for Request collection                                                                        //
                                                                                                                      //
                                                                                                                      //
    RequestCollection.prototype.upsertUser = function () {                                                            //
        function upsertUser(Data) {                                                                                   //
            console.log(Data, "%%%%%%%%%%%%%%%");                                                                     // 15
                                                                                                                      //
            var checkEmail = _Mongo$Collection.prototype.findOne.call(this, {                                         // 16
                email: Data.email                                                                                     // 16
            }),                                                                                                       // 16
                checkPhone = _Mongo$Collection.prototype.findOne.call(this, {                                         // 16
                phoneNum: Data.phoneNum                                                                               // 17
            }); // console.log(checkPhone, "check phoene is hereeeeee");                                              // 17
            // console.log(checkEmail, "check email is hereeeeee")                                                    // 19
                                                                                                                      //
                                                                                                                      //
            if (checkEmail) {                                                                                         // 20
                return _Mongo$Collection.prototype.update.call(this, {                                                // 21
                    email: Data.email                                                                                 // 22
                }, Data, {                                                                                            // 21
                    upsert: true                                                                                      // 23
                });                                                                                                   // 23
            } else if (checkPhone) {                                                                                  // 24
                return _Mongo$Collection.prototype.update.call(this, {                                                // 25
                    phoneNum: Data.phoneNum                                                                           // 26
                }, Data, {                                                                                            // 25
                    upsert: true                                                                                      // 27
                });                                                                                                   // 27
            } else {                                                                                                  // 28
                return _Mongo$Collection.prototype.update.call(this, {                                                // 29
                    email: Data.email,                                                                                // 30
                    phoneNum: Data.phoneNum                                                                           // 31
                }, Data, {                                                                                            // 29
                    upsert: true                                                                                      // 32
                });                                                                                                   // 32
            }                                                                                                         // 33
        }                                                                                                             // 34
                                                                                                                      //
        return upsertUser;                                                                                            //
    }();                                                                                                              //
                                                                                                                      //
    return RequestCollection;                                                                                         //
}(Mongo.Collection);                                                                                                  //
                                                                                                                      //
Request = new RequestCollection("Request");                                                                           // 37
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"UserMaster.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// collections/UserMaster.js                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
var MasterCollection = function (_Mongo$Collection) {                                                                 //
    (0, _inherits3.default)(MasterCollection, _Mongo$Collection);                                                     //
                                                                                                                      //
    function MasterCollection() {                                                                                     //
        (0, _classCallCheck3.default)(this, MasterCollection);                                                        //
        return (0, _possibleConstructorReturn3.default)(this, _Mongo$Collection.apply(this, arguments));              //
    }                                                                                                                 //
                                                                                                                      //
    MasterCollection.prototype.registerUser = function () {                                                           //
        function registerUser(data) {                                                                                 //
            /* save related data to masterCollection */return _Mongo$Collection.prototype.insert.call(this, data);    // 4
        }                                                                                                             // 6
                                                                                                                      //
        return registerUser;                                                                                          //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.getUserLoacation = function () {                                                       //
        function getUserLoacation(userId) {                                                                           //
            return _Mongo$Collection.prototype.findOne.call(this, {                                                   // 9
                userId: userId                                                                                        // 9
            }).location;                                                                                              // 9
        }                                                                                                             // 10
                                                                                                                      //
        return getUserLoacation;                                                                                      //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.generateToken = function () {                                                          //
        function generateToken(id) {                                                                                  //
            return _Mongo$Collection.prototype.update.call(this, {                                                    // 13
                userId: id                                                                                            // 13
            }, {                                                                                                      // 13
                $set: {                                                                                               // 14
                    auth: {                                                                                           // 15
                        token: Random.secret(),                                                                       // 16
                        date_created: Date.now()                                                                      // 17
                    }                                                                                                 // 15
                }                                                                                                     // 14
            });                                                                                                       // 13
        }                                                                                                             // 21
                                                                                                                      //
        return generateToken;                                                                                         //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.getDeviceInfo = function () {                                                          //
        function getDeviceInfo(userId) {                                                                              //
            return _Mongo$Collection.prototype.findOne.call(this, {                                                   // 24
                userId: userId                                                                                        // 24
            }).deviceInfo;                                                                                            // 24
        }                                                                                                             // 25
                                                                                                                      //
        return getDeviceInfo;                                                                                         //
    }(); // saveDeviceInfoLogOut(id, deviceType, gcmId, deviceToken,token) {                                          //
                                                                                                                      //
                                                                                                                      //
    MasterCollection.prototype.saveDeviceInfoLogOut = function () {                                                   //
        function saveDeviceInfoLogOut(id, deviceToken, token) {                                                       //
            return _Mongo$Collection.prototype.update.call(this, {                                                    // 29
                userId: id                                                                                            // 29
            }, {                                                                                                      // 29
                $set: {                                                                                               // 30
                    'deviceInfo.deviceToken': deviceToken,                                                            // 31
                    // given device token is deleted                                                                  // 31
                    'auth.token': token // given token is deleted to log out.                                         // 32
                                                                                                                      //
                }                                                                                                     // 30
            });                                                                                                       // 29
        }                                                                                                             // 35
                                                                                                                      //
        return saveDeviceInfoLogOut;                                                                                  //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.saveDeviceInfoLogIn = function () {                                                    //
        function saveDeviceInfoLogIn(id, deviceType, deviceToken) {                                                   //
            //console.log(id,deviceType,gcmId,deviceToken);                                                           // 38
            return _Mongo$Collection.prototype.update.call(this, {                                                    // 39
                userId: id                                                                                            // 39
            }, {                                                                                                      // 39
                $set: {                                                                                               // 40
                    deviceInfo: {                                                                                     // 41
                        deviceType: deviceType,                                                                       // 42
                        deviceToken: deviceToken                                                                      // 43
                    }                                                                                                 // 41
                }                                                                                                     // 40
            });                                                                                                       // 39
        }                                                                                                             // 47
                                                                                                                      //
        return saveDeviceInfoLogIn;                                                                                   //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.updateStatus = function () {                                                           //
        function updateStatus(condition, query) {                                                                     //
            return _Mongo$Collection.prototype.update.call(this, condition, query, {                                  // 50
                upsert: true                                                                                          // 50
            });                                                                                                       // 50
        }                                                                                                             // 51
                                                                                                                      //
        return updateStatus;                                                                                          //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.checkToken = function () {                                                             //
        function checkToken(token, userId) {                                                                          //
            if (_Mongo$Collection.prototype.findOne.call(this, {                                                      // 54
                "auth.token": token,                                                                                  // 54
                userId: userId                                                                                        // 54
            })) return true;else {                                                                                    // 54
                return false;                                                                                         // 56
            }                                                                                                         // 57
        }                                                                                                             // 58
                                                                                                                      //
        return checkToken;                                                                                            //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.setNotification = function () {                                                        //
        function setNotification(Data) {                                                                              //
            return _Mongo$Collection.prototype.update.call(this, {                                                    // 61
                userId: Data.userId                                                                                   // 61
            }, {                                                                                                      // 61
                $set: {                                                                                               // 62
                    getNotification: Data.status                                                                      // 63
                }                                                                                                     // 62
            });                                                                                                       // 61
        }                                                                                                             // 66
                                                                                                                      //
        return setNotification;                                                                                       //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.getNotification = function () {                                                        //
        function getNotification(id) {                                                                                //
            return _Mongo$Collection.prototype.findOne.call(this, {                                                   // 69
                userId: id                                                                                            // 69
            }).getNotification;                                                                                       // 69
        }                                                                                                             // 70
                                                                                                                      //
        return getNotification;                                                                                       //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.getUserData = function () {                                                            //
        function getUserData(Data) {                                                                                  //
            return _Mongo$Collection.prototype.findOne.call(this, {                                                   // 73
                $or: [{                                                                                               // 74
                    email: Data                                                                                       // 74
                }, {                                                                                                  // 74
                    userId: Data                                                                                      // 74
                }]                                                                                                    // 74
            });                                                                                                       // 73
        }                                                                                                             // 76
                                                                                                                      //
        return getUserData;                                                                                           //
    }();                                                                                                              //
                                                                                                                      //
    MasterCollection.prototype.setUserLastActivityTime = function () {                                                //
        function setUserLastActivityTime(userId) {                                                                    //
            return _Mongo$Collection.prototype.update.call(this, {                                                    // 79
                userId: userId                                                                                        // 79
            }, {                                                                                                      // 79
                $set: {                                                                                               // 80
                    seen: Date.now() // last activity time                                                            // 81
                                                                                                                      //
                }                                                                                                     // 80
            });                                                                                                       // 79
        }                                                                                                             // 84
                                                                                                                      //
        return setUserLastActivityTime;                                                                               //
    }();                                                                                                              //
                                                                                                                      //
    return MasterCollection;                                                                                          //
}(Mongo.Collection);                                                                                                  //
                                                                                                                      //
UserMaster = new MasterCollection("UserMaster");                                                                      // 88
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validations":{"validations.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// validations/validations.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
NonEmptyString = Match.Where(function (x) {                                                                           // 1
  console.log('function called for non empty string *******', x);                                                     // 2
  return x.length > 0 && typeof String(x) === "string";                                                               // 3
});                                                                                                                   // 4
checkNumber = Match.Where(function (x) {                                                                              // 6
  console.log('function called for number check *******', x);                                                         // 7
  return parseInt(x);                                                                                                 // 8
});                                                                                                                   // 9
MaybeEmptyString = Match.Where(function (x) {                                                                         // 11
  return x.length >= 0;                                                                                               // 12
});                                                                                                                   // 13
                                                                                                                      //
isEmail = function (email) {                                                                                          // 15
  var filter = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                                                                                                                      //
  if (filter.test(email)) {                                                                                           // 17
    return true;                                                                                                      // 18
  }                                                                                                                   // 19
};                                                                                                                    // 20
                                                                                                                      //
isPhoneNo = function (mobile) {                                                                                       // 22
  // return (mobile.match(/^\d{10,15}$/));                                                                            // 23
  //if (mobile.match(/^\d{11,15}$/)) {                                                                                // 24
  if (mobile.match(/^\+(?:[0-9] ?){6,14}[0-9]$/)) {                                                                   // 25
    return true;                                                                                                      // 26
  } else {                                                                                                            // 27
    return false;                                                                                                     // 28
  }                                                                                                                   // 29
};                                                                                                                    // 30
                                                                                                                      //
isDob = function (dob) {                                                                                              // 32
  // return (mobile.match(/^\d{10,15}$/));                                                                            // 33
  //if (mobile.match(/^\d{11,15}$/)) {                                                                                // 34
  if (dob.match(/^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/)) {                                                            // 35
    return true;                                                                                                      // 36
  } else {                                                                                                            // 37
    return false;                                                                                                     // 38
  }                                                                                                                   // 39
};                                                                                                                    // 40
                                                                                                                      //
isGender = function (gender) {                                                                                        // 42
  if (gender.match(/^male$|^Male$|^female$|^Female$|^others$|^Others$/)) {                                            // 43
    return true;                                                                                                      // 44
  } else {                                                                                                            // 45
    return false;                                                                                                     // 46
  }                                                                                                                   // 47
};                                                                                                                    // 48
                                                                                                                      //
isMartialStatus = function (martialStatus) {                                                                          // 50
  if (martialStatus.match(/^single$|^Single$|^married$|^Married$|^divorced$|^Divorced$/)) {                           // 51
    return true;                                                                                                      // 52
  } else {                                                                                                            // 53
    return false;                                                                                                     // 54
  }                                                                                                                   // 55
};                                                                                                                    // 56
                                                                                                                      //
onlyNumber = function (experience) {                                                                                  // 58
  // let filter = /^[0-4][0-9]?$/;                                                                                    // 59
  var filter = /^((\d|[1-9]\d+)(\.\d{0,1})?|\.\d{0,1})$/;                                                             // 60
                                                                                                                      //
  if (filter.test(experience)) {                                                                                      // 61
    return true;                                                                                                      // 62
  } else {                                                                                                            // 63
    return false;                                                                                                     // 64
  }                                                                                                                   // 65
};                                                                                                                    // 66
                                                                                                                      //
capitalizeFirstLetter = function (name) {                                                                             // 68
  return name.charAt(0).toUpperCase() + name.slice(1);                                                                // 69
};                                                                                                                    // 71
                                                                                                                      //
capitalizeEachLetter = function () {                                                                                  // 73
  return this.toLowerCase().split(' ').map(function (word) {                                                          // 74
    return word.capitalizeFirstLetter();                                                                              // 77
  }).join(' ');                                                                                                       // 78
};                                                                                                                    // 80
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./server/rest/v1/File/upload.js");
require("./server/rest/v1/user/forgotpwd.js");
require("./server/rest/v1/user/login.js");
require("./server/rest/v1/user/resendOtp.js");
require("./server/rest/v1/user/signUpWithBankAcc.js");
require("./server/rest/v1/user/signup.js");
require("./server/rest/v1/user/verify.js");
require("./server/configs/smtpsettings.js");
require("./server/configs/twilioSettings.js");
require("./server/methods/Counter.js");
require("./server/methods/SystemMessages.js");
require("./server/methods/Users.js");
require("./server/methods/adminMethods.js");
require("./server/methods/emailConfig.js");
require("./server/publications/publications.js");
require("./server/rest/Auth.js");
require("./server/rest/Payload.js");
require("./server/rest/Response.js");
require("./server/rest/middleware.js");
require("./server/rest/utilities.js");
require("./collections/Collection.js");
require("./collections/Files.js");
require("./collections/RequestCollection.js");
require("./collections/UserMaster.js");
require("./validations/validations.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
